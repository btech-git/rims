<div id="footer">
	<div class="row">
		<div class="small-12 columns">
			<div class="copyright">Copyright &copy;2018 Raperind Motor. All Rights Reserved.

			</div>
		</div>
	</div>
</div>
<?php
/* @var $this LevelController */
/* @var $model Level */


?>


<div class="row">

	<div class="small-12 columns">
		<div id="maincontent">
			<?php $this->renderPartial('_form-dialog', array('model'=>$model)); ?>
		</div>
	</div>
</div>
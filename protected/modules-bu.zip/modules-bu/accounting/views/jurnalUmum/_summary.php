<?php
Yii::app()->clientScript->registerCss('_report', '
	.price {text-align: right;}
');
?>
<?php //echo(CJSON::encode($orderPenjualanPendingSummary->dataProvider->data)); ?>

	
	<?php if($jurnals != NULL) { ?>
		<div class="reportHeader">
		    <div>PT RATU PERDANA INDAH JAYA</div>
		    <div>JURNAL UMUM</div>
		    <div>Periode: <?php echo $tanggal_mulai .' s/d '.$tanggal_sampai; ?></div>
		   
		    <span></span><br>
		    <div>Tanggal Cetak: <?php echo date('d/m/Y'); ?></div>
		</div>
		<p></p>
		<table>
		<thead>
			<th>TANGGAL</th>
			<th>KODE TRANSAKSI</th>
			<th>KODE</th>
			<th>NAMA</th>
			<th>DEBET</th>
			<th>KREDIT</th>
		</thead>
		<tbody>
			<?php $lastkode = ""; ?>
			<?php $totalDebet =  $totalkredit = 0; ?>
			
			<?php foreach ($jurnals as $key => $jurnal): ?>
				<tr>
					<td>
						<?php echo $lastkode == $jurnal->kode_transaksi ?"": $jurnal->tanggal_posting; ?>
					</td>
					<td>
						<?php echo $lastkode == $jurnal->kode_transaksi ?"": $jurnal->kode_transaksi; ?>
					</td>
					<td><?php echo $jurnal->coa->code; ?></td>
					<td><?php echo $jurnal->coa->name ?></td>
					<td><?php echo $jurnal->debet_kredit == 'D'? number_format($jurnal->total,2) : '' ?></td>
					<td><?php echo $jurnal->debet_kredit == 'K'? number_format($jurnal->total,2) : '' ?></td>
					<?php if ($jurnal->debet_kredit == 'D') {
						$totalDebet += $jurnal->total;
					} ?>
					<?php if ($jurnal->debet_kredit == 'K') {
						$totalkredit += $jurnal->total;
					} ?>
				</tr>
				<?php $lastkode = $jurnal->kode_transaksi; ?>
			<?php endforeach ?>
			<tr>
				<td colspan="4">&nbsp;</td>
				<td><b><?php echo number_format($totalDebet,2); ?></b></td>
				<td><b><?php echo number_format($totalkredit,2); ?></b></td>
			</tr>
		</tbody>
	</table>
	<?php } ?>
	

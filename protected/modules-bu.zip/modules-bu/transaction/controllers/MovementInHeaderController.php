<?php

class MovementInHeaderController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column1';

	/**
	 * @return array action filters
	 */
	/*public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}*/

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete','ajaxHtmlAddDetail','ajaxHtmlRemoveDetail','ajaxReceive','ajaxHtmlRemoveDetailAll','updateStatus','updateApproval','ajaxReturn','updateDelivered','updateReceived'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$details = MovementInDetail::model()->findAllByAttributes(array('movement_in_header_id'=>$id));
		$historis = MovementInApproval::model()->findAllByAttributes(array('movement_in_id'=>$id));
		$shippings = MovementInShipping::model()->findAllByAttributes(array('movement_in_id'=>$id));
		$this->render('view',array(
			'model'=>$this->loadModel($id),
			'details'=>$details,
			'historis'=>$historis,
			'shippings'=>$shippings,
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		//$model=new MovementInHeader;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		$movementIn = $this->instantiate(null);
      	$this->performAjaxValidation($movementIn->header);

      	/*Receive Item*/
      	$receiveItem = new TransactionReceiveItem('search');
      		$receiveItem->unsetAttributes();
      		if(isset($_GET['TransactionReceiveItem']))
      			$receiveItem->attributes = $_GET['TransactionReceiveItem'];
      	$receiveItemCriteria = new CDbCriteria;
      	$receiveItemCriteria->together = 'true';
      	$receiveItemCriteria->with = array('recipientBranch');
      	$receiveItemCriteria->compare('recipientBranch.name',$receiveItem->branch_name,true);
      	$receiveItemCriteria->compare('receive_item_no',$receiveItem->receive_item_no,true);
      	$receiveItemDataProvider = new CActiveDataProvider('TransactionReceiveItem',array('criteria'=>$receiveItemCriteria));

      	$receiveItemDetail = new TransactionReceiveItemDetail('search');
			$receiveItemDetail->unsetAttributes();  // clear any default values
	      	if (isset($_GET['TransactionReceiveItemDetail']))
	        	$receiveItemDetail->attributes = $_GET['TransactionReceiveItemDetail'];
	  	$receiveItemDetailCriteria = new CDbCriteria;
	  	$receiveItemDetailCriteria->together = 'true';
	  	$receiveItemDetailCriteria->with = array('product','receiveItem');
	  		
			$receiveItemDetailCriteria->compare('receive_item_id',$receiveItemDetail->receive_item_id,true);      
			$receiveItemDetailCriteria->compare('receiveItem.receive_item_no',$receiveItemDetail->receive_item_no,true);      
			$receiveItemDetailCriteria->compare('product.name',$receiveItemDetail->product_name,true);      
		$receiveItemDetailDataProvider = new CActiveDataProvider('TransactionReceiveItemDetail', array(
    		'criteria'=>$receiveItemDetailCriteria,
  		));

		/*Return Item*/
  		$returnItem = new TransactionReturnItem('search');
      		$returnItem->unsetAttributes();
      		if(isset($_GET['TransactionReturnItem']))
      			$returnItem->attributes = $_GET['TransactionReturnItem'];
      	$returnItemCriteria = new CDbCriteria;
      	$returnItemCriteria->together = 'true';
      	$returnItemCriteria->with = array('recipientBranch');
      	$returnItemCriteria->compare('recipientBranch.name',$returnItem->branch_name,true);
      	$returnItemCriteria->compare('return_item_no',$returnItem->return_item_no,true);
      	$returnItemDataProvider = new CActiveDataProvider('TransactionReturnItem',array('criteria'=>$returnItemCriteria));

      	$returnItemDetail = new TransactionReturnItemDetail('search');
			$returnItemDetail->unsetAttributes();  // clear any default values
	      	if (isset($_GET['TransactionReturnItemDetail']))
	        	$returnItemDetail->attributes = $_GET['TransactionReturnItemDetail'];
	  	$returnItemDetailCriteria = new CDbCriteria;
	  	$returnItemDetailCriteria->together = 'true';
	  	$returnItemDetailCriteria->with = array('product','returnItem');
	  		
			$returnItemDetailCriteria->compare('return_item_id',$returnItemDetail->return_item_id,true);      
			$returnItemDetailCriteria->compare('returnItem.return_item_no',$returnItemDetail->return_item_no,true);      
			$returnItemDetailCriteria->compare('product.name',$returnItemDetail->product_name,true);      
		$returnItemDetailDataProvider = new CActiveDataProvider('TransactionReturnItemDetail', array(
    		'criteria'=>$returnItemDetailCriteria,
  		));

		if(isset($_POST['MovementInHeader']))
		{
			$this->loadState($movementIn);
			if ($movementIn->save(Yii::app()->db)){
      			$this->redirect(array('view', 'id' => $movementIn->header->id));
      		}
		}

		$this->render('create',array(
			'movementIn'=>$movementIn,
			'receiveItemDetail'=>$receiveItemDetail,
			'receiveItemDetailDataProvider'=>$receiveItemDetailDataProvider,
			'receiveItem'=>$receiveItem,
			'receiveItemDataProvider'=>$receiveItemDataProvider,
			'returnItem'=>$returnItem,
			'returnItemDataProvider'=>$returnItemDataProvider,
			'returnItemDetail'=>$returnItemDetail,
			'returnItemDetailDataProvider'=>$returnItemDetailDataProvider,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		//$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
		$movementIn = $this->instantiate($id);
		// Uncomment the following line if AJAX validation is needed
		$this->performAjaxValidation($movementIn->header);
		$receiveItem = new TransactionReceiveItem('search');
      		$receiveItem->unsetAttributes();
      		if(isset($_GET['TransactionReceiveItem']))
      			$receiveItem->attributes = $_GET['TransactionReceiveItem'];
      	$receiveItemCriteria = new CDbCriteria;
		$receiveItemCriteria->compare('recipient_branch_id',$movementIn->header->branch_id);
      	$receiveItemCriteria->together = 'true';
      	$receiveItemCriteria->with = array('recipientBranch');
      	$receiveItemCriteria->compare('recipientBranch.name',$receiveItem->branch_name,true);
      	$receiveItemCriteria->compare('receive_item_no',$receiveItem->receive_item_no,true);

      	$receiveItemDataProvider = new CActiveDataProvider('TransactionReceiveItem',array('criteria'=>$receiveItemCriteria));

      	$receiveItemDetail = new TransactionReceiveItemDetail('search');
			$receiveItemDetail->unsetAttributes();  // clear any default values
	      	if (isset($_GET['TransactionReceiveItemDetail']))
	        	$receiveItemDetail->attributes = $_GET['TransactionReceiveItemDetail'];
	  	$receiveItemDetailCriteria = new CDbCriteria;
	  	$receiveItemDetailCriteria->compare('receive_item_id',$movementIn->header->receive_item_id);
	  	$receiveItemDetailCriteria->together = 'true';
	  	$receiveItemDetailCriteria->with = array('product','receiveItem');
	  		
			$receiveItemDetailCriteria->compare('receive_item_id',$receiveItemDetail->receive_item_id,true);      
			$receiveItemDetailCriteria->compare('receiveItem.receive_item_no',$receiveItemDetail->receive_item_no,true);      
			$receiveItemDetailCriteria->compare('product.name',$receiveItemDetail->product_name,true);      
		$receiveItemDetailDataProvider = new CActiveDataProvider('TransactionReceiveItemDetail', array(
    		'criteria'=>$receiveItemDetailCriteria,
  		));

  		/*Return Item*/
  		$returnItem = new TransactionReturnItem('search');
      		$returnItem->unsetAttributes();
      		if(isset($_GET['TransactionReturnItem']))
      			$returnItem->attributes = $_GET['TransactionReturnItem'];
      	$returnItemCriteria = new CDbCriteria;
      	$receiveItemCriteria->compare('recipient_branch_id',$movementIn->header->branch_id);
      	$returnItemCriteria->together = 'true';
      	$returnItemCriteria->with = array('recipientBranch');
      	$returnItemCriteria->compare('recipientBranch.name',$returnItem->branch_name,true);
      	$returnItemCriteria->compare('return_item_no',$returnItem->return_item_no,true);
      	$returnItemDataProvider = new CActiveDataProvider('TransactionReturnItem',array('criteria'=>$returnItemCriteria));

      	$returnItemDetail = new TransactionReturnItemDetail('search');
			$returnItemDetail->unsetAttributes();  // clear any default values
	      	if (isset($_GET['TransactionReturnItemDetail']))
	        	$returnItemDetail->attributes = $_GET['TransactionReturnItemDetail'];
	  	$returnItemDetailCriteria = new CDbCriteria;
	  	$returnItemDetailCriteria->compare('return_item_id',$movementIn->header->return_item_id);
	  	$returnItemDetailCriteria->together = 'true';
	  	$returnItemDetailCriteria->with = array('product','returnItem');
	  		
			$returnItemDetailCriteria->compare('return_item_id',$returnItemDetail->return_item_id,true);      
			$returnItemDetailCriteria->compare('returnItem.return_item_no',$returnItemDetail->return_item_no,true);      
			$returnItemDetailCriteria->compare('product.name',$returnItemDetail->product_name,true);      
		$returnItemDetailDataProvider = new CActiveDataProvider('TransactionReturnItemDetail', array(
    		'criteria'=>$returnItemDetailCriteria,
  		));


		if(isset($_POST['MovementInHeader']))
		{
			// $model->attributes=$_POST['MovementInHeader'];
			// if($model->save())
			// 	$this->redirect(array('view','id'=>$model->id));
			$this->loadState($movementIn);
			if ($movementIn->save(Yii::app()->db)){
      			$this->redirect(array('view', 'id' => $movementIn->header->id));
      		}
		}

		$this->render('update',array(
			'movementIn'=>$movementIn,
			'receiveItemDetail'=>$receiveItemDetail,
			'receiveItemDetailDataProvider'=>$receiveItemDetailDataProvider,
			'receiveItem'=>$receiveItem,
			'receiveItemDataProvider'=>$receiveItemDataProvider,
			'returnItem'=>$returnItem,
			'returnItemDataProvider'=>$returnItemDataProvider,
			'returnItemDetail'=>$returnItemDetail,
			'returnItemDetailDataProvider'=>$returnItemDetailDataProvider,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('MovementInHeader');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new MovementInHeader('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['MovementInHeader']))
			$model->attributes=$_GET['MovementInHeader'];
		$receiveItem = new TransactionReceiveItem('search');
      		$receiveItem->unsetAttributes();
      		if(isset($_GET['TransactionReceiveItem']))
      			$receiveItem->attributes = $_GET['TransactionReceiveItem'];

		$returnItem = new TransactionReturnItem('search');
      		$returnItem->unsetAttributes();
      		if(isset($_GET['TransactionReturnItem']))
      			$returnItem->attributes = $_GET['TransactionReturnItem'];

		$this->render('admin',array(
			'model'=>$model,
			'receiveItem'=>$receiveItem,
			'returnItem'=>$returnItem,
		));
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return MovementInHeader the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=MovementInHeader::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param MovementInHeader $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='movement-in-header-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
	public function instantiate($id)
	{
	;	if (empty($id)){
			$movementIn = new MovementIns(new MovementInHeader(), array());
			//print_r("Inst");
		}
		else
		{
			$movementInModel = $this->loadModel($id);
			$movementIn = new MovementIns($movementInModel, $movementInModel->movementInDetails);
			//print_r("test");

		}
		return $movementIn;
	}

	public function loadState($movementIn)
	{
		if (isset($_POST['MovementInHeader']))
		{
			$movementIn->header->attributes = $_POST['MovementInHeader'];
		}


		if (isset($_POST['MovementInDetail']))
		{
			foreach ($_POST['MovementInDetail'] as $i => $item)
			{
				if (isset($movementIn->details[$i])){
					$movementIn->details[$i]->attributes = $item;

				}

				else
				{
					$detail = new MovementInDetail();
					$detail->attributes = $item;
					$movementIn->details[] = $detail;
					
				}
			}
			if (count($_POST['MovementInDetail']) < count($movementIn->details))
				array_splice($movementIn->details, $i + 1);
		}
		else
		{
			$movementIn->details = array();

		}

	}
	//Add Detail
	public function actionAjaxHtmlAddDetail($id,$detailId,$type)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			$movementIn = $this->instantiate($id); 	
			$this->loadState($movementIn);
			
			$movementIn->addDetail($detailId,$type);
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
   			Yii::app()->clientscript->scriptMap['jquery.js'] = false;
   			Yii::app()->clientscript->scriptMap['jquery.yiigridview.js'] = false;
      		$this->renderPartial('_detail', array('movementIn'=>$movementIn,
      	
      	), false, true);
		}
	}
	public function actionAjaxHtmlRemoveDetail($id, $index)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			$movementIn = $this->instantiate($id);
			$this->loadState($movementIn);

			$movementIn->removeDetailAt($index);
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
      		Yii::app()->clientscript->scriptMap['jquery.js'] = false;
      		//Yii::app()->clientscript->scriptMap['jquery.yiigridview.js'] = false;
			$this->renderPartial('_detail', array('movementIn'=>$movementIn,
      	
      		), false, true);
		}
	}
	public function actionAjaxHtmlRemoveDetailAll($id)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			$movementIn = $this->instantiate($id);
			$this->loadState($movementIn);

			$movementIn->removeDetailAll();
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
      		Yii::app()->clientscript->scriptMap['jquery.js'] = false;
      		//Yii::app()->clientscript->scriptMap['jquery.yiigridview.js'] = false;
			$this->renderPartial('_detail', array('movementIn'=>$movementIn,
      	
      		), false, true);
		}
	}
	public function actionAjaxReceive($id){
		if (Yii::app()->request->isAjaxRequest)
		{
			$receive = TransactionReceiveItem::model()->findByPk($id);
			$type = $requestNumber = "";
			if($receive->request_type == "Internal Delivery Order"){
				$type = "Internal Delivery Order";
				$requestNumber = $receive->deliveryOrder->delivery_order_no;
			}
			elseif ($receive->request_type == "Purchase Order") {
				$type = "Purchase Order";
				$requestNumber = $receive->purchaseOrder->purchase_order_no;
			}
			elseif ($receive->request_type == "Consignment In") {
				$type = "Consignment In";
				$requestNumber = $receive->consignmentIn->consignment_in_number;
			}

			$object = array(
				'id' => $receive->id,
				'number' => $receive->receive_item_no,
				'type'=>$type,
				'requestNumber'=>$requestNumber,
			);

			echo CJSON::encode($object);
		}
	}
	public function actionUpdateStatus($id)
	{
		$model=$this->loadModel($id);

		if(isset($_POST['MovementInHeader']))	
		{
			$model->status =$_POST['MovementInHeader']['status'];
			$model->supervisor_id =$_POST['MovementInHeader']['supervisor_id'];
			
			


			if($model->update(array('status','supervisor_id')))
				$this->redirect(array('view','id'=>$model->id));
		}

		$this->render('updateStatus',array(
			'model'=>$model,
			//'jenisPersediaan'=>$jenisPersediaan,
			//'jenisPersediaanDataProvider'=>$jenisPersediaanDataProvider,
			));

	}
	public function actionUpdateApproval($headerId)
	{
		$movement = MovementInHeader::model()->findByPK($headerId);
		$historis = MovementInApproval::model()->findAllByAttributes(array('movement_in_id'=>$headerId));
		$model = new MovementInApproval;
		//$model = $this->loadModelDetail($detailId);
		if(isset($_POST['MovementInApproval']))
		{
			$model->attributes=$_POST['MovementInApproval'];
			if ($model->save()){
				$movement->status = $model->approval_type;
				$movement->save(false);
				
				$this->redirect(array('view', 'id' => $headerId));
			}
		}
		
		$this->render('updateApproval',array(
			'model'=>$model,
			'movement'=>$movement,
			'historis'=>$historis,
			//'jenisPersediaan'=>$jenisPersediaan,
			//'jenisPersediaanDataProvider'=>$jenisPersediaanDataProvider,
		));
	}

	public function actionAjaxReturn($id){
		if (Yii::app()->request->isAjaxRequest)
		{
			$return = TransactionReturnItem::model()->findByPk($id);
			
			$object = array(
				'id' => $return->id,
				'number' => $return->return_item_no,
				
			);

			echo CJSON::encode($object);
		}
	}

	public function actionUpdateDelivered($id){
		$delivered = new MovementInShipping();
		$delivered->movement_in_id = $id;
		$delivered->status = "Delivered";
		$delivered->date = date('Y-m-d');
		$delivered->supervisor_id = Yii::app()->user->getId();
		if($delivered->save()){
			$movement = MovementInHeader::model()->findByPk($id);
			$movement->status = "Delivered";
			$movement->save(false);
		}
	}
	public function actionUpdateReceived($id)
	{
		$received = new MovementInShipping();
		$received->movement_in_id = $id;
		$received->status = "Received";
		$received->date = date('Y-m-d');
		$received->supervisor_id = Yii::app()->user->getId();
		if($received->save()){
			$movement = MovementInHeader::model()->findByPk($id);
			$movementDetails = MovementInDetail::model()->findAllByAttributes(array('movement_in_header_id'=>$id));

			foreach($movementDetails as $movementDetail){
				$inventoryId = "";
				$inventory = Inventory::model()->findByAttributes(array('product_id'=>$movementDetail->product_id,'warehouse_id'=>$movementDetail->warehouse_id));
				if($inventory !== NULL){
					$inventoryId = $inventory->id;
				}else{
					$insertInventory = new Inventory();
		    		$insertInventory->product_id = $productId;
		    		$insertInventory->warehouse_id = $warehouseId;
		    		$insertInventory->status = 'Active';
		    		if ($insertInventory->save()) {
		    			$inventoryId = $insertInventory->id;
		    		}else{
		                $inventoryId = '';
		    		}
				}
				$inventoryDetail = new InventoryDetail();
					$inventoryDetail->inventory_id = $inventoryId;
					$inventoryDetail->product_id = $movementDetail->product_id;
					$inventoryDetail->warehouse_id = $movementDetail->warehouse_id;
					$inventoryDetail->transaction_type = 'Movement';
					$inventoryDetail->transaction_number = $movement->movement_in_number;
					$inventoryDetail->transaction_date = $movement->date_posting;
					$inventoryDetail->stock_in = $movementDetail->quantity;
					$inventoryDetail->notes = "Data from Movement In";
					
					$inventoryDetail->save(false);
				
			}
			$movement->status = "Finished";
			$movement->save(false);
		}

		
	}

}

<?php

class TransactionSentRequestController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column1';

	/**
	 * @return array action filters
	 */
	/*public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}*/

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete','ajaxHtmlAddDetail','ajaxProduct','ajaxHtmlRemoveDetail','ajaxGetTotal','UpdateApproval'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$sentDetails = TransactionSentRequestDetail::model()->findAllByAttributes(array('sent_request_id'=>$id));

		$this->render('view',array(
			'model'=>$this->loadModel($id),
			'sentDetails'=>$sentDetails,
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		// $model=new TransactionSentRequest;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		// if(isset($_POST['TransactionSentRequest']))
		// {
		// 	$model->attributes=$_POST['TransactionSentRequest'];
		// 	if($model->save())
		// 		$this->redirect(array('view','id'=>$model->id));
		// }

		// $this->render('create',array(
		// 	'model'=>$model,
		// ));

		$product = new Product('search');
	      	$product->unsetAttributes();  // clear any default values
	      	if (isset($_GET['Product']))
	        	$product->attributes = $_GET['Product'];

			$productCriteria = new CDbCriteria;
			$productCriteria->compare('name',$product->name,true);
			$productCriteria->compare('manufacturer_code',$product->manufacturer_code,true);
			$productCriteria->together=true;
		$productCriteria->select = 't.*, rims_product_master_category.name as product_master_category_name, rims_product_sub_master_category.name as product_sub_master_category_name, rims_product_sub_category.name as product_sub_category_name, rims_brand.name as product_brand_name';
					$productCriteria->join = 'join rims_product_master_category on rims_product_master_category.id = t.product_master_category_id join rims_product_sub_master_category on rims_product_sub_master_category.id = t.product_sub_master_category_id join rims_product_sub_category on rims_product_sub_category.id = t.product_sub_category_id join rims_brand on rims_brand.id = t.brand_id ';
					$productCriteria->compare('rims_product_master_category.name', $product->product_master_category_name,true);
					$productCriteria->compare('rims_product_sub_master_category.name', $product->product_sub_master_category_name,true);
					$productCriteria->compare('rims_product_sub_category.name', $product->product_sub_category_name,true);
					$productCriteria->compare('rims_brand.name', $product->product_brand_name,true);
		$productDataProvider = new CActiveDataProvider('Product', array(
			    	'criteria'=>$productCriteria,));

		$sentRequest = $this->instantiate(null);
		$this->performAjaxValidation($sentRequest->header);
		if(isset($_POST['TransactionSentRequest']))
		{
			
			$this->loadState($sentRequest);
			
			if ($sentRequest->save(Yii::app()->db)){
				$this->redirect(array('view', 'id' => $sentRequest->header->id));
			}
		}

		$this->render('create',array(
			'sentRequest'=>$sentRequest,
			'product'=>$product,
			'productDataProvider'=>$productDataProvider,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		// $model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		// if(isset($_POST['TransactionSentRequest']))
		// {
		// 	$model->attributes=$_POST['TransactionSentRequest'];
		// 	if($model->save())
		// 		$this->redirect(array('view','id'=>$model->id));
		// }

		// $this->render('update',array(
		// 	'model'=>$model,
		// ));

		$product = new Product('search');
	      	$product->unsetAttributes();  // clear any default values
	      	if (isset($_GET['Product']))
	        	$product->attributes = $_GET['Product'];

			$productCriteria = new CDbCriteria;
			$productCriteria->compare('name',$product->name,true);
			$productCriteria->compare('manufacturer_code',$product->manufacturer_code,true);
			$productCriteria->together=true;
		$productCriteria->select = 't.*, rims_product_master_category.name as product_master_category_name, rims_product_sub_master_category.name as product_sub_master_category_name, rims_product_sub_category.name as product_sub_category_name, rims_brand.name as product_brand_name';
					$productCriteria->join = 'join rims_product_master_category on rims_product_master_category.id = t.product_master_category_id join rims_product_sub_master_category on rims_product_sub_master_category.id = t.product_sub_master_category_id join rims_product_sub_category on rims_product_sub_category.id = t.product_sub_category_id join rims_brand on rims_brand.id = t.brand_id ';
					$productCriteria->compare('rims_product_master_category.name', $product->product_master_category_name,true);
					$productCriteria->compare('rims_product_sub_master_category.name', $product->product_sub_master_category_name,true);
					$productCriteria->compare('rims_product_sub_category.name', $product->product_sub_category_name,true);
					$productCriteria->compare('rims_brand.name', $product->product_brand_name,true);
		$productDataProvider = new CActiveDataProvider('Product', array(
			    	'criteria'=>$productCriteria,));
		// 
		$sentRequest = $this->instantiate($id);

		$this->performAjaxValidation($sentRequest->header);

		if(isset($_POST['TransactionSentRequest']))
		{
			

			$this->loadState($sentRequest);
			if ($sentRequest->save(Yii::app()->db)){
				$this->redirect(array('view', 'id' => $sentRequest->header->id));
			}else{
				foreach($sentRequest->details as $detail){
					echo $detail->quantity;
				}
			} 

		}

		$this->render('update',array(
			'sentRequest'=>$sentRequest,
			'product'=>$product,
			'productDataProvider'=>$productDataProvider,
			
		));
	
	}
	public function actionUpdateApproval($headerId)
	{
		$sentRequest = TransactionSentRequest::model()->findByPk($headerId);
		// $sentRequestDetail = TransactionSentRequestDetail::model()->findByPk($detailId);
		$historis = TransactionSentRequestApproval::model()->findAllByAttributes(array('sent_request_id'=>$headerId));
		$model = new TransactionSentRequestApproval;
		//$model = $this->loadModelDetail($detailId);
		if(isset($_POST['TransactionSentRequestApproval']))
		{
			$model->attributes=$_POST['TransactionSentRequestApproval'];

			if ($model->save()){
				$sentRequest->status_document = $model->approval_type;
				if($model->approval_type == 'Approved'){
					$sentRequest->approved_by = $model->supervisor_id;
				}
				$sentRequest->save(false);
				$this->redirect(array('view', 'id' => $headerId));
			}
		}
		
		$this->render('updateApproval',array(
			'model'=>$model,
			'sentRequest'=>$sentRequest,
			//'sentRequestDetail'=>$sentRequestDetail,
			'historis'=>$historis,
			//'jenisPersediaan'=>$jenisPersediaan,
			//'jenisPersediaanDataProvider'=>$jenisPersediaanDataProvider,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('TransactionSentRequest');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new TransactionSentRequest('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['TransactionSentRequest']))
			$model->attributes=$_GET['TransactionSentRequest'];

		$this->render('admin',array(
			'model'=>$model,
		));
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return TransactionSentRequest the loaded model
	 * @throws CHttpException
	 */

	public function actionAjaxProduct($id){
		if (Yii::app()->request->isAjaxRequest)
		{
			$product = Product::model()->findByPk($id);

			$object = array(
				'id' => $product->id,
				'name' => $product->name,
				'retail_price'=>$product->retail_price,
				'hpp'=>$product->hpp,
			);

			echo CJSON::encode($object);
		}
	}
	public function actionAjaxGetTotal($id)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			$sentRequest = $this->instantiate($id);
			$this->loadState($sentRequest);
			//$requestType =$requestOrder->header->request_type;
			$total = 0;
			$totalItems = 0;
			// if($requestType == 'Request for Purchase'){
			// 	foreach ($requestOrder->details as $key => $detail) {
			// 		$totalItems += $detail->total;
			// 		$total += $detail->subtotal;_quantity;
			// 	}
			// } else if($requestType == 'Request for Transfer'){
			// 	foreach ($requestOrder->transferDetails as $key => $transferDetail) {
			// 		$totalItems += $transferDetail->quantity;	
			// 	}
			// }
			foreach ($sentRequest->details as $key => $detail) {
				$totalItems += $detail->quantity;
				$total += $detail->unit_price * $totalItems;
			}			
			//echo($totalItems);	
			$object = array('total'=>$total,'totalItems'=>$totalItems);
			echo CJSON::encode($object);

		}

	}
	
	//Add Detail
	public function actionAjaxHtmlAddDetail($id)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			$product = new Product('search');
	      	$product->unsetAttributes();  // clear any default values
	      	if (isset($_GET['Product']))
	        	$product->attributes = $_GET['Product'];

			$productCriteria = new CDbCriteria;
			$productCriteria->compare('name',$product->name,true);
			$productCriteria->compare('manufacturer_code',$product->manufacturer_code,true);
			$productCriteria->together=true;
		$productCriteria->select = 't.*, rims_product_master_category.name as product_master_category_name, rims_product_sub_master_category.name as product_sub_master_category_name, rims_product_sub_category.name as product_sub_category_name, rims_brand.name as product_brand_name';
					$productCriteria->join = 'join rims_product_master_category on rims_product_master_category.id = t.product_master_category_id join rims_product_sub_master_category on rims_product_sub_master_category.id = t.product_sub_master_category_id join rims_product_sub_category on rims_product_sub_category.id = t.product_sub_category_id join rims_brand on rims_brand.id = t.brand_id ';
					$productCriteria->compare('rims_product_master_category.name', $product->product_master_category_name,true);
					$productCriteria->compare('rims_product_sub_master_category.name', $product->product_sub_master_category_name,true);
					$productCriteria->compare('rims_product_sub_category.name', $product->product_sub_category_name,true);
					$productCriteria->compare('rims_brand.name', $product->product_brand_name,true);
		$productDataProvider = new CActiveDataProvider('Product', array(
			    	'criteria'=>$productCriteria,));
			$sentRequest = $this->instantiate($id); 	
			$this->loadState($sentRequest);
			
			$sentRequest->addDetail();
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
   			Yii::app()->clientscript->scriptMap['jquery.js'] = false;
      $this->renderPartial('_detailSentRequest', array('sentRequest'=>$sentRequest,'product'=>$product,
			'productDataProvider'=>$productDataProvider,
      	
      	), false, true);
		}
	}
	public function actionAjaxHtmlRemoveDetail($id, $index)
	{
		if (Yii::app()->request->isAjaxRequest)
		{

				$product = new Product('search');
	      	$product->unsetAttributes();  // clear any default values
	      	if (isset($_GET['Product']))
	        	$product->attributes = $_GET['Product'];

			$productCriteria = new CDbCriteria;
			$productCriteria->compare('name',$product->name,true);
			$productCriteria->compare('manufacturer_code',$product->manufacturer_code,true);
			$productCriteria->together=true;
		$productCriteria->select = 't.*, rims_product_master_category.name as product_master_category_name, rims_product_sub_master_category.name as product_sub_master_category_name, rims_product_sub_category.name as product_sub_category_name, rims_brand.name as product_brand_name';
					$productCriteria->join = 'join rims_product_master_category on rims_product_master_category.id = t.product_master_category_id join rims_product_sub_master_category on rims_product_sub_master_category.id = t.product_sub_master_category_id join rims_product_sub_category on rims_product_sub_category.id = t.product_sub_category_id join rims_brand on rims_brand.id = t.brand_id ';
					$productCriteria->compare('rims_product_master_category.name', $product->product_master_category_name,true);
					$productCriteria->compare('rims_product_sub_master_category.name', $product->product_sub_master_category_name,true);
					$productCriteria->compare('rims_product_sub_category.name', $product->product_sub_category_name,true);
					$productCriteria->compare('rims_brand.name', $product->product_brand_name,true);
		$productDataProvider = new CActiveDataProvider('Product', array(
			    	'criteria'=>$productCriteria,));

			$sentRequest = $this->instantiate($id);
			$this->loadState($sentRequest);

			$sentRequest->removeDetailAt($index);
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
     		Yii::app()->clientscript->scriptMap['jquery.js'] = false;
			 $this->renderPartial('_detailSentRequest', array('sentRequest'=>$sentRequest,'product'=>$product,
			'productDataProvider'=>$productDataProvider,
      	
      	), false, true);
		}
	}

	public function instantiate($id)
	{
		if (empty($id)){
			$sentRequest = new SentRequests(new TransactionSentRequest(), array());
			//print_r("test");
		}
		else
		{
			$sentRequestModel = $this->loadModel($id);
			$sentRequest = new SentRequests($sentRequestModel, $sentRequestModel->transactionSentRequestDetails);
			//print_r("test");
		}
		return $sentRequest;
	}
	public function loadState($sentRequest)
	{
		if (isset($_POST['TransactionSentRequest']))
		{
			$sentRequest->header->attributes = $_POST['TransactionSentRequest'];
		}


		if (isset($_POST['TransactionSentRequestDetail']))
		{
			foreach ($_POST['TransactionSentRequestDetail'] as $i => $item)
			{
				if (isset($sentRequest->details[$i])){
					$sentRequest->details[$i]->attributes = $item;
				
				}

				else
				{
					$detail = new TransactionSentRequestDetail();	
					$detail->attributes = $item;
					$sentRequest->details[] = $detail;
					
				} 
			}
			if (count($_POST['TransactionSentRequestDetail']) < count($sentRequest->details))
				array_splice($sentRequest->details, $i + 1);
		}
		else
			{
				$sentRequest->details = array();
				
			}



	}
	public function loadModel($id)
	{
		$model=TransactionSentRequest::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param TransactionSentRequest $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='transaction-sent-request-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}

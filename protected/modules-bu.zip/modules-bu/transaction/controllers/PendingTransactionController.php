<?php

class PendingTransactionController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column1';

	/**
	 * @return array action filters
	 */
	/*public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}*/

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete','ajaxSent','ajaxHtmlAddDetail','ajaxSales','ajaxHtmlRemoveDetail','ajaxCustomer','ajaxHtmlRemoveDetailRequest','ajaxConsignment','ajaxTransfer'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	// public function actionView($id)
	// {
	// 	$deliveryDetails = TransactionDeliveryOrderDetail::model()->findAllByAttributes(array('delivery_order_id'=>$id));
	// 	$this->render('view',array(
	// 		'model'=>$this->loadModel($id),
	// 		'deliveryDetails'=>$deliveryDetails,
	// 	));
	// }

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	
	public function actionIndex()
	{

		$tanggal_mulai = (isset($_GET['tanggal_mulai'])) ? $_GET['tanggal_mulai'] : '';
        $tanggal_sampai = (isset($_GET['tanggal_sampai'])) ? $_GET['tanggal_sampai'] : '';
        $status_document = (isset($_GET['status_document'])) ? $_GET['status_document'] : '';


		$model=new TransactionDeliveryOrder('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['TransactionDeliveryOrder']))
			$model->attributes=$_GET['TransactionDeliveryOrder'];

		$branchId = User::model()->findByPk(Yii::app()->user->getId())->branch_id;

		$request = new TransactionRequestOrder('search');
      	$request->unsetAttributes();  // clear any default values
      	if (isset($_GET['TransactionRequestOrder']))
        	$request->attributes = $_GET['TransactionRequestOrder'];

		$requestCriteria = new CDbCriteria;
		$requestCriteria->compare('request_order_no',$request->request_order_no.'%',true,'AND', false);
		$requestCriteria->addCondition("status_document != 'Approved' AND main_branch_id = ".$branchId );
		if ($status_document) 
			$requestCriteria->addCondition("status_document = '".$status_document."'");
		
		$requestCriteria->addBetweenCondition('t.request_order_date', $tanggal_mulai, $tanggal_sampai);
		$requestCriteria->order = 'request_order_date DESC';
		$requestDataProvider = new CActiveDataProvider('TransactionRequestOrder', array(
			'criteria'=>$requestCriteria,
		));

		$purchase = new TransactionPurchaseOrder('search');
      	$purchase->unsetAttributes();  // clear any default values
      	if (isset($_GET['TransactionPurchaseOrder']))
        	$purchase->attributes = $_GET['TransactionPurchaseOrder'];

		$purchaseCriteria = new CDbCriteria;
		$purchaseCriteria->compare('purchase_order_no',$purchase->purchase_order_no.'%',true,'AND', false);
		$purchaseCriteria->addCondition("status_document != 'Approved' AND main_branch_id = ".$branchId);
		if ($status_document) 
			$purchaseCriteria->addCondition("status_document = '".$status_document."'");
		$purchaseCriteria->addBetweenCondition('t.purchase_order_date', $tanggal_mulai, $tanggal_sampai);
		$purchaseCriteria->order = 'purchase_order_date DESC';

		$purchaseDataProvider = new CActiveDataProvider('TransactionPurchaseOrder', array(
			'criteria'=>$purchaseCriteria,
		));

		$transfer = new TransactionTransferRequest('search');
      	$transfer->unsetAttributes();  // clear any default values
      	if (isset($_GET['TransactionTransferRequest']))
        	$transfer->attributes = $_GET['TransactionTransferRequest'];

		$transferCriteria = new CDbCriteria;
		$transferCriteria->compare('transfer_request_no',$transfer->transfer_request_no.'%',true,'AND', false);
		$transferCriteria->addCondition("status_document != 'Approved' AND requester_branch_id = ".$branchId);
		if ($status_document) 
			$transferCriteria->addCondition("status_document = '".$status_document."'");
		$transferCriteria->addBetweenCondition('t.transfer_request_date', $tanggal_mulai, $tanggal_sampai);
		$transferCriteria->order = 'transfer_request_date DESC';
		$transferDataProvider = new CActiveDataProvider('TransactionTransferRequest', array(
			'criteria'=>$transferCriteria,
		));

		$sent = new TransactionSentRequest('search');
      	$sent->unsetAttributes();  // clear any default values
      	if (isset($_GET['TransactionSentRequest']))
        	$sent->attributes = $_GET['TransactionSentRequest'];

		$sentCriteria = new CDbCriteria;
		$sentCriteria->compare('sent_request_no',$sent->sent_request_no.'%',true,'AND', false);
		$sentCriteria->addCondition("status_document != 'Approved' AND requester_branch_id = ".$branchId);
		if ($status_document) 
			$sentCriteria->addCondition("status_document = '".$status_document."'");
		$sentCriteria->addBetweenCondition('t.sent_request_date', $tanggal_mulai, $tanggal_sampai);
		$sentCriteria->order = 'sent_request_date DESC';
		$sentDataProvider = new CActiveDataProvider('TransactionSentRequest', array(
			'criteria'=>$sentCriteria,
		));

		$sales = new TransactionSalesOrder('search');
      	$sales->unsetAttributes();  // clear any default values
      	if (isset($_GET['TransactionSalesOrder']))
        	$sales->attributes = $_GET['TransactionSalesOrder'];

		$salesCriteria = new CDbCriteria;
		$salesCriteria->compare('sale_order_no',$sales->sale_order_no.'%',true,'AND', false);
		$salesCriteria->addCondition("status_document != 'Approved' AND requester_branch_id = ".$branchId);
		if ($status_document) 
			$salesCriteria->addCondition("status_document = '".$status_document."'");
		$salesCriteria->addBetweenCondition('t.sale_order_date', $tanggal_mulai, $tanggal_sampai);
		$salesCriteria->order = 'sale_order_date DESC';
		$salesDataProvider = new CActiveDataProvider('TransactionSalesOrder', array(
			'criteria'=>$salesCriteria,
		));

		$consignment = new ConsignmentOutHeader('search');
      	$consignment->unsetAttributes();  // clear any default values
      	if (isset($_GET['ConsignmentOutHeader']))
        	$consignment->attributes = $_GET['ConsignmentOutHeader'];

		$consignmentCriteria = new CDbCriteria;
		$consignmentCriteria->compare('consignment_out_no',$consignment->consignment_out_no.'%',true,'AND', false);
		$consignmentCriteria->addCondition("status != 'Approved' AND branch_id = ".$branchId);
		if ($status_document) 
			$consignmentCriteria->addCondition("status = '".$status_document."'");
		$consignmentCriteria->addBetweenCondition('t.date_posting', $tanggal_mulai, $tanggal_sampai);
		$consignmentCriteria->order = 'date_posting DESC';
		$consignmentDataProvider = new CActiveDataProvider('ConsignmentOutHeader', array(
			'criteria'=>$consignmentCriteria,
		));
		$consignmentIn = new ConsignmentInHeader('search');
      	$consignmentIn->unsetAttributes();  // clear any default values
      	if (isset($_GET['ConsignmentInHeader']))
        	$consignmentIn->attributes = $_GET['ConsignmentInHeader'];

		$consignmentInCriteria = new CDbCriteria;
		$consignmentInCriteria->compare('consignment_in_number',$consignmentIn->consignment_in_number.'%',true,'AND', false);
		$consignmentInCriteria->addCondition("status_document != 'Approved' AND receive_branch = ".$branchId);
		if ($status_document) 
			$consignmentInCriteria->addCondition("status_document = '".$status_document."'");
		$consignmentInCriteria->addBetweenCondition('t.date_posting', $tanggal_mulai, $tanggal_sampai);
		$consignmentInCriteria->order = 'date_posting DESC';
		$consignmentInDataProvider = new CActiveDataProvider('ConsignmentInHeader', array(
			'criteria'=>$consignmentInCriteria,
		));

		$movement = new MovementOutHeader('search');
      	$movement->unsetAttributes();  // clear any default values
      	if (isset($_GET['MovementOutHeader']))
        	$movement->attributes = $_GET['MovementOutHeader'];

		$movementCriteria = new CDbCriteria;
		$movementCriteria->compare('movement_out_no',$movement->movement_out_no.'%',true,'AND', false);
		$movementCriteria->addCondition("status != 'Approved' AND branch_id = ".$branchId);
		if ($status_document) 
			$movementCriteria->addCondition("status = '".$status_document."'");
		$movementCriteria->addBetweenCondition('t.date_posting', $tanggal_mulai, $tanggal_sampai);
		$movementCriteria->order = 'date_posting DESC';
		$movementDataProvider = new CActiveDataProvider('MovementOutHeader', array(
			'criteria'=>$movementCriteria,
		));
		$movementIn = new MovementInHeader('search');
      	$movementIn->unsetAttributes();  // clear any default values
      	if (isset($_GET['MovementInHeader']))
        	$movementIn->attributes = $_GET['MovementInHeader'];

		$movementInCriteria = new CDbCriteria;
		$movementInCriteria->compare('movement_in_number',$movementIn->movement_in_number.'%',true,'AND', false);
		$movementInCriteria->addCondition("status != 'Approved' AND branch_id = ".$branchId);
		if ($status_document) 
			$movementInCriteria->addCondition("status = '".$status_document."'");
		$movementInCriteria->addBetweenCondition('t.date_posting', $tanggal_mulai, $tanggal_sampai);
		$movementInCriteria->order = 'date_posting DESC';
		$movementInDataProvider = new CActiveDataProvider('MovementInHeader', array(
			'criteria'=>$movementInCriteria,
		));

		$this->render('index',array(
			'tanggal_mulai' =>$tanggal_mulai,
			'tanggal_sampai' => $tanggal_sampai,
			'status_document' =>$status_document,
			'model'=>$model,
			'sent'=>$sent,
			'sentDataProvider'=>$sentDataProvider,
			'sales'=>$sales,
			'salesDataProvider'=>$salesDataProvider,
			'request'=>$request,
			'requestDataProvider'=>$requestDataProvider,
			'purchase'=>$purchase,
			'purchaseDataProvider'=>$purchaseDataProvider,
			'consignment'=>$consignment,
			'consignmentDataProvider'=>$consignmentDataProvider,
			'consignmentIn'=>$consignmentIn,
			'consignmentInDataProvider'=>$consignmentInDataProvider,
			'transfer'=>$transfer,
			'transferDataProvider'=>$transferDataProvider,
			'movement'=>$movement,
			'movementDataProvider'=>$movementDataProvider,
			'movementIn'=>$movementIn,
			'movementInDataProvider'=>$movementInDataProvider,

		));
	}

	
}

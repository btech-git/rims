<?php

class CashTransactionController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column1';
	public $defaultAction = 'admin';

	/**
	 * @return array action filters
	 */
	// public function filters()
	// {
	// 	return array(
	// 		'accessControl', // perform access control for CRUD operations
	// 		'postOnly + delete', // we only allow deletion via POST request
	// 	);
	// }

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$details = CashTransactionDetail::model()->findAllByAttributes(array('cash_transaction_id'=>$id));
		$revisionHistories = CashTransactionApproval::model()->findAllByAttributes(array('cash_transaction_id'=>$id));
		$postImages = CashTransactionImages::model()->findAllByAttributes(array('cash_transaction_id'=>$id,'is_inactive'=>0));
		$this->render('view',array(
			'model'=>$this->loadModel($id),
			'details'=>$details,
			'postImages'=>$postImages,
			'revisionHistories'=>$revisionHistories,
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		//$model=new CashTransaction;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
		$cashTransaction = $this->instantiate(null);
      	$this->performAjaxValidation($cashTransaction->header);

		$coaKas = new Coa('search');
      	$coaKas->unsetAttributes();  // clear any default values
      	if (isset($_GET['Coa']))
        	$coaKas->attributes = $_GET['Coa'];
		$coaKasCriteria = new CDbCriteria;
		$coaKasCriteria->addCondition("(coa_sub_category_id = 2 OR id = 3 OR id = 183) AND coa_id = 0");
		$coaKasCriteria->compare('code',$coaKas->code.'%',true,'AND', false);
		$coaKasCriteria->compare('name',$coaKas->name,true);
		$coaKasCriteria->compare('normal_balance',$coaKas->normal_balance,true);
	  	$coaKasDataProvider = new CActiveDataProvider('Coa', array(
	    	'criteria'=>$coaKasCriteria,
	  	));

	  	$coaDetail = new Coa('search');
      	$coaDetail->unsetAttributes();  // clear any default values
      	if (isset($_GET['Coa']))
        	$coaDetail->attributes = $_GET['Coa'];
		$coaDetailCriteria = new CDbCriteria;
		//$coaDetailCriteria->addCondition("(coa_sub_category_id IN (6,7,8,10,12,13,15,16,17,18,20,21,22,26,27,28,29,31,32,33,34,35,36,37,38,39,42) OR cash_transaction = 'YES' AND id != 3 AND id != 13 AND id != 183) AND coa_id = 0 ");
		$coaDetailCriteria->addCondition("(coa_sub_category_id IN (2,6,7,10,12,14,15,17,19,20,21,23,24,25,29,30,31,32,33,34,35,36,37,38,39,40,41,42,45,53,54)) AND coa_id = 0 ");
		$coaDetailCriteria->compare('code',$coaDetail->code.'%',true,'AND', false);
		$coaDetailCriteria->compare('name',$coaDetail->name,true);
		$coaDetailCriteria->compare('normal_balance',$coaDetail->normal_balance,true);
		$coaDetailCriteria->order = 'code ASC';
	  	$coaDetailDataProvider = new CActiveDataProvider('Coa', array(
	    	'criteria'=>$coaDetailCriteria,
	  	));	
	  	$images = $cashTransaction->header->images = CUploadedFile::getInstances($cashTransaction->header, 'images');
		if(isset($_POST['CashTransaction']))
		{
			// $model->attributes=$_POST['CashTransaction'];
			// if($model->save())
			// 	$this->redirect(array('view','id'=>$model->id));
			$this->loadState($cashTransaction);
			if ($cashTransaction->save(Yii::app()->db)){
				if(isset($images) && !empty($images)) {
		    		foreach($cashTransaction->header->images as $i=>$image)
		    		{
		    			$postImage = new CashTransactionImages;
		    			$postImage->cash_transaction_id = $cashTransaction->header->id;
						$postImage->is_inactive = 0;
		    			$postImage->extension = $image->extensionName;

		    			if($postImage->save()){
		    				$dir = dirname(Yii::app()->request->scriptFile). '/images/uploads/cashTransaction/' . $cashTransaction->header->id;

		    				if(!file_exists($dir)){
		    					mkdir($dir,0777,true);
		    				}
		    				$path = $dir . '/' . $postImage->filename;
		    				$image->saveAs($path);
		    				$picture = Yii::app()->image->load($path);
		    				$picture->save();

		    				$thumb = Yii::app()->image->load($path);
		    				$thumb_path = $dir . '/' . $postImage->thumbname;
		    				$thumb->save($thumb_path);

		    				$square = Yii::app()->image->load($path);
		    				$square_path = $dir . '/' . $postImage->squarename;
		    				$square->save($square_path);
		    			}

		    		}
	    		}
      			$this->redirect(array('view', 'id' => $cashTransaction->header->id));
      		}
		}
		


		$this->render('create',array(
			//'model'=>$model,
			'cashTransaction'=>$cashTransaction,
			'coaKas'=>$coaKas,
			'coaKasDataProvider'=>$coaKasDataProvider,
			'coaDetail'=>$coaDetail,
			'coaDetailDataProvider'=>$coaDetailDataProvider,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		//$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
		$cashTransaction = $this->instantiate($id);
      	$this->performAjaxValidation($cashTransaction->header);

      	$coaKas = new Coa('search');
      	$coaKas->unsetAttributes();  // clear any default values
      	if (isset($_GET['Coa']))
        	$coaKas->attributes = $_GET['Coa'];
		$coaKasCriteria = new CDbCriteria;
		$coaKasCriteria->addCondition("(coa_sub_category_id = 2 OR id = 3 OR id = 183) AND coa_id = 0");
		$coaKasCriteria->compare('code',$coaKas->code.'%',true,'AND', false);
		$coaKasCriteria->compare('name',$coaKas->name,true);
		$coaKasCriteria->compare('normal_balance',$coaKas->normal_balance,true);
	  	$coaKasDataProvider = new CActiveDataProvider('Coa', array(
	    	'criteria'=>$coaKasCriteria,
	  	));

	  	$coaDetail = new Coa('search');
      	$coaDetail->unsetAttributes();  // clear any default values
      	if (isset($_GET['Coa']))
        	$coaDetail->attributes = $_GET['Coa'];
		$coaDetailCriteria = new CDbCriteria;
		//$coaDetailCriteria->addCondition("(coa_sub_category_id IN (6,7,8,10,12,13,15,16,17,18,20,21,22,26,27,28,29,31,32,33,34,35,36,37,38,39,42) OR cash_transaction = 'YES' AND id != 3 AND id != 13 AND id != 183) AND coa_id = 0 ");
		$coaDetailCriteria->addCondition("(coa_sub_category_id IN (2,6,7,10,12,14,15,17,19,20,21,23,24,25,29,30,31,32,33,34,35,36,37,38,39,40,41,42,45,53,54)) AND coa_id = 0 ");
		$coaDetailCriteria->compare('code',$coaDetail->code.'%',true,'AND', false);
		$coaDetailCriteria->compare('name',$coaDetail->name,true);
		$coaDetailCriteria->compare('normal_balance',$coaDetail->normal_balance,true);
		$coaDetailCriteria->order = 'code ASC';
	  	$coaDetailDataProvider = new CActiveDataProvider('Coa', array(
	    	'criteria'=>$coaDetailCriteria,
	  	));	

	  	$images = $cashTransaction->header->images = CUploadedFile::getInstances($cashTransaction->header, 'images');
	  	$postImages = CashTransactionImages::model()->findAllByAttributes(array('cash_transaction_id' => $cashTransaction->header->id, 'is_inactive'=> 0));
		$countPostImage = count($postImages);
		$maxImage = 10;
		$allowedImages = $maxImage - $countPostImage;
		
		if(isset($_POST['CashTransaction']))
		{
			// $model->attributes=$_POST['CashTransaction'];
			// if($model->save())
			// 	$this->redirect(array('view','id'=>$model->id));

			$this->loadState($cashTransaction);

			if ($cashTransaction->save(Yii::app()->db)){
				if(isset($images) && !empty($images)) {
		    		foreach($cashTransaction->header->images as $i=>$image)
		    		{
		    			$postImage = new CashTransactionImages;
		    			$postImage->cash_transaction_id = $cashTransaction->header->id;
						$postImage->is_inactive = 0;
		    			$postImage->extension = $image->extensionName;

		    			if($postImage->save()){
		    				$dir = dirname(Yii::app()->request->scriptFile). '/images/uploads/cashTransaction/' . $cashTransaction->header->id;

		    				if(!file_exists($dir)){
		    					mkdir($dir,0777,true);
		    				}
		    				$path = $dir . '/' . $postImage->filename;
		    				$image->saveAs($path);
		    				$picture = Yii::app()->image->load($path);
		    				$picture->save();

		    				$thumb = Yii::app()->image->load($path);
		    				$thumb_path = $dir . '/' . $postImage->thumbname;
		    				$thumb->save($thumb_path);

		    				$square = Yii::app()->image->load($path);
		    				$square_path = $dir . '/' . $postImage->squarename;
		    				$square->save($square_path);
		    			}

		    		}
	    		}
      			$this->redirect(array('view', 'id' => $cashTransaction->header->id));
      		}
		}

		$this->render('update',array(
			//'model'=>$model,
			'cashTransaction'=>$cashTransaction,
			'coaKas'=>$coaKas,
			'coaKasDataProvider'=>$coaKasDataProvider,
			'coaDetail'=>$coaDetail,
			'coaDetailDataProvider'=>$coaDetailDataProvider,
			'postImages' => $postImages,
			'allowedImages' => $allowedImages,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('CashTransaction');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new CashTransaction('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['CashTransaction']))
			$model->attributes=$_GET['CashTransaction'];

		$this->render('admin',array(
			'model'=>$model,
		));
	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return CashTransaction the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=CashTransaction::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param CashTransaction $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='cash-transaction-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
	public function actionAjaxCoa($id){
        if (Yii::app()->request->isAjaxRequest)
        {
            $coa = Coa::model()->findByPk($id);

            $object = array(
        		'id' => $coa->id,
                'code' => $coa->code,
                'name' => $coa->name,
                'opening_balance' => !empty($coa->opening_balance)?$coa->opening_balance:0,
                'debit' => !empty($coa->debit)?$coa->debit:0,
                'credit' => !empty($coa->credit)?$coa->credit:0,
            );

            echo CJSON::encode($object);
        }
  	}

  	public function instantiate($id)
	{
		if (empty($id)){
			$cashTransaction = new Cashs(new CashTransaction(), array());
		}
		else
		{
			$cashTransactionModel = $this->loadModel($id);
			$cashTransaction = new Cashs($cashTransactionModel, $cashTransactionModel->cashTransactionDetails);
			//print_r("test");
		}
		return $cashTransaction;
	}

	public function loadState($cashTransaction)
	{
		if (isset($_POST['CashTransaction']))
		{
			$cashTransaction->header->attributes = $_POST['CashTransaction'];
		}


		if (isset($_POST['CashTransactionDetail']))
		{
			foreach ($_POST['CashTransactionDetail'] as $i => $item)
			{
				if (isset($cashTransaction->details[$i])){
					$cashTransaction->details[$i]->attributes = $item;

				}

				else
				{
					$detail = new CashTransactionDetail();
					$detail->attributes = $item;
					$cashTransaction->details[] = $detail;
					
				}
			}
			if (count($_POST['CashTransactionDetail']) < count($cashTransaction->details))
				array_splice($cashTransaction->details, $i + 1);
		}
		else
		{
			$cashTransaction->details = array();

		}

	}
	//Add Detail
	public function actionAjaxHtmlAddDetail($id,$coaId)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			$cashTransaction = $this->instantiate($id); 	
			$this->loadState($cashTransaction);
			
			$cashTransaction->addDetail($coaId);
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
   			Yii::app()->clientscript->scriptMap['jquery.js'] = false;
   			Yii::app()->clientscript->scriptMap['jquery.yiigridview.js'] = false;
      		$this->renderPartial('_detail', array('cashTransaction'=>$cashTransaction
      	), false, true);
		}
	}
	public function actionAjaxHtmlRemoveDetail($id, $index)
	{
		if (Yii::app()->request->isAjaxRequest)
		{

			$cashTransaction = $this->instantiate($id);
			$this->loadState($cashTransaction);

			$cashTransaction->removeDetailAt($index);
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
      		Yii::app()->clientscript->scriptMap['jquery.js'] = false;
      		Yii::app()->clientscript->scriptMap['jquery.yiigridview.js'] = false;
			$this->renderPartial('_detail', array('cashTransaction'=>$cashTransaction
      		), false, true);
		}
	}
	public function actionDeleteImage($id)
	{
		$model = CashTransactionImages::model()->findByPk($id);
		$model->scenario = 'delete';

		$dir = dirname(Yii::app()->request->scriptFile) . '/images/uploads/cashTransaction/' . $model->cash_transaction_id . '/' . $model->filename;
		$dir_thumb = dirname(Yii::app()->request->scriptFile) . '/images/uploads/cashTransaction/' . $model->cash_transaction_id . '/' . $model->thumbname;
		$dir_square = dirname(Yii::app()->request->scriptFile) .'/images/uploads/cashTransaction/' . $model->cash_transaction_id . '/' . $model->squarename;

		if(file_exists($dir))
		{
			unlink($dir);
		}
		if(file_exists($dir_thumb))
		{
			unlink($dir_thumb);
		}
		if(file_exists($dir_square))
		{
			unlink($dir_square);
		}

		$model->is_inactive = 1;
		$model->update(array('is_inactive'));

		$this->redirect(Yii::app()->request->urlReferrer);
	}
	public function actionAjaxGetTotal($id)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			$cashTransaction = $this->instantiate($id);
			$this->loadState($cashTransaction);
			//$requestType =$requestOrder->header->request_type;
			$total = 0;
			
			foreach ($cashTransaction->details as $key => $detail) {
				$total += $detail->amount;
				
			}				
			$object = array('total'=>$total);
			echo CJSON::encode($object);

		}

	}
	public function actionUpdateApproval($headerId)
	{
		$cashTransaction = CashTransaction::model()->findByPK($headerId);
		$historis = CashTransactionApproval::model()->findAllByAttributes(array('cash_transaction_id'=>$headerId));
		$model = new CashTransactionApproval;
		$branch = Branch::model()->findByPk($cashTransaction->branch_id);
		$getCoa ="";
		$getCoaDetail="";
		//$model = $this->loadModelDetail($detailId);
		if(isset($_POST['CashTransactionApproval']))
		{
			$model->attributes=$_POST['CashTransactionApproval'];
			if ($model->save()){
				$cashTransaction->status = $model->approval_type;
				$cashTransaction->save(false);
				if($model->approval_type == "Approved"){
					$coa = Coa::model()->findByPk($cashTransaction->coa_id);
					
					$getCoa = $branch->coa_prefix.'.'.$coa->code;
					$coaWithCode = Coa::model()->findByAttributes(array('code'=>$getCoa));
					if($cashTransaction->transaction_type == "In")
					{
						$jurnalUmum = new JurnalUmum;
						$jurnalUmum->kode_transaksi = $cashTransaction->transaction_number;
						$jurnalUmum->tanggal_transaksi = $cashTransaction->transaction_date;
						$jurnalUmum->coa_id = $coaWithCode->id;
						$jurnalUmum->total = $cashTransaction->credit_amount;
						$jurnalUmum->debet_kredit = 'D';
						$jurnalUmum->tanggal_posting = date('Y-m-d');
						$jurnalUmum->branch_id = $cashTransaction->branch_id;
						$jurnalUmum->save();
					}
					else{
						$jurnalUmum = new JurnalUmum;
						$jurnalUmum->kode_transaksi = $cashTransaction->transaction_number;
						$jurnalUmum->tanggal_transaksi = $cashTransaction->transaction_date;
						$jurnalUmum->coa_id = $coaWithCode->id;
						$jurnalUmum->total = $cashTransaction->debit_amount;
						$jurnalUmum->debet_kredit = 'K';
						$jurnalUmum->tanggal_posting = date('Y-m-d');
						$jurnalUmum->branch_id = $cashTransaction->branch_id;
						$jurnalUmum->save();
					}
					foreach ($cashTransaction->cashTransactionDetails as $key => $ctDetail) {
							// $c = Coa::model()->findByPk($ctDetail->coa_id);
							$coaDetail = Coa::model()->findByPk($ctDetail->coa_id);
							$getCoaDetail = $branch->coa_prefix.'.'.$coaDetail->code;
							$coaDetailWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaDetail));
							
							if($cashTransaction->transaction_type == "In")
							{
								
								$jurnalUmum = new JurnalUmum;
								$jurnalUmum->kode_transaksi = $cashTransaction->transaction_number;
								$jurnalUmum->tanggal_transaksi = $cashTransaction->transaction_date;
								$jurnalUmum->coa_id = $coaDetailWithCode->id;
								$jurnalUmum->total = $ctDetail->amount;
								$jurnalUmum->debet_kredit = 'K';
								$jurnalUmum->tanggal_posting = date('Y-m-d');
								$jurnalUmum->branch_id = $cashTransaction->branch_id;
								$jurnalUmum->save(false);
							}
							else{
								
								$jurnalUmum = new JurnalUmum;
								$jurnalUmum->kode_transaksi = $cashTransaction->transaction_number;
								$jurnalUmum->tanggal_transaksi = $cashTransaction->transaction_date;
								$jurnalUmum->coa_id = $coaDetailWithCode->id;
								$jurnalUmum->total = $ctDetail->amount;
								$jurnalUmum->debet_kredit = 'D';
								$jurnalUmum->tanggal_posting = date('Y-m-d');
								$jurnalUmum->branch_id = $cashTransaction->branch_id;
								$jurnalUmum->save(false);
							}
							//echo $getCoaDetail;
						}
					//echo $coaWithCode->id;
					//echo $getCoa;
					

				}
				$this->redirect(array('view', 'id' => $headerId));
			}
		}
		
		$this->render('updateApproval',array(
			'model'=>$model,
			'cashTransaction'=>$cashTransaction,
			'historis'=>$historis,
			//'jenisPersediaan'=>$jenisPersediaan,
			//'jenisPersediaanDataProvider'=>$jenisPersediaanDataProvider,
		));
	}
	public function actionAjaxGetCount($coaId, $amount, $type){
		if (Yii::app()->request->isAjaxRequest)
		{
			$coa = Coa::model()->findByPk($coaId);
			if ($type == "In"){
				$total = $coa->credit + $amount;
			}
			else{
				$total = $coa->debit + $amount;
			}
			$object = array('total'=>$total);
			echo CJSON::encode($object);

		}
	}

}

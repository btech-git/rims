<?php
/* @var $this PaymentInController */
/* @var $model PaymentIn */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'payment-in-form',
	'htmlOptions' =>array('enctype' => 'multipart/form-data'),
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<div class="small-12 medium-6 columns">

			

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($model,'payment_number'); ?>
					</div>
					<div class="small-8 columns">
						<?php echo $form->textField($model,'payment_number',array('size'=>50,'maxlength'=>50)); ?>
						<?php echo $form->error($model,'payment_number'); ?>
					</div>
				</div>
			</div>		

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($model,'payment_date'); ?>
					</div>
					<div class="small-8 columns">
						<?php //echo $form->textField($model,'payment_date'); ?>
						<?php $this->widget('zii.widgets.jui.CJuiDatePicker',array(
											'model' => $model,
											'attribute' => "payment_date",
											'options'=>array(
												'dateFormat' => 'yy-mm-dd',
												'changeMonth'=>true,
												'changeYear'=>true,
												'yearRange'=>'1900:2020'
												),
											'htmlOptions'=>array(
												'value'=>date('Y-m-d'),
						                        //'value'=>$customer->header->isNewRecord ? '' : Customer::model()->findByPk($customer->header->id)->birthdate,
												),
											));
								?>
						<?php echo $form->error($model,'payment_date'); ?>
					</div>
				</div>
			</div>

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($model,'payment_type'); ?>
					</div>
					<div class="small-8 columns">
						<?php echo $form->dropDownlist($model,'payment_type',array('Cash'=>'Cash','Direct Bank Transfer'=>'Direct Bank Transfer','Giro'=>'Giro'),array('prompt'=>'[--Select Payment Type--]',
						'onchange'=>'
									clearAll();
									if($(this).val() == "Giro") {
										$(".giro").show();
										$(".cash").hide();
										$(".bank").hide();
									}
									else if($(this).val() == "Cash"){
										$(".giro").hide();
										$(".cash").show();
										$(".bank").hide();
									}
									else{
										$(".giro").hide();
										$(".cash").hide();
										$(".bank").hide();
									}
									
						')); ?>
						<?php echo $form->error($model,'payment_type'); ?>
					</div>
				</div>
			</div>

			<div class="giro">
		<div class="field">
			<div class="row collapse">
				<div class="small-4 columns">
					<?php echo $form->labelEx($model,'nomor_giro'); ?>
				</div>
				<div class="small-8 columns">
					<?php echo $form->textField($model,'nomor_giro',array('maxlength'=>20,'size'=>20)); ?>
					<?php echo $form->error($model,'nomor_giro'); ?>
				</div>
			</div>
		</div>
	</div>
	
	<div class="cash">
		<div class="field">
			<div class="row collapse">
				<div class="small-4 columns">
					<?php echo $form->labelEx($model,'cash_payment_type'); ?>
				</div>
				<div class="small-8 columns">
					<?php echo $form->dropDownlist($model,'cash_payment_type',array('1'=>'Cash','2'=>'Debit','3'=>'Credit Card'),array('prompt'=>'[--Select Cash Payment Type--]',
						'onchange'=>'
									$("#PaymentIn_bank_id").val("");
									if($(this).val() == "1") {
										$(".bank").hide();
									}
									else{
										$(".bank").show();
									}
									
						')); ?>
					<?php echo $form->error($model,'cash_payment_type'); ?>
				</div>
			</div>
		</div>
	</div>
	<div class="bank">
		<div class="field">
			<div class="row collapse">
				<div class="small-4 columns">
					<?php echo $form->labelEx($model,'bank_id'); ?>
				</div>
				<div class="small-8 columns">
					<?php echo $form->dropDownlist($model,'bank_id',CHtml::listData(Bank::model()->findAll(),'id','name'),array('prompt'=>'[--Select Bank--]',
								)); ?>
					<?php echo $form->error($model,'bank_id'); ?>
				</div>
			</div>
		</div>
	</div>	

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($model,'user_id'); ?>
					</div>
					<div class="small-8 columns">
						<?php echo $form->hiddenField($model,'user_id',array('value'=>$model->isNewRecord ?  Yii::app()->user->getId() : $model->user_id,'readonly'=>true)); ?>
						<?php echo $form->textField($model,'user_name',array('size'=>30,'maxlength'=>30,'value'=>$model->isNewRecord ?Yii::app()->user->getName() : $model->user_name,'readonly'=>true)); ?>
						<?php echo $form->error($model,'user_id'); ?>
					</div>
				</div>
			</div>		

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($model,'status'); ?>
					</div>
					<div class="small-8 columns">
						<?php echo $form->textField($model,'status',array('value'=>$model->isNewRecord ?  'Draft' : $model->status,'readonly'=>true)); ?>
						<?php echo $form->error($model,'status'); ?>
					</div>
				</div>
			</div>	

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($model,'branch_id'); ?>
					</div>
					<div class="small-8 columns">
						<?php //echo $form->textField($model,'branch_id',array('size'=>50,'maxlength'=>50)); ?>
						<?php echo $form->dropDownlist($model,'branch_id',CHtml::listData(Branch::model()->findAll(),'id','name'),array('prompt'=>'[--Select Branch--]',
										'onchange'=> 'jQuery.ajax({
												type: "POST",
												url: "' . CController::createUrl('ajaxGetCompanyBank') . '",
												data: jQuery("form").serialize(),
												success: function(data){
										    	console.log(data);
										    	jQuery("#PaymentIn_company_bank_id").html(data);
											},
										});')); ?>
						<?php echo $form->error($model,'branch_id'); ?>
					</div>
				</div>
			</div>

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($model,'company_bank_id'); ?>
					</div>
					<div class="small-8 columns">
						<?php echo $form->dropDownlist($model,'company_bank_id',array(),array('prompt'=>'[--Select Company Bank--]',
								
						)); ?>
						<?php echo $form->error($model,'company_bank_id'); ?>
					</div>
				</div>
			</div>			

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($model,'invoice_id'); ?>
					</div>
					<div class="small-8 columns">
						<?php echo $form->hiddenField($model,'invoice_id'); ?>
						<?php echo $form->textField($model,'invoice_number',array('readonly'=>true,'onclick' => 'jQuery("#invoice-dialog").dialog("open"); return false;','value'=>$model->invoice_id != "" ?InvoiceHeader::model()->findByPk($model->invoice_id)->invoice_number : '')) ?>
						<?php echo $form->error($model,'invoice_id'); ?>
					</div>
				</div>
			</div>

			
		</div>
	</div>
	
	<div class="row">
		<div class="large-12 columns">
			<div class="detail">
			<fieldset>
				<h1>Invoice Detail</h1>
				<div id="invoice-Detail">
					<fieldset>
						<legend>Invoice</legend>
						<div class="large-4 columns">
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Invoice Date</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" id="Invoice_invoice_date" value="<?php echo $model->invoice_id != "" ? $model->invoice->invoice_date :'' ?>" > 
									</div>
								</div>
							</div>
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Due Date </span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" id="Invoice_due_date" value="<?php echo $model->invoice_id != "" ? $model->invoice->due_date :'' ?>"> 
									</div>
								</div>
							</div>
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Status</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" id="Invoice_status" value="<?php echo $model->invoice_id != "" ? $model->invoice->status :'' ?>"> 
									</div>
								</div>
							</div>
						</div>
						<div class="large-4 columns">
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Reference Type</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" id="Invoice_reference_type" value="<?php echo $model->invoice_id != "" ? $model->invoice->reference_type :'' ?>"> 
									</div>
								</div>
							</div>
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Reference Number</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" id="Invoice_reference_number"> 
									</div>
								</div>
							</div>
							
						</div>
						<div class="large-4 columns">
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Invoice Amount</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" id="Invoice_total_price" value="<?php echo $model->invoice_id != "" ? $model->invoice->total_price :'0,00' ?>"> 
									</div>
								</div>
							</div>
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Payment Amount</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" id="Invoice_payment_amount" value="<?php echo $model->invoice_id != "" ? $model->invoice->payment_amount : '0,00' ?>"> 
									</div>
								</div>
							</div>
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Payment Left</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" id="Invoice_payment_left" value="<?php echo $model->invoice_id != "" ? $model->invoice->payment_left : '0,00' ?>"> 
									</div>
								</div>
							</div>
						</div>
					</fieldset>
				</div>

				<div id="customer">
					<fieldset>
						<legend>Customer</legend>
			
						
							<div class="large-6 columns">

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Name</span>
										</div>
										<div class="small-8 columns">
											<?php echo $form->hiddenField($model,'customer_id',array('readonly'=>true)); ?>
											<input type="text" readonly="true" id="Customer_customer_name" value="<?php echo $model->invoice_id != "" ? $model->invoice->customer->name :'' ?>"> 
										</div>
									</div>
								</div>

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Type</span>
										</div>
										<div class="small-8 columns">
											<input type="text" readonly="true" id="Customer_customer_type" value="<?php echo $model->customer_id != "" ? $model->invoice->customer->customer_type :'' ?>"> 
										</div>
									</div>
								</div>

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Address</span>
										</div>
										<div class="small-8 columns">
											<textarea name="" id="Customer_customer_address" cols="30" rows="5" readonly="true"><?php echo $model->customer_id != "" ? $model->customer->address. '&#13;&#10;'. $model->customer->province->name . '&#13;&#10;'. $model->customer->city->name.'&#13;&#10;'.$model->customer->zipcode : ''; ?></textarea>
										</div>
									</div>
								</div>

								


							</div> <!-- end div large -->
						
						
							<div class="large-6 columns">

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Phone</span>
										</div>
										<div class="small-8 columns">
											<?php $getPhone = ""; ?>
											<?php if ($model->customer_id != ""): ?>
												<?php $phones = CustomerPhone::model()->findAllByAttributes(array('customer_id'=>$model->customer_id,'status'=>'Active')); ?>
												
												<?php if (count($phones) > 0): ?>
													
													<?php foreach ($phones as $key => $phone): ?>
														<?php $getPhone = $phone->phone_no . '&#13;&#10;';  ?>
														<!-- <input type="text" readonly="true" value="<?php //?>">  -->
													<?php endforeach ?>
													</textarea>
												
												<?php endif ?>
												
											<?php endif ?>
											<textarea name="" id="Customer_phones" cols="30" rows="5" readonly="true"><?php echo $getPhone; ?></textarea>
											
											
											
										</div>
									</div>
								</div>
								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Mobile</span>
										</div>
										<div class="small-8 columns">
										<?php $getMobile = "" ?>
										<?php if ($model->customer_id != ""): ?>
											<?php $mobiles = CustomerMobile::model()->findAllByAttributes(array('customer_id'=>$model->customer_id,'status'=>'Active')); ?>
											
											<?php if (count($mobiles) > 0): ?>
												
												<?php foreach ($mobiles as $key => $mobile): ?>
													<?php $getMobile .= $mobile->mobile_no. '&#13;&#10;'; ?>
													
												<?php endforeach ?>
												
											
												
											<?php endif ?>
											
										<?php endif ?>
											
											<textarea name="" id="Customer_mobiles" cols="30" rows="5" readonly="true"><?php echo $getMobile ?></textarea>
											
										</div>
									</div>
								</div>
								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Email</span>
										</div>
										<div class="small-8 columns">
											<input type="text" readonly="true" id="Customer_email" value="<?php echo $model->customer_id != "" ? $model->customer->email : ''; ?>"> 
										</div>
									</div>
								</div>
							
						</div>
					</fieldset>
				</div>

				<div id="vehicle">
					<fieldset>
						<legend>Vehicle</legend>
						
						<?php 
							$vehicleId = $plate = $machine = $frame = $chasis = $power =$carMake = $carModel = $carSubModel = $carColor = "";
							if($model->vehicle_id != ""){
								$vehicle = Vehicle::model()->findByPk($model->vehicle_id);
								if (count($vehicle) != 0) {
									$vehicleId = $vehicle->id;
									$plate = $vehicle->plate_number != ""? $vehicle->plate_number : '';
									$machine = $vehicle->machine_number != "" ? $vehicle->machine_number :  '';
									$frame = $vehicle->frame_number != "" ? $vehicle->frame_number : '';
									$chasis = $vehicle->chasis_code != "" ? $vehicle->chasis_code : '';
									$power = $vehicle->power != "" ? $vehicle->power : '';
									$carMake = $vehicle->car_make_id != "" ? $vehicle->carMake->name : '';
									$carModel = $vehicle->car_model_id != "" ? $vehicle->carModel->name : '';
									$carSubModel = $vehicle->car_sub_model_detail_id != "" ?$vehicle->carSubModel->name : '';
									$carColor = $vehicle->color_id != "" ? Colors:: model()->findByPk($vehicle->color_id)->name : '';

								}
							}
						 ?>
							<div class="large-6 columns">

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Plate Number</span>
										</div>
										<div class="small-8 columns">
											<?php echo $form->hiddenField($model,'vehicle_id',array('readonly'=>true)); ?>
											<input type="text" readonly="true" id="Vehicle_plate_number" value="<?php echo $plate != "" ? $plate : ''; ?>"> 
										</div>
									</div>
								</div>

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Machine Number</span>
										</div>
										<div class="small-8 columns">
											<input type="text" readonly="true" id="Vehicle_machine_number" value="<?php echo $machine != "" ? $machine : ''; ?>"> 
										</div>
									</div>
								</div>

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Frame Number</span>
										</div>
										<div class="small-8 columns">
											<input type="text" readonly="true" id="Vehicle_frame_number" value="<?php echo $frame != "" ? $frame : ''; ?>"> 
										</div>
									</div>
								</div>
	
								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Chasis Code</span>
										</div>
										<div class="small-8 columns">
											<input type="text" readonly="true" id="Vehicle_chasis_code" value="<?php echo $chasis != "" ? $chasis : ''; ?>"> 
											
											
										</div>
									</div>
								</div>
								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Power CC</span>
										</div>
										<div class="small-8 columns">
											<input type="text" readonly="true" id="Vehicle_power" value="<?php echo $power != "" ? $power : ''; ?>"> 
											
											
										</div>
									</div>
								</div>


							</div> <!-- end div large -->
						
						
							<div class="large-6 columns">

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Car Make</span>
										</div>
										<div class="small-8 columns">
											<input type="text" readonly="true" id="Vehicle_car_make_name" value="<?php echo $carMake != "" ? $carMake : ''; ?>"> 
											
											
										</div>
									</div>
								</div>
								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Car Model</span>
										</div>
										<div class="small-8 columns">
											<input type="text" readonly="true" id="Vehicle_car_model_name" value="<?php echo $carModel != "" ? $carModel : ''; ?>"> 
											
											
										</div>
									</div>
								</div>
								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Car Sub Model</span>
										</div>
										<div class="small-8 columns">
											<input type="text" readonly="true" id="Vehicle_car_sub_model_name" value="<?php echo $carSubModel != "" ? $carSubModel : ''; ?>"> 
											
											
										</div>
									</div>
								</div>

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Color</span>
										</div>
										<div class="small-8 columns">
										<?php //$color = Colors::model()->findByPK($model->vehicle->color_id); ?>
											<input type="text" readonly="true" id="Vehicle_car_color_name" value="<?php echo $carColor != "" ? $carColor : ''; ?>"> 
											
											
										</div>
									</div>
								</div>
							</div><!-- end div large -->
						
					
					</fieldset>
				</div>

				
			</fieldset>
				
			</div>

		</div>
	</div>
	<div class="row">
		<div class="small-12 medium-6 columns">

		<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($model,'payment_amount'); ?>
					</div>
					<div class="small-8 columns">
						<?php echo $form->textField($model,'payment_amount',array('size'=>18,'maxlength'=>18,'readonly'=>$model->isNewRecord ? false : true,
							'onchange'=>'
								var relCount = $("#PaymentIn_invoice_id").attr("rel");
								var count = 0;
								var paymentAmount = $("#PaymentIn_payment_amount").val();
								var invoiceAmount = $("#Invoice_total_price").val();
								var invoiceLeft = $("#Invoice_payment_left").val();
								console.log(paymentAmount);
								console.log(invoiceAmount);
								console.log(invoiceLeft);
								if(relCount == 1)
									count = invoiceAmount - paymentAmount;
								else
									count = invoiceLeft - paymentAmount;
								if(count < 0)
								{
									alert("Payment Amount could not be higher than Invoice Amount");
									$("#PaymentIn_payment_amount").val("");
								}

								')); ?>
						<?php echo $form->error($model,'payment_amount'); ?>
					</div>
				</div>
			</div>		

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($model,'notes'); ?>
					</div>
					<div class="small-8 columns">
						<?php echo $form->textArea($model,'notes',array('rows'=>6, 'cols'=>50)); ?>
						<?php echo $form->error($model,'notes'); ?>
					</div>
				</div>
			</div>

	<div class="field">
		<div class="row collapse">
			<div class="small-4 columns">
				<?php echo $form->labelEx($model,'images'); ?>
			</div>
			<div class="small-8 columns">
				<?php if ($model->isNewRecord): ?>
								<?php //echo $form->labelEx($model, 'images', array('class' => 'label')); ?>
								<?php
								$this->widget('CMultiFileUpload', array(
									'model' => $model,
									'attribute' => 'images',
									'accept' => 'jpg|jpeg|png|gif',
									'denied' => 'Only jpg, jpeg, png and gif are allowed',
									'max' => 10,
									'remove' => 'x',
	                				//'duplicate' => 'Already Selected',

										
									));
								?>
							<?php else:
								if ($allowedImages != 0): ?>
									<?php //echo $form->labelEx($model, 'images', array('class' => 'label')); ?>
									<?php
										$this->widget('CMultiFileUpload', array(
											'model' => $model,
											'attribute' => 'images',
											'accept' => 'jpg|jpeg|png|gif',
											'denied' => 'Only jpg, jpeg, png and gif are allowed',
											'max' => 10,
											'remove' => 'x',
			                    			//'duplicate' => 'Already Selected',

											
										));
									?>
								<?php endif;

								if ($postImages !== null): ?>
									<?php
										//$criteria = new CDbCriteria;
										//$criteria->select = 'max(`order`) AS max_order';
										//$row = ArticlesImages::model()->findByAttributes(array('article_id' => $model->id, 'status' => 1));

										//$count_banners = count($restaurantImages);

										//$down = SKINS . 'arrow_down.png';
										//$up = SKINS . 'arrow_up.png';
									?>
									<?php //print_r($postImages); ?>
									<?php foreach ($postImages as $postImage):
										$dir = dirname(Yii::app()->request->scriptFile) . '/images/uploads/paymentIn/' . $model->id . '/' . $postImage->filename;
										$src = Yii::app()->baseUrl . '/images/uploads/paymentIn/' . $model->id . '/' . $postImage->filename;
									?>
									<div class="row">
										<div class="small-3 columns">
											<div style="margin-bottom:.5rem">
												<?php echo CHtml::image($src, $model->payment_number . "Image"); ?>
											</div>
										</div>
										<div class="small-8 columns">
											<div style="padding:.375rem .5rem; border:1px solid #ccc; background:#fff; font-size:.8125rem; line-height:1.4; margin-bottom:.5rem;">
												<?php echo (Yii::app()->baseUrl . '/images/uploads/paymentIn/' . $model->id . '/' . $postImage->filename); ?>
											</div>
										</div>
										<div class="small-1 columns">
											<?php echo CHtml::link('x', array('deleteImage', 'id' => $postImage->id, 'payment_in_id' => $model->id), array('class'=>'deleteImg right','confirm' => 'Are you sure you want to delete this image?')); ?>
										</div>
									</div>
									<?php endforeach; ?>
								<?php endif;
							endif; ?>
				<?php echo $form->error($model,'images'); ?>
			</div>
		</div>
	</div>		

		<div class="field buttons text-center">
			<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save', array('class'=>'button cbutton')); ?>
		</div>
	</div>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->
<?php $this->beginWidget('zii.widgets.jui.CJuiDialog', array(
						'id' => 'invoice-dialog',
						'options' => array(
							'title' => 'Invoice',
							'autoOpen' => false,
							'width' => 'auto',
							'modal' => true,
							),)
						);
?>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'invoice-grid',
	// 'dataProvider'=>$vehicleDataProvider,
	'dataProvider'=>$invoiceDataProvider,
	'filter'=>$invoice,
	'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
	'pager'=>array(
		'cssFile'=>false,
		'header'=>'',
		),
	'selectionChanged'=>'js:function(id){
		jQuery("#PaymentIn_invoice_id").val(jQuery.fn.yiiGridView.getSelection(id));
		jQuery("#invoice-dialog").dialog("close");
		jQuery.ajax({
			type: "POST",
			dataType: "JSON",
			url: "' . CController::createUrl('ajaxInvoice', array('invoiceId'=> '')) . '" + jQuery.fn.yiiGridView.getSelection(id),
			data: $("form").serialize(),
			success: function(data) {

				jQuery("#PaymentIn_invoice_number").val(data.invoice_number);
				jQuery("#PaymentIn_customer_id").val(data.customer_id);
				jQuery("#PaymentIn_vehicle_id").val(data.vehicle_id);
				$("#PaymentIn_invoice_id").attr("rel",data.count);
				jQuery("#Invoice_invoice_date").val(data.invoice_number);
				jQuery("#Invoice_due_date").val(data.due_date);
				jQuery("#Invoice_reference_type").val(data.reference_type);
				jQuery("#Invoice_reference_number").val(data.reference_num);
				jQuery("#Invoice_status").val(data.status);
				jQuery("#Invoice_total_price").val(data.total_price);
				jQuery("#Invoice_payment_amount").val(data.payment_amount);
				jQuery("#Invoice_payment_left").val(data.payment_left);
				jQuery("#Customer_customer_name").val(data.customer_name);
				jQuery("#Customer_customer_type").val(data.type);
				jQuery("#Customer_customer_address").text(data.address+"\n"+data.province+"\n"+data.city );
				console.log(data.address+"\n"+data.province+"\n"+data.city);
				jQuery("#Customer_email").val(data.email);
				var phones = data.phones;
				jQuery("#Customer_phones").text("");
				jQuery("#Customer_mobiles").text("");
				for (i=0; i < phones.length; i++) { 
					console.log(phones[i]);
					var obj = phones[i];

					for(var prop in obj){
						if(obj.hasOwnProperty(prop)){
							if(prop == "phone_no"){
								console.log(prop + " = " + obj[prop]);
							 	jQuery("#Customer_phones").text(jQuery("#Customer_phones").val()+"\n"+obj[prop]);
							}
							 	
						}
					}
				}
				var mobiles = data.mobiles;
				for (i=0; i < mobiles.length; i++) { 
					console.log(mobiles[i]);
					var obj = mobiles[i];
					for(var prop in obj){
						if(obj.hasOwnProperty(prop)){
							if(prop == "mobile_no"){
								console.log(prop + " = " + obj[prop]);
							 	jQuery("#Customer_mobiles").text(jQuery("#Customer_mobiles").val()+"\n"+obj[prop]);
							}
							 	
						}
					}
				}
	
				jQuery("#Vehicle_plate_number").val(data.plate);
				jQuery("#Vehicle_machine_number").val(data.machine);
				jQuery("#Vehicle_frame_number").val(data.frame);
				jQuery("#Vehicle_chasis_code").val(data.chasis);
				jQuery("#Vehicle_power").val(data.power);
				jQuery("#Vehicle_car_make_name").val(data.carMake);
				jQuery("#Vehicle_car_model_name").val(data.carModel);
				jQuery("#Vehicle_car_sub_model_name").val(data.carSubModel);
				jQuery("#Vehicle_car_color_name").val(data.carColor);
				
				if($("#PaymentIn_customer_id").val() != ""){
					$(".detail").show();
					$("#invoice-Detail").show();
					$("#customer").show();
					$("#vehicle").hide();
				}
				if($("#PaymentIn_vehicle_id").val() != ""){
					$(".detail").show();
					$("#invoice-Detail").show();
					$("#customer").show();
					$("#vehicle").show();
				}
				

		
			},
		});

		jQuery("#invoice-grid").find("tr.selected").each(function(){
			$(this).removeClass( "selected" );
		});
	}',
	'columns'=>array(
			'invoice_number',
			'invoice_date',
			'due_date',
			'status',
			array('name'=>'reference_type','value'=>'$data->reference_type == 1 ? "Sales Order" : "Retail Sales"'),
			array('name'=>'customer_name','value'=>'$data->customer->name'),
			'total_price',
		),
	)
);
?>

<?php $this->endWidget('zii.widgets.jui.CJuiDialog'); ?>
<script>
	if (jQuery("#PaymentIn_invoice_id").val()== "") {
		$(".detail").hide();
		// $("#invoice-Detail").hide();
		// $("#customer").hide();
		// $("#vehicle").hide();
	}
	if($("#PaymentIn_customer_id").val() != ""){
		$(".detail").show();
		$("#invoice-Detail").show();
		$("#customer").show();
		$("#vehicle").hide();
	}
	if($("#PaymentIn_vehicle_id").val() != ""){
		$(".detail").show();
		$("#invoice-Detail").show();
		$("#customer").show();
		$("#vehicle").show();
	}

	if ($("#PaymentIn_payment_type").val()== "Giro") {
		$(".giro").show();
		$(".cash").hide();
		//$(".bank").hide();
		if ($("#PaymentIn_cash_payment_type").val()== "1") {
			$(".bank").hide();
		}
		else
			$(".bank").show();
		
	}
	else if($("#PaymentIn_payment_type").val()== "Cash"){
		$(".giro").hide();
		$(".cash").show();
		//$(".bank").hide();
		if ($("#PaymentIn_cash_payment_type").val()== "Cash") {
			$(".bank").hide();
		}
		else
			$(".bank").show();
		
	}
	else{
		$(".giro").hide();
		$(".cash").hide();
		$(".bank").hide();
	}
	function clearAll(){
		$("#PaymentIn_cash_payment_type").val("");
		$("#PaymentIn_nomor_giro").val("");
		$("#PaymentIn_bank_id").val("");
	}
</script>

<?php
	Yii::app()->clientScript->registerScriptFile(Yii::app()->baseUrl . '/js/vendor/jquery.number.min.js', CClientScript::POS_HEAD);
	Yii::app()->clientScript->registerScript('myjavascript', '
		$(".numbers").number( true,2, ".", ",");
    ', CClientScript::POS_END);
?>
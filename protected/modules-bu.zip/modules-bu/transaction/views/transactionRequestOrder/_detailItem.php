<div class="row">
	<div class="small-2 columns">
		<label class="prefix">Quantity</label>
	</div>
	<div class="small-3 columns">
		<?php echo CHtml::activeTextField($detail,"[$i]quantity"); ?>
	</div>
	<div class="small-1 columns">
	</div>
	<div class="small-2 columns">
		<label class="prefix">Discount Step</label>
	</div>
	<div class="small-3 columns">
		<?php echo CHtml::activeTextField($detail,"[$i]quantity"); ?>
	</div>
</div>
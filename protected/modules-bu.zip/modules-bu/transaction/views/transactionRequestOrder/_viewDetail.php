
	<?php $requestOrders = TransactionRequestOrderDetail::model()->findAllByAttributes(array('request_order_id'=>$model->id)); 
	foreach ($requestOrders as $requestOrder) : ?>
	<?php if ($requestOrder->supplier != NULL): ?>
		<fieldset>
		<legend><?php echo $requestOrder->supplier->name; ?></legend>
		<div class="row">
			<div class="large-12 columns">
				
					<div class="large-6 columns">

						

						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Product</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo $requestOrder->product->name; ?>"> 
								</div>
							</div>
						</div>

						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Unit</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo $requestOrder->unit_id; ?>"> 
								</div>
							</div>
						</div>

						
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Quantity</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo $requestOrder->quantity; ?>"> 
								</div>
							</div>
						</div>
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Total Quantity</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo $requestOrder->total_quantity; ?>"> 
								</div>
							</div>
						</div>
						
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Retail Price</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo number_format($requestOrder->retail_price,0); ?>"> 
								</div>
							</div>
						</div>

						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Last Buying Price</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo number_format($requestOrder->last_buying_price,0); ?>"> 
								</div>
							</div>
						</div>

						

					</div> <!-- end div large -->
				
				
					<div class="large-6 columns">

						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Discount step</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo $requestOrder->discount_step; ?>"> 
								</div>
							</div>
						</div>
						
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Discount</span>
								</div>
								<div class="small-8 columns">
									<?php $step = $requestOrder->discount_step; ?>
									<?php if ($step == 1): ?>
										<?php if ($requestOrder->discount1_type == 1){
												$type = "Percent";
												}
												elseif ($requestOrder->discount1_type == 2) {
													$type = "Nominal";
												}
												else{
													$type = "Bonus";
												}

											 ?>
											
										
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount1_nominal; ?>"> 
									<?php elseif($step == 2): ?>

										<input type="text" readonly="true" value="<?php echo $requestOrder->discount1_nominal; ?>"> 
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount2_nominal; ?>"> 
									<?php elseif($step == 3): ?>
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount1_nominal; ?>"> 
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount2_nominal; ?>"> 
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount3_nominal; ?>"> 
									<?php elseif($step == 4): ?>
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount1_nominal; ?>"> 
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount2_nominal; ?>"> 
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount3_nominal; ?>"> 
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount4_nominal; ?>"> 
									<?php elseif($step == 5): ?>
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount1_nominal; ?>"> 
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount2_nominal; ?>"> 
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount3_nominal; ?>"> 
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount4_nominal; ?>"> 
										<input type="text" readonly="true" value="<?php echo $requestOrder->discount5_nominal; ?>"> 
									<?php endif ?>
									
								</div>
							</div>
						</div>

						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Price</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo number_format($requestOrder->unit_price,0); ?>"> 
								</div>
							</div>
						</div>
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Subtotal</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo number_format($requestOrder->total_price,0); ?>"> 
								</div>
							</div>
						</div>
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Notes</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo $requestOrder->notes; ?>">
								</div>
							</div>
						</div>
					</div><!-- end div large -->
				
			</div>
		</div>

	</fieldset>
<?php else: ?>
	<?php echo "NO SUPPLIER" ?>
	<?php endif ?>
	
<?php endforeach ?>


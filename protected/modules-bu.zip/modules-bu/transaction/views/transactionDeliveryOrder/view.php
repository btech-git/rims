<?php
/* @var $this TransactionReceiveItemController */
/* @var $model TransactionReceiveItem */

$this->breadcrumbs=array(
	'Transaction Delivery Orders'=>array('admin'),
	$model->id,
);

$this->menu=array(
	array('label'=>'List TransactionDeliveryOrder', 'url'=>array('index')),
	array('label'=>'Create TransactionDeliveryOrder', 'url'=>array('create')),
	array('label'=>'Update TransactionDeliveryOrder', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Delete TransactionDeliveryOrder', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage TransactionDeliveryOrder', 'url'=>array('admin')),
);
?>
		<div id="maincontent">
			<div class="clearfix page-action">
			<?php $ccontroller = Yii::app()->controller->id; ?>
			<?php $ccaction = Yii::app()->controller->action->id; ?>
			<?php echo CHtml::link('<span class="fa fa-list"></span>Manage Delivery Order', Yii::app()->baseUrl.'/transaction/transactionDeliveryOrder/admin', array('class'=>'button cbutton right', 'visible'=>Yii::app()->user->checkAccess("transaction.transactionDeliveryOrder.admin"))) ?>
			
			<?php 
				$movements = MovementOutHeader::model()->findAllByAttributes(array('delivery_order_id'=>$model->id));
			if (count($movements) == 0): ?>
				<?php echo CHtml::link('<span class="fa fa-edit"></span>Edit', Yii::app()->baseUrl.'/transaction/transactionDeliveryOrder/update?id=' . $model->id, array('class'=>'button cbutton right','style'=>'margin-right:10px', 'visible'=>Yii::app()->user->checkAccess("transaction.transactionDeliveryOrder.update"))) ?>
			<?php else: ?>
			<?php echo CHtml::link('<span class="fa fa-edit"></span>Print', Yii::app()->baseUrl.'/transaction/transactionDeliveryOrder/pdf?id=' . $model->id, array('class'=>'button cbutton right','style'=>'margin-right:10px', 'visible'=>Yii::app()->user->checkAccess("transaction.transactionDeliveryOrder.pdf"))) ?>
			<?php endif ?>
			
			
			<h1>View Transaction Delivery Order #<?php echo $model->id; ?></h1>

			<?php $this->widget('zii.widgets.CDetailView', array(
					'data'=>$model,
					'attributes'=>array(
						'id',
						'delivery_order_no',
						'delivery_date',
						'posting_date',
						'sender_id',
						'sender_branch_id',
						'request_type',
						'sales_order_id',
						'sent_request_id',
						'request_date',
						'estimate_arrival_date',
						'destination_branch',
						'customer_id',
					),
				)); ?>

				</div>
		</div>
	<div class="detail">
	<hr>
	<h3>Details</h3>
	
		<?php if ($model->request_type =='Sales Order'): ?>
			<div class="row">
				<div class="small-12 columns">
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">SO no</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo $model->salesOrder != "" ? $model->salesOrder->sale_order_no : ''; ?></label>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Customer</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo $model->customer_id == NULL?'-':$model->customer->name; ?></label>
							</div>
						</div>
					</div>
				</div>
			</div>


		<?php elseif($model->request_type =='Sent Request'): ?>
			<div class="row">
				<div class="small-12 columns">
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Sent Request no</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo $model->sentRequest != NULL ? $model->sentRequest->sent_request_no : ''; ?></label>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Destination Branch</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo $model->destination_branch == NULL?'-':$model->destinationBranch->name; ?></label>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php elseif($model->request_type =='Consignment Out') : ?>
			<div class="row">
				<div class="small-12 columns">
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Consignment Out</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo $model->consignmentOut != NULL ? $model->consignmentOut->consignment_out_no : ''; ?></label>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Customer</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo $model->customer_id == NULL?'-':$model->customer->name; ?></label>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php elseif($model->request_type =='Transfer Request') : ?>
			<div class="row">
				<div class="small-12 columns">
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Transfer Request</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo $model->transferRequest != NULL ? $model->transferRequest->transfer_request_no : ''; ?></label>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Destination Branch</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo $model->destination_branch == NULL?'-':$model->destinationBranch->name; ?></label>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif ?>
		<br><br>
		<?php if (count($deliveryDetails)>0): ?>
			<table>
				<thead>
					<tr>
						<th>Product</th>
						<th>Quantity</th>
						<th>QTY Delivery</th>
						<th>QTY Left</th>
						<th>QTY Movement</th>
						<th>QTY Movement Left</th>
						<th>Note</th>
						<th>Barcode Product</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($deliveryDetails as $key => $deliveryDetail): ?>
						<tr>
							<td><?php echo $deliveryDetail->product->name == ''?'-':$deliveryDetail->product->name; ?></td>
							<td><?php echo $deliveryDetail->quantity_request == ''?'-':$deliveryDetail->quantity_request; ?></td>
							<td><?php echo $deliveryDetail->quantity_delivery== ''?'-':$deliveryDetail->quantity_delivery; ?></td>
							<td><?php echo $deliveryDetail->quantity_request_left== ''?'-':$deliveryDetail->quantity_request_left; ?></td>
							<td><?php echo $deliveryDetail->quantity_movement == ''?'-':$deliveryDetail->quantity_movement; ?></td>
							<td><?php echo $deliveryDetail->quantity_movement_left == ''?'-':$deliveryDetail->quantity_movement_left; ?></td>
							<td><?php echo $deliveryDetail->note== ''?'-':$deliveryDetail->note; ?></td>
							<td><?php echo $deliveryDetail->barcode_product == ''?'-':$deliveryDetail->barcode_product; ?></td>
							
						</tr>
					<?php endforeach ?>
				</tbody>
			</table>	
		<?php else: ?>
			<?php echo 'No Details Available'; ?>
		<?php endif ?>
		<hr />

		<?php if($model->request_type == 'Sales Order'){
			$itemHeaders= TransactionDeliveryOrder::model()->findAllByAttributes(array('sales_order_id'=>$model->sales_order_id));
	
			}elseif($model->request_type == 'Sent Request'){ ?>
			<?php $itemHeaders= TransactionDeliveryOrder::model()->findAllByAttributes(array('sent_request_id'=>$model->sent_request_id)); ?>
			<?php }else $itemHeaders= array(); ?>

			<?php if (count($itemHeaders)!= 0): ?>

				<table>
				<caption>History</caption>
				<thead>
					<tr>
						<td>Request No</td>
						<td>Product</td>
						<td>Qty Request</td>
						<td>Qty Delivery</td>
					
						<td>Qty Request Left</td>
						<td>Note</td>
						<td>Barcode</td>
					</tr>
				</thead>
				<tbody>
				<?php foreach ($itemHeaders as $key => $itemHeader): ?>
					<?php $deliveryDetails = TransactionDeliveryOrderDetail::model()->findAllByAttributes(array('delivery_order_id'=>$itemHeader->id)); ?>
					
					<?php foreach ($deliveryDetails as $key => $deliveryDetail): ?>
				
					<tr>
						<td><?php echo $deliveryDetail->deliveryOrder->delivery_order_no; ?></td>
						<td><?php echo $deliveryDetail->product->name; ?></td>
						<td><?php echo $deliveryDetail->quantity_request; ?></td>
						<td><?php echo $deliveryDetail->quantity_delivery; ?></td>
						<td><?php echo $deliveryDetail->quantity_request_left; ?></td>
						<td><?php echo $deliveryDetail->note; ?></td>
						<td><?php echo $deliveryDetail->barcode_product; ?></td>
					</tr>
				
				<?php endforeach ?>
			<?php endforeach ?>
			</tbody>
			</table>
			<?php endif ?>
	</div>
<?php
/* @var $this MovementOutHeaderController */
/* @var $model MovementOutHeader */

$this->breadcrumbs=array(
	'Movement Out Headers'=>array('admin'),
	'Manage',
);

/*$this->menu=array(
	array('label'=>'List MovementOutHeader', 'url'=>array('index')),
	array('label'=>'Create MovementOutHeader', 'url'=>array('create')),
);*/

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').slideToggle(600);
	$('.bulk-action').toggle();
	$(this).toggleClass('active');
	if($(this).hasClass('active')){
		$(this).text('');
	}else {
		$(this).text('Advanced Search');
	}
	return false;
});
$('.search-form form').submit(function(){
	$('#movement-out-header-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<!--<h1>Manage Movement Out Headers</h1>-->


<div id="maincontent">
	<div class="row">
		<div class="small-12 columns">
			<div class="clearfix page-action">
				<?php //echo CHtml::link('<span class="fa fa-list" ></span>Pending Order', Yii::app()->baseUrl.'/transaction/movementOutHeader/index', array('class'=>'button cbutton right','style'=>'margin-left:10px', 'visible'=>Yii::app()->user->checkAccess("transaction.movementOutHeader.index"))) ?>
				<?php echo CHtml::link('<span class="fa fa-plus"></span>New Movement Out', Yii::app()->baseUrl.'/transaction/movementOutHeader/create', array('class'=>'button success right', 'visible'=>Yii::app()->user->checkAccess("transaction.movementOutHeader.create"))) ?>
				<h2>Manage Movement Out Headers</h2>
			</div>

			<div class="search-bar">
				<div class="clearfix button-bar">
		  			<!--<div class="left clearfix bulk-action">
		         		<span class="checkbox"><span class="fa fa-reply fa-rotate-270"></span></span>
		         		<input type="submit" value="Archive" class="button secondary cbutton" name="archive">         
		         		<input type="submit" value="Delete" class="button secondary cbutton" name="delete">      
		         	</div>-->
					<?php echo CHtml::link('Advanced Search','#',array('class'=>'search-button right button cbutton secondary')); ?>					<div class="clearfix"></div>
					<div class="search-form" style="display:none">
					<?php $this->renderPartial('_search',array(
						'model'=>$model,
					)); ?>
					</div><!-- search-form -->
		        </div>
		    </div>
        	
        	<div class="grid-view">
				<?php $this->widget('zii.widgets.grid.CGridView', array(
					'id'=>'movement-out-header-grid',
					'dataProvider'=>$model->search(),
					'filter'=>$model,
					// 'summaryText'=>'',
					'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
					'pager'=>array(
					   'cssFile'=>false,
					   'header'=>'',
					),
					'columns'=>array(
					//'id',
					array('name'=>'movement_out_no', 'value'=>'CHTml::link($data->movement_out_no, array("view", "id"=>$data->id))', 'type'=>'raw'),
					//'movement_out_no',
					'date_posting',
					'status',
					// 'delivery_order_id',
					// 'branch_id',
	         			array(
	         				'name'=>'user_id',
	         				'value'=>'$data->user->username',
	         			),
						array(
							'name'=>'branch_name',
							'value'=>'$data->branch->name'
						),
						array(
							'name'=>'delivery_order_number',
							'value'=>'(!empty($data->deliveryOrder->delivery_order_no)?$data->deliveryOrder->delivery_order_no:"")'
						),
						array(
							'name'=>'return_order_number',
							'value'=>'(!empty($data->returnOrder->return_order_no)?$data->returnOrder->return_order_no:"")'
						),
					// 'user_id',
					/*
					'supervisor_id',
					'status',
					*/
						array(
							'class'=>'CButtonColumn',
							'template'=>'{edit}',
							'buttons'=>array
							(
								'edit' => array
								(
									'label'=>'edit',
									'url'=>'Yii::app()->createUrl("transaction/movementInHeader/update", array("id"=>$data->id))',
									'visible'=>'($data->status != "Approved") && ($data->status != "Delivered") && ($data->status != "Finished" ) && Yii::app()->user->checkAccess("transaction.movementOutHeader.update")',
										
									),
								),
							),
						
	         		),
	         		)); ?>
			</div>
			<fieldset>
				<legend>Pending Orders</legend>
				<h2>Delivery Orders</h2>
				<hr>
					<div class="grid-view">
						<?php $this->widget('zii.widgets.grid.CGridView', array(
							'id'=>'delivery-order-grid',
							'dataProvider'=>$deliveryOrder->search(),
							'filter'=>$deliveryOrder,
							// 'summaryText'=>'',
							'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
							'pager'=>array(
							   'cssFile'=>false,
							   'header'=>'',
							),
							'columns'=>array(
							//'id',
							array('name'=>'delivery_order_no', 'value'=>'CHTml::link($data->delivery_order_no, array("/transaction/transactionDeliveryOrder/view", "id"=>$data->id))', 'type'=>'raw'),
							'delivery_date',
							array('header'=>'Movements','value'=> function($data){
								foreach ($data->movementOutHeaders as $key => $movementDetail) {
									echo $movementDetail->movement_out_no. "<br>";
									
								}

							}
								
								
							),
							// 'user_id',
							/*
							'supervisor_id',
							'status',
							*/
								
			         		),
			         		)); ?>
					</div>
				<h2>Return Orders</h2>
				<hr>
					<div class="grid-view">
						<?php $this->widget('zii.widgets.grid.CGridView', array(
							'id'=>'return-order-grid',
							'dataProvider'=>$returnOrder->search(),
							'filter'=>$returnOrder,
							// 'summaryText'=>'',
							'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
							'pager'=>array(
							   'cssFile'=>false,
							   'header'=>'',
							),
							'columns'=>array(
							//'id',
							array('name'=>'return_order_no', 'value'=>'CHTml::link($data->return_order_no, array("/transaction/transactionReturnOrder/view", "id"=>$data->id))', 'type'=>'raw'),
							'return_order_date',
							array('header'=>'Movements','value'=> function($data){
								foreach ($data->movementOutHeaders as $key => $movementDetail) {
									echo $movementDetail->movement_out_no. "<br>";
									
								}

							}
								
								
							),
							// 'user_id',
							/*
							'supervisor_id',
							'status',
							*/
								
			         		),
			         		)); ?>
					</div>
				<h2>Retail Sales</h2>
				<hr>
					<div class="grid-view">
						<?php $this->widget('zii.widgets.grid.CGridView', array(
							'id'=>'retail-sale-grid',
							'dataProvider'=>$registrationTransactionDataProvider,
							'filter'=>$registrationTransaction,
							// 'summaryText'=>'',
							'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
							'pager'=>array(
							   'cssFile'=>false,
							   'header'=>'',
							),
							'columns'=>array(
							//'id',
							array('name'=>'transaction_number', 'value'=>'CHTml::link($data->transaction_number, array("/frontDesk/registrationTransaction/view", "id"=>$data->id))', 'type'=>'raw'),
							array('name'=>'transaction_date','value'=>'$data->transaction_date'),
							//'total_product',
							array('header'=>'Movements','value'=> function($data){
								foreach ($data->movementOutHeaders as $key => $movementDetail) {
									echo $movementDetail->movement_out_no. "<br>";
									
								}


							}
								
								
							),
							// 'user_id',
							/*
							'supervisor_id',
							'status',
							*/
								
			         		),
			         		)); ?>
					</div>
			</fieldset>
			
		</div>
	</div> <!-- end row -->
</div> <!-- end maintenance -->

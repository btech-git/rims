<fieldset>
			<legend>Details</legend>

			<table>
				<thead>
					<tr>
						<th>Product Name</th>
						<th>Warehouse</th>
						<th>Quantity Transaction</th>
						<th>Quantity</th>
						<th>Quantity On warehouse</th>
						<th>Status</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($details as $key => $detail): ?>
						<tr>
							<td><?php echo $detail->product->name; ?></td>
							<td><?php echo $detail->warehouse == "" ? "" : $detail->warehouse->name ?></td>
							<td><?php echo $detail->quantity_transaction; ?></td>
							<td><?php echo $detail->quantity; ?></td>
							<?php $stockInventory = Inventory::model()->findByAttributes(array('product_id'=>$detail->product_id,'warehouse_id'=>$detail->warehouse_id)); ?>
							<td><?php echo count($stockInventory)!= 0 ? $stockInventory->total_stock : ''; ?></td>
							<td><?php echo $stockInventory->total_stock > $detail->quantity ? 'V' : 'X'; ?></td>
						</tr>
					<?php endforeach ?>
				</tbody>
			</table>
		</fieldset>	
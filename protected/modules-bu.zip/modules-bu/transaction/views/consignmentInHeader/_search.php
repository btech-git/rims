<?php
/* @var $this ConsignmentInHeaderController */
/* @var $model ConsignmentInHeader */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model,'id'); ?>
		<?php echo $form->textField($model,'id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'consignment_in_number'); ?>
		<?php echo $form->textField($model,'consignment_in_number',array('size'=>30,'maxlength'=>30)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'date_posting'); ?>
		<?php echo $form->textField($model,'date_posting'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'status_document'); ?>
		<?php echo $form->textField($model,'status_document',array('size'=>30,'maxlength'=>30)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'supplier_id'); ?>
		<?php echo $form->textField($model,'supplier_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'date_arrival'); ?>
		<?php echo $form->textField($model,'date_arrival'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'receive_id'); ?>
		<?php echo $form->textField($model,'receive_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'receive_branch'); ?>
		<?php echo $form->textField($model,'receive_branch'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model,'total_price'); ?>
		<?php echo $form->textField($model,'total_price',array('size'=>18,'maxlength'=>18)); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Search'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->
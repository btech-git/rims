<?php if (count($consignmentIn->details)): ?>
	<table>
		<thead>
			<tr>
				<th>Product</th>
				<th>Quantity</th>
				<th>Price</th>
				<th>Total Price</th>
				<th>Note</th>
				<th>Barcode Product</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($consignmentIn->details as $i => $detail): ?>
				<tr>
					<td><?php echo CHtml::activeHiddenField($detail, "[$i]product_id", array('size'=>20,'maxlength'=>20)); ?>
							
							<?php echo CHtml::activeTextField($detail,"[$i]product_name",
								array(
									'size'=>15,
									'maxlength'=>10,
									//'onclick' => '$("#product'.$i.'-dialog").dialog("open"); return false;',
					            	'value' => $detail->product_id == "" ? '': Product::model()->findByPk($detail->product_id)->name
								)); ?>

							
					</td>
					<td><?php echo CHtml::activeTextField($detail,"[$i]quantity");?></td>
					<td><?php echo CHtml::activeTextField($detail,"[$i]price");?></td>
					<td><?php
							echo CHtml::button('Count', array(
							'id' => 'count_'.$i,
							'style'=>'display:none;',
							'onclick' =>'
								var qty = +$("#ConsignmentInDetail_'.$i.'_quantity").val();
								var price = +$("#ConsignmentInDetail_'.$i.'_price").val();

								var total = qty * price;
								$("#ConsignmentInDetail_'.$i.'_total_price").val(total);
								console.log(total);
							'));
						?>
						<?php echo CHtml::activeTextField($detail,"[$i]total_price");?></td>
					<td><?php echo CHtml::activeTextField($detail,"[$i]note");?></td>
					<td><?php echo CHtml::activeTextField($detail,"[$i]barcode_product");?></td>
					<td>
						<?php
						echo CHtml::button('X', array(
						'onclick' => CHtml::ajax(array(
							'type' => 'POST',
							'url' => CController::createUrl('ajaxHtmlRemoveDetail', array('id' => $consignmentIn->header->id, 'index' => $i)),
							'update' => '#product',
							)),
						));
						?>
					</td>
				</tr>	

				<?php
				Yii::app()->clientScript->registerScript('myjqueryCount'.$i,'
					$("#ConsignmentInDetail_'.$i.'_price,#ConsignmentInDetail_'.$i.'_quantity").keyup(function(event){
						$("#count_'.$i.'").click();
						$("#total-button").click();
					});
				');
				?>
			<?php endforeach ?>
		</tbody>
	</table>
<?php endif ?>


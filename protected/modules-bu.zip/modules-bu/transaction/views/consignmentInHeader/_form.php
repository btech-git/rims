<?php
/* @var $this ConsignmentInHeaderController */
/* @var $consignmentIn->header ConsignmentInHeader */
/* @var $form CActiveForm */
?>
<div class="clearfix page-action">
	<?php echo CHtml::link('<span class="fa fa-list"></span>Manage Consignment In', Yii::app()->baseUrl.'/transaction/consignmentInHeader/admin', array('class'=>'button cbutton right', 'visible'=>Yii::app()->user->checkAccess("transaction.consignmentInHeader.admin"))) ?>
	<h1><?php if($consignmentIn->header->id == ""){ echo "New Consignment In"; }else{ echo "Update Consignment In";}?></h1>
	<!-- begin FORM -->
	<div class="form">

		<?php $form=$this->beginWidget('CActiveForm', array(
			'id'=>'consignment-in-header-form',
			'enableAjaxValidation'=>false,
			)); ?>
			<?php //Yii::app()->clientScript->registerCoreScript('jquery'); ?>
			<?php //Yii::app()->clientScript->registerCoreScript('jquery.ui'); ?>
			<p class="note">Fields with <span class="required">*</span> are required.</p>

			<?php echo $form->errorSummary($consignmentIn->header); ?>
			
			<div class="row">
				<div class="large-6 columns">
			      <div class="row collapse prefix-radius">
			        <div class="small-4 columns">
			        	<?php echo $form->labelEx($consignmentIn->header,'consignment_in_number', array('class'=>'prefix')); ?>
			        </div>
			        <div class="small-8 columns">
			        	<?php echo $form->textField($consignmentIn->header,'consignment_in_number',array('size'=>30,'maxlength'=>30)); ?>
						<?php echo $form->error($consignmentIn->header,'consignment_in_number'); ?>
			        </div>
			      </div>
			    </div>

			    <div class="large-6 columns">
			      <div class="row collapse prefix-radius">
			        <div class="small-4 columns">
			          	<?php echo $form->labelEx($consignmentIn->header,'receive_id', array('class'=>'prefix')); ?>
			        </div>
			        <div class="small-8 columns">
			          	<?php echo $form->textField($consignmentIn->header,'receive_id',array('size'=>30,'maxlength'=>30,'value'=>$consignmentIn->header->isNewRecord ? Yii::app()->user->getId() : $consignmentIn->header->receive_id,'readonly'=>true)); ?>
						<?php echo $form->error($consignmentIn->header,'receive_id'); ?>
			        </div>
			      </div>
			    </div>

		    </div>

			<div class="row">
				<div class="large-6 columns">
			      <div class="row collapse prefix-radius">
			        <div class="small-4 columns">
			        	<?php echo $form->labelEx($consignmentIn->header,'date_posting', array('class'=>'prefix')); ?>
			        </div>
			        <div class="small-8 columns">
			        	<?php //echo $form->textField($consignmentIn->header,'date_posting',array('size'=>30,'maxlength'=>30)); ?>
			        	<?php $this->widget('zii.widgets.jui.CJuiDatePicker',array(
									'model' => $consignmentIn->header,
									'attribute' => "date_posting",
									'options'=>array(
										'dateFormat' => 'yy-mm-dd',
										'changeMonth'=>true,
										'changeYear'=>true,
										'yearRange'=>'1900:2020'
										),
									'htmlOptions'=>array(
										'value'=>date('Y-m-d'),
				                        //'value'=>$customer->header->isNewRecord ? '' : Customer::model()->findByPk($customer->header->id)->birthdate,
										),
									));
						?>
						<?php echo $form->error($consignmentIn->header,'date_posting'); ?>
			        </div>
			      </div>
			    </div>

			    <div class="large-6 columns">
			      <div class="row collapse prefix-radius">
			        <div class="small-4 columns">
			          	<?php echo $form->labelEx($consignmentIn->header,'receive_branch', array('class'=>'prefix')); ?>
			        </div>
			        <div class="small-8 columns">
			          	<?php //echo $form->textField($consignmentIn->header,'receive_branch',array('size'=>30,'maxlength'=>30)); ?>
			          	<?php echo $form->dropDownlist($consignmentIn->header,'receive_branch',CHtml::listData(Branch::model()->findAll(),'id','name'),array('prompt'=>'[--Select Branch--]')); ?>
						<?php echo $form->error($consignmentIn->header,'receive_branch'); ?>
			        </div>
			      </div>
			    </div>
			    
		    </div>

		    <div class="row">

				<div class="large-6 columns">
			      <div class="row collapse prefix-radius">
			        <div class="small-4 columns">
			        	<?php echo $form->labelEx($consignmentIn->header,'status_document', array('class'=>'prefix')); ?>
			        </div>
			        <div class="small-8 columns">
			        	<?php if($consignmentIn->header->isNewRecord){
									echo $form->textField($consignmentIn->header,'status_document',array('value'=>'Draft','readonly'=>true));
								}else{
									echo $form->dropDownList($consignmentIn->header, 'status_document', array('Draft'=>'Draft','Revised' => 'Revised','Rejected'=>'Rejected','Approved'=>'Approved','Done'=>'Done'),array('prompt'=>'[--Select Status Document--]'));
								} 
						?>
						<?php echo $form->error($consignmentIn->header,'status_document'); ?>
			        </div>
			      </div>
			    </div>

			   
			    
		    </div>

		    <div class="row">

				<div class="large-6 columns">
			      <div class="row collapse prefix-radius">
			        <div class="small-4 columns">
			        	<?php echo $form->labelEx($consignmentIn->header,'supplier_id', array('class'=>'prefix')); ?>
			        </div>
			        <div class="small-2 columns">
						<a class="button expand" href="<?php echo Yii::app()->baseUrl.'/master/supplier/create';?>"><span class="fa fa-plus"></span>Add</a>
					</div>	
			        <div class="small-6 columns">
			        	<?php echo CHtml::activeHiddenField($consignmentIn->header,'supplier_id'); ?>
								<?php echo CHtml::activeTextField($consignmentIn->header,'supplier_name',array(
									'size'=>15,
									'maxlength'=>10,
									'readonly'=>true,
										//'disabled'=>true,
									'onclick' => '$("#supplier-dialog").dialog("open"); return false;',
									'onkeypress' => 'if (event.keyCode == 13) { $("#supplier-dialog").dialog("open"); return false; }',
									'value' =>$consignmentIn->header->supplier_id == "" ? '': Supplier::model()->findByPk($consignmentIn->header->supplier_id)->name
									)
								);
								?>
									
						<?php echo $form->error($consignmentIn->header,'supplier_id'); ?>
			        </div>
			      </div>
			    </div>

		    </div>

		    <div class="row">

				<div class="large-6 columns">
			      <div class="row collapse prefix-radius">
			        <div class="small-4 columns">
			        	<?php echo $form->labelEx($consignmentIn->header,'date_arrival', array('class'=>'prefix')); ?>
			        </div>
			        <div class="small-8 columns">
			        	<?php $this->widget('zii.widgets.jui.CJuiDatePicker',array(
									'model' => $consignmentIn->header,
									'attribute' => "date_arrival",
									'options'=>array(
										'dateFormat' => 'yy-mm-dd',
										'changeMonth'=>true,
										'changeYear'=>true,
										'yearRange'=>'1900:2020'
										),
									'htmlOptions'=>array(
										'value'=>date('Y-m-d'),
				                        //'value'=>$customer->header->isNewRecord ? '' : Customer::model()->findByPk($customer->header->id)->birthdate,
										),
									));
						?>
			        	<?php //echo $form->textField($consignmentIn->header,'date_arrival',array('size'=>30,'maxlength'=>30)); ?>
						<?php echo $form->error($consignmentIn->header,'date_arrival'); ?>
			        </div>
			      </div>
			    </div>

		    </div>

		    <div class="row">

				<div class="large-6 columns">
			      <div class="row collapse prefix-radius">
			        <div class="small-4 columns">
			        	<?php echo $form->labelEx($consignmentIn->header,'total_price', array('class'=>'prefix')); ?>
			        </div>
			        <div class="small-8 columns">
			        	<?php echo $form->textField($consignmentIn->header,'total_price',array('size'=>18,'maxlength'=>18,'readonly'=>true)); ?>
						<?php echo $form->error($consignmentIn->header,'total_price'); ?>
			        </div>
			      </div>
			    </div>

			    <div class="large-6 columns">
			      <div class="row collapse prefix-radius">
			        <div class="small-4 columns">
			        	<?php echo $form->labelEx($consignmentIn->header,'total_quantity', array('class'=>'prefix')); ?>
			        </div>
			        <div class="small-8 columns">
			        	<?php echo $form->textField($consignmentIn->header,'total_quantity',array('readonly'=>true)); ?>
						<?php echo $form->error($consignmentIn->header,'total_quantity'); ?>
			        </div>
			      </div>
			    </div>

		    </div>
				
			<fieldset>
				<legend>Detail Product</legend>
				<div class="row">
					<div class="large-5 columns">
						<div class="small-4 columns">
							<?php echo CHtml::button('Add Details', array(
									'id' => 'detail-button',
									'name' => 'Detail',
									'style' =>'width:100%',
									
									'onclick' => '$("#product-dialog").dialog("open"); return false;
									jQuery.ajax({
										type: "POST",
										url: "' . CController::createUrl('ajaxHtmlAddDetail', array('id' => $consignmentIn->header->id)) . '",
										data: jQuery("form").serialize(),
										success: function(html) {
											jQuery("#product").html(html);
										},
									});')
								); ?>
						</div>
						<div class="small-4 columns">
							
							<?php 
								echo CHtml::button('Add New Product', array(
									'id' => 'detail-button',
									'name' => 'Detail',
									'style' =>'width:100%',
									//'target'=>'_blank',
									'onclick' => ' 
										window.location.href = "'.Yii::app()->baseUrl.'/master/product/create/"',
									
								
								 )
							); ?>
						</div>
						<div class="small-4 columns">
							
							<?php echo CHtml::button('Count Total', array(
									'id' => 'total-button',
									'name' => 'Total',
									'style' =>'width:100%',
									'onclick' => '
									$.ajax({
					                  type: "POST",
					                  url: "' . CController::createUrl('ajaxGetTotal', array('id' => $consignmentIn->header->id,)) . '",
					                  data: $("form").serialize(),
					                  dataType: "json",
					                  success: function(data) {
					                      //console.log(data.total);
					                  	//console.log(data.requestType);
					                      $("#ConsignmentInHeader_total_price").val(data.total);
					                      $("#ConsignmentInHeader_total_quantity").val(data.total_items);
					                      
					                  },
					                });',)); 
	                		?>
						
						</div>
					</div>
				</div>

				<br>
				<div class="row">
					<div class="large-12 columns">
						<div class="detail" id="product">
							<?php $this->renderPartial('_detail', array('consignmentIn'=>$consignmentIn,'product'=>$product,
									'productDataProvider'=>$productDataProvider,
								));
							?>
						</div>
					</div>	
				</div>
			</fieldset>
			

			<div class="row buttons text-center">
				<?php echo CHtml::submitButton($consignmentIn->header->isNewRecord ? 'Create' : 'Save', array('class'=>'button cbutton')); ?>
			</div>

			<?php $this->endWidget(); ?>
		
	</div><!-- form -->
</div>


<?php $this->beginWidget('zii.widgets.jui.CJuiDialog', array(
	'id' => 'supplier-dialog',
	// additional javascript options for the dialog plugin
	'options' => array(
		'title' => 'Supplier',
		'autoOpen' => false,
		'width' => 'auto',
		'modal' => true,
		),)
);
?>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'supplier-grid',
	// 'dataProvider'=>$supplierDataProvider,
	'dataProvider'=>$supplier->search(),
	'filter'=>$supplier,
	'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
	'pager'=>array(
		'cssFile'=>false,
		'header'=>'',
		),
	'selectionChanged'=>'js:function(id){
		$("#ConsignmentInHeader_supplier_id").val($.fn.yiiGridView.getSelection(id));
		$("#supplier-dialog").dialog("close");
		$.ajax({
			type: "POST",
			dataType: "JSON",
			url: "' . CController::createUrl('ajaxSupplier', array('id' => '')) . '" + $.fn.yiiGridView.getSelection(id),
			data: $("form").serialize(),
			success: function(data) {
				$("#ConsignmentInHeader_supplier_name").val(data.name);	
				$.updateGridView("product-grid", "Product[product_supplier]", data.name);      	                        	
				                      	
			},
		});
		
	}',
	'columns'=>array(
		'id',
		'name',
		// array('name'=>'product_name','value'=>'$data->product_name'),
		)
	)
); ?>
<?php $this->endWidget(); ?>
<?php $this->beginWidget('zii.widgets.jui.CJuiDialog', array(
	'id' => 'product-dialog',
	// additional javascript options for the dialog plugin
	'options' => array(
		'title' => 'Product',
		'autoOpen' => false,
		'width' => 'auto',
		'modal' => true,
		),));
?>
<div class="row">
<!-- <div class="small-3 columns">
	<input placeholder="Find By Keyword" style="margin-bottom:0px;" name="Product[findkeyword]" id="Product_findkeyword" type="text">
		<?php //echo $form->textField($product,'findkeyword', array('placeholder'=>'Find By Keyword', "style"=>"margin-bottom:0px;")); ?>
	</div>	
</div> -->
<div class="row">
	<div class="small-12 columns" style="padding-left: 0px; padding-right: 0px;">
	
	<?php $this->widget('zii.widgets.grid.CGridView', array(
		'id'=>'product-grid',
		'dataProvider'=>$productDataProvider,
		'filter'=>$product,
		'template' => '<div style="overflow-x:scroll ; overflow-y: hidden; margin-bottom: 1.25rem;">{items}</div><div class="clearfix">{summary}{pager}</div>',
		'pager'=>array(
			'cssFile'=>false,
			'header'=>'',
			),
		'selectionChanged'=>'js:function(id){

			$("#product-dialog").dialog("close");
			$.ajax({
				type: "POST",
				dataType: "html",
				url: "' . CController::createUrl('ajaxHtmlAddDetail', array('id'=>$consignmentIn->header->id,'productId'=>'')). '" + $.fn.yiiGridView.getSelection(id),
				data: $("form").serialize(),
				success: function(data) {
					$("#product").html(data);
				},
			});

			$("#product-grid").find("tr.selected").each(function(){
				$(this).removeClass( "selected" );
			});
		}',
		'columns'=>array(
			'id',
			array('name'=>'name', 'value'=>'$data->name'),
			'manufacturer_code',
			array('name'=>'product_master_category_name', 'value'=>'$data->productMasterCategory->name'),
			array('name'=>'product_sub_master_category_name', 'value'=>'$data->productSubMasterCategory->name'),
			array('name'=>'product_sub_category_name', 'value'=>'$data->productSubCategory->name'),
			'production_year',
			array('name'=>'product_brand_name', 'value'=>'$data->brand->name'),
			array('name'=>'product_supplier','value'=>'$data->product_supplier'),
			),
			));?>
	</div>
</div>
<?php $this->endWidget(); ?>
<?php 
	Yii::app()->clientScript->registerScript('search',"
	
		
    	$('#Product_findkeyword').keypress(function(e) {
		    if(e.which == 13) {
				$.fn.yiiGridView.update('product-grid', {
					data: $(this).serialize()
				});
		        return false;
		    	//alert('test');
		    }
		});
		
       

		
    ");
 ?>
<?php
	Yii::app()->clientScript->registerScript('updateGridView', '
	$.updateGridView = function(gridID, name, value) {
		$("#"+gridID+" input[name=\""+name+"\"], #"+gridID+" select[name=\""+name+"\"]").val(value);
		$.fn.yiiGridView.update(gridID, {data: $.param(
			$("#"+gridID+" .filters input, #"+gridID+" .filters select")
			)});
		}
	', CClientScript::POS_READY);
?>
<?php
/* @var $this TransactionReceiveItemController */
/* @var $model TransactionReceiveItem */

$this->breadcrumbs=array(
	'Transaction Return Item'=>array('admin'),
	$model->id,
);

$this->menu=array(
	array('label'=>'List TransactionReturnItem', 'url'=>array('index')),
	array('label'=>'Create TransactionReturnItem', 'url'=>array('create')),
	array('label'=>'Update TransactionReturnItem', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Delete TransactionReturnItem', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage TransactionReturnItem', 'url'=>array('admin')),
);
?>



		<div id="maincontent">
			<div class="clearfix page-action">
			<?php $ccontroller = Yii::app()->controller->id; ?>
				<?php $ccaction = Yii::app()->controller->action->id; ?>
			<?php echo CHtml::link('<span class="fa fa-list"></span>Manage Return Item', Yii::app()->baseUrl.'/transaction/transactionReturnItem/admin', array('class'=>'button cbutton right', 'visible'=>Yii::app()->user->checkAccess("transaction.transactionReturnItem.admin"))) ?>
			
			<?php $movements = MovementInHeader::model()->findAllByAttributes(array('return_item_id'=>$model->id));
				if (count($movements)== 0):
			 ?>
				<?php echo CHtml::link('<span class="fa fa-edit"></span>Edit', Yii::app()->baseUrl.'/transaction/transactionReturnItem/update?id=' . $model->id, array('class'=>'button cbutton right','style'=>'margin-right:10px', 'visible'=>Yii::app()->user->checkAccess("transaction.transactionReturnItem.update"))) ?>
				
			
			<?php endif ?>
			<?php echo CHtml::link('<span class="fa fa-edit"></span>Update Approval', Yii::app()->baseUrl.'/transaction/transactionReturnItem/updateApproval?headerId=' . $model->id , array('class'=>'button cbutton right','style'=>'margin-right:10px', 'visible'=>Yii::app()->user->checkAccess("transaction.transactionReturnItem.updateApproval"))) ?>
			<h1>View Transaction Return Item #<?php echo $model->id; ?></h1>

			<?php $this->widget('zii.widgets.CDetailView', array(
				'data'=>$model,
				'attributes'=>array(
					'id',
					'return_item_no',
					'return_item_date',
					'arrival_date',
					'recipient_id',
					'recipient_branch_id',
					'request_type',
					'estimate_arrival_date',
					
				),
			)); ?>

				</div>
		</div>
	<div class="detail">
	<hr>
	<h3>Details</h3>
	
		<?php if ($model->request_type =='Sales Order'): ?>
			<div class="row">
				<div class="small-12 columns">
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">SO no</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo $model->salesOrder->sale_order_no; ?></label>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Customer</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo count($model->customer)== 0?'-':$model->customer->name; ?></label>
							</div>
						</div>
					</div>
				</div>
			</div>


		<?php elseif($model->request_type =='Sent Request'): ?>
			<div class="row">
				<div class="small-12 columns">
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Sent Request no</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo $model->sentRequest->sent_request_no; ?></label>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Destination Branch</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo count($model->destinationBranch)== 0?'-':$model->destinationBranch->name; ?></label>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php elseif($model->request_type =='Transfer Request'): ?>
			<div class="row">
				<div class="small-12 columns">
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Transfer Request no</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo $model->transferRequest->transfer_request_no; ?></label>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Destination Branch</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo count($model->destinationBranch)== 0?'-':$model->destinationBranch->name; ?></label>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php elseif ($model->request_type =='Consignment Out'): ?>
			<div class="row">
				<div class="small-12 columns">
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Consignment Out no</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo $model->consignmentOut->consignment_out_no; ?></label>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label for="label">Customer</label>
							</div>
							<div class="small-8 columns">
								<label for="label"><?php echo count($model->customer)== 0?'-':$model->customer->name; ?></label>
							</div>
						</div>
					</div>
				</div>
			</div>
		<?php endif ?>

		<?php if (count($returnDetails)>0): ?>
			<table>
				<thead>
					<tr>
						<td>Product</td>
						<td>Quantity</td>
						<td>Quantity Return</td>
						<!-- <td>QTY Left</td> -->
						<td>Note</td>
						<td>Barcode Product</td>
						<td>Quantity Movement</td>
						<td>Quantity Movement Left</td>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($returnDetails as $key => $returnDetail): ?>
						<tr>
							<td><?php echo $returnDetail->product->name == ''?'-':$returnDetail->product->name; ?></td>
							<td><?php echo $returnDetail->quantity == ''?'-':$returnDetail->quantity; ?></td>
							<td><?php echo $returnDetail->quantity_delivery== ''?'-':$returnDetail->quantity_delivery; ?></td>
							<!-- <td><?php //echo $returnDetail->quantity_left== ''?'-':$returnDetail->quantity_left; ?></td> -->
							<td><?php echo $returnDetail->note== ''?'-':$returnDetail->note; ?></td>
							<td><?php echo $returnDetail->barcode_product == ''?'-':$returnDetail->barcode_product; ?></td>
							<td><?php echo $returnDetail->quantity_movement; ?></td>
							<td><?php echo $returnDetail->quantity_movement_left; ?></td>
						</tr>
					<?php endforeach ?>
				</tbody>
			</table>	
		<?php else: ?>
			<?php echo 'No Details Available'; ?>
		<?php endif ?>
		<hr />
	</div>
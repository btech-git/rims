	<?php if(count($returnItem->details) != 0) {	?>
	<table>
		<thead>
	
			<tr>
				<td>Product</td>
				<td>Return Type</td>
				<td>Quantity</td>
				<td>Qty Return</td>
				<!-- <td>Qty Left</td> -->
				<td>Note</td>
				<td>Barcode</td>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($returnItem->details as $i => $detail): ?>
				<tr>
					<td><?php echo CHtml::activeHiddenField($detail,"[$i]product_id");  ?>
							<?php $product = Product::model()->findByPK($detail->product_id); ?>
							<?php echo CHtml::activeTextField($detail,"[$i]product_name",array('value'=>$product->name,'readOnly'=>true));  ?>
					</td>
					<td><?php echo CHtml::activeTextField($detail,"[$i]quantity_delivery",array('readOnly'=>true));  ?></td>
					<td><?php echo CHtml::activeTextField($detail,"[$i]quantity",array(
					//'onchange'=>
								// 'var quantity = +jQuery("#TransactionReturnItemDetail_'.$i.'_quantity").val();
								// var delivery = +jQuery("#TransactionReturnItemDetail_'.$i.'_quantity_delivery").val();
								// //alert(quantity);
								// var count = quantity- delivery;
								// jQuery("#TransactionReturnItemDetail_'.$i.'_quantity_left").val(count);
								// console.log(count);
								// '
					));  ?>
					<?php echo CHtml::activeHiddenField($detail,"[$i]price");  ?>
					</td>
					<!-- <td><?php //echo CHtml::activeTextField($detail,"[$i]quantity_left",array('readOnly'=>true));  ?></td> -->
					<td><?php echo CHtml::activeTextField($detail,"[$i]note");  ?></td>
					<td><?php echo CHtml::activeTextField($detail,"[$i]barcode_product"); ?></td>
					<td>
							<?php
						    echo CHtml::button('X', array(
						     	'onclick' => CHtml::ajax(array(
							       	'type' => 'POST',
							       	'url' => CController::createUrl('ajaxHtmlRemoveDetail', array('id' => $returnItem->header->id, 'index' => $i)),
							       	'update' => '.detail',
					      		)),
					     	));
				     	?>
						</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
		
	</table>
	<?php } ?>
	
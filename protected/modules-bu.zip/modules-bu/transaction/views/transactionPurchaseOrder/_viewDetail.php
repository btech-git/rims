<?php //$ccontroller = Yii::app()->controller->id; ?>
<?php foreach ($purchaseOrderDetails as $key => $purchaseOrderDetail): ?>
	<table>
		<tr>
			<td width="10%">Product</td>
			<?php $product = Product::model()->findByPK($purchaseOrderDetail->product_id); ?>
			<td width="75%"><?php echo $product->name; ?></td>
			
		</tr>
		<tr>
			<?php $detailRequests = TransactionPurchaseOrderDetailRequest::model()->findAllByAttributes(array('purchase_order_detail_id'=>$purchaseOrderDetail->id)); ?>
			<td colspan="3">
				<table>
					<tr>
						<td>Purchase Request no</td>
						<td>PR Quantity</td>
						<td>ETA</td>
						<td>Branch</td>
						<td>PO Quantity</td>
						<td>Notes</td>

					</tr>
					<?php foreach ($detailRequests as $key => $detailRequest): ?>
						<?php $requestOrder = TransactionRequestOrder::model()->findByPK($detailRequest->purchase_request_id);  ?>
						<?php $requestOrderDetail = TransactionRequestOrderDetail::model()->findByPK($detailRequest->purchase_request_detail_id);  ?>
						<?php $branch = Branch::model()->findByPK($detailRequest->purchase_request_branch_id);  ?>
						<tr>
							<td><?php echo $requestOrder->request_order_no; ?></td>
							<td><?php echo $detailRequest->purchase_request_quantity; ?></td>
							<td><?php echo $detailRequest->estimate_date_arrival; ?></td>
							<td><?php echo $branch->name; ?></td>
							<td><?php echo $detailRequest->purchase_order_quantity; ?></td>
							<td><?php echo $detailRequest->notes; ?></td>
						</tr>
					<?php endforeach ?>
					
				</table>
			</td>
			
		</tr>
		<tr>
			<td>Quantity</td>
			<td colspan="2"><?php echo $purchaseOrderDetail->quantity; ?></td>
		</tr>
		<tr>
			<td>Unit</td>
			<td colspan="2"><?php echo $purchaseOrderDetail->unit_id; ?></td>
		</tr>
		
		<tr>
			<td>Discount step</td>
			<td colspan="2"><?php echo $purchaseOrderDetail->discount_step != ""? $purchaseOrderDetail->discount_step : '-'; ?></td>
		</tr>
		<tr>
			<td>Discounts </td>
			<td colspan="2">
				<?php if ($purchaseOrderDetail->discount_step == 1): ?>

					<?php echo $purchaseOrderDetail->discount1_nominal; ?>
				<?php elseif($purchaseOrderDetail->discount_step == 2): ?>
					<?php echo $purchaseOrderDetail->discount1_nominal. '<br>'; ?>
					<?php echo $purchaseOrderDetail->discount2_nominal; ?>
				<?php elseif($purchaseOrderDetail->discount_step == 3): ?>
					<?php echo $purchaseOrderDetail->discount1_nominal. '<br>'; ?>
					<?php echo $purchaseOrderDetail->discount2_nominal. '<br>'; ?>
					<?php echo $purchaseOrderDetail->discount3_nominal; ?>
				<?php elseif($purchaseOrderDetail->discount_step == 4): ?>
					<?php echo $purchaseOrderDetail->discount1_nominal. '<br>'; ?>
					<?php echo $purchaseOrderDetail->discount2_nominal. '<br>'; ?>
					<?php echo $purchaseOrderDetail->discount3_nominal. '<br>'; ?>
					<?php echo $purchaseOrderDetail->discount4_nominal; ?>
				<?php elseif($purchaseOrderDetail->discount_step == 5): ?>
					<?php echo $purchaseOrderDetail->discount1_nominal. '<br>'; ?>
					<?php echo $purchaseOrderDetail->discount2_nominal. '<br>'; ?>
					<?php echo $purchaseOrderDetail->discount3_nominal. '<br>'; ?>
					<?php echo $purchaseOrderDetail->discount4_nominal. '<br>'; ?>
					<?php echo $purchaseOrderDetail->discount5_nominal; ?>
				<?php else: ?>
					<?php echo "0"; ?>
				<?php endif ?>
			</td>
		</tr>
		<tr>
			<td>Retail Price</td>
			<td colspan="2"><?php echo $purchaseOrderDetail->retail_price; ?></td>
		</tr>
		<tr>
			<td>Unit Price</td>
			<td colspan="2"><?php echo $purchaseOrderDetail->unit_price; ?></td>
		</tr>
		<tr>
			<td>Total Qty</td>
			<td colspan="2"><?php echo $purchaseOrderDetail->total_quantity; ?></td>
		</tr>
		<tr>
			<td>Total Price</td>
			<td colspan="2"><?php echo $purchaseOrderDetail->total_price; ?></td>
		</tr>
	</table>
<?php endforeach ?>
<table>
	<tr>
		<td width="10%">Product : <?php echo CHtml::activeHiddenField($detail, "[$i]product_id", array('size'=>20,'maxlength'=>20)); ?></td>
		<td width="85%">		
			<?php 
			echo CHtml::activeTextField(
				$detail,"[$i]product_name",array('size'=>15,
					'maxlength'=>10,
					'readonly'=>true,
					'value' => $detail->product_id == "" ? '': Product::model()->findByPk($detail->product_id)->name)
				); 
				?>
			</td>
			<td width="5%">
				<?php
				echo CHtml::button('X', array(
					'onclick' => CHtml::ajax(array(
						'type' => 'POST',
						'url' => CController::createUrl('ajaxHtmlRemoveDetail', array('id' => $purchaseOrder->header->id, 'index' => $i)),
						'update' => '#detail',
						)),
					));
					?>
				</td>
			</tr>
			<tr>
				<td colspan="3" id="request_<?php echo $i; ?>">
					<?php 

					$requestOrderDetails = TransactionRequestOrderDetail::model()->findAllByAttributes(array('product_id'=>$detail->product_id));

					$this->renderPartial('_detailRequest', array('requestOrderDetails'=>$requestOrderDetails,'purchaseOrder'=>$purchaseOrder,'detail'=>$detail,'index'=>$i),false, true);
			//$this->renderPartial('_detailRequest',array('detail'=>$detail,'i'=>$i,'requestOrderDetails'=>$requestOrderDetails)); ?>
		</td>
	</tr>
	<tr>
		<td colspan="3">
			<div class="row">
				<div class="medium-6 columns">
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Quantity</label>
							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]quantity"); ?>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Retail Price</label>
							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]retail_price",array('readonly'=>true)); ?>

							</div>
						</div>
					</div>

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Unit</label>

							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]unit_id"); ?>

							</div>
						</div>
					</div>

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">HPP</label>

							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]hpp",array('readonly'=>true,'value'=>$detail->product_id !=""? Product::model()->findByPk($detail->product_id)->hpp:'0')); ?>

							</div>
						</div>
					</div>

					
				</div>
				<div class="medium-6 columns">
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Discount Step</label>
							</div>
							<div class="small-8 columns">
								<div class="row">
									<div class="small-8 columns">
										<?php 
										echo CHtml::activeDropDownList($detail, "[$i]discount_step",array('1' => '1', '2' => '2','3'=>'3','4'=>'4','5'=>'5'),array('prompt'=>'[--Select Discount step--]'));
										?>
									</div>
									<div class="small-2 columns">
										<?php echo CHtml::button('Add', array(
											'id'=>'add'.$i,
											'onclick' => 'var step = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount_step").val();
											stepbtn'.$i.' = step;
											switch (step) {
												case 1:
												$("#step1_'.$i.'").show();
												$("#step2_'.$i.'").hide();
												$("#step3_'.$i.'").hide();
												$("#step4_'.$i.'").hide();
												$("#step5_'.$i.'").hide();
												break;
												case 2:
												$("#step1_'.$i.'").show();
												$("#step2_'.$i.'").show();
												$("#step3_'.$i.'").hide();
												$("#step4_'.$i.'").hide();
												$("#step5_'.$i.'").hide();
												break;
												case 3:
												$("#step1_'.$i.'").show();
												$("#step2_'.$i.'").show();
												$("#step3_'.$i.'").show();
												$("#step4_'.$i.'").hide();
												$("#step5_'.$i.'").hide();
												break;
												case 4:
												$("#step1_'.$i.'").show();
												$("#step2_'.$i.'").show();
												$("#step3_'.$i.'").show();
												$("#step4_'.$i.'").show();
												$("#step5_'.$i.'").hide();
												break;
												case 5:
												$("#step1_'.$i.'").show();
												$("#step2_'.$i.'").show();
												$("#step3_'.$i.'").show();
												$("#step4_'.$i.'").show();
												$("#step5_'.$i.'").show();
												break;

												default:
												$("#step1_'.$i.'").hide();
												$("#step2_'.$i.'").hide();
												$("#step3_'.$i.'").hide();
												$("#step4_'.$i.'").hide();
												$("#step5_'.$i.'").hide();

												break;
										}'));?>
									</div>
									<div class="small-2 columns text-right">
										<?php
											echo CHtml::button('Count', array(
											'id' => 'count_'.$i,
											// 'style'=>'display:none;',
											'onclick' =>

											'var step = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount_step").val();
											switch (step) {
											case 1:
											$("#TransactionPurchaseOrderDetail_'.$i.'_total_quantity").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount1_temp_quantity").val());
											$("#TransactionPurchaseOrderDetail_'.$i.'_total_price").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount1_temp_price").val());
											$("#TransactionPurchaseOrderDetail_'.$i.'_subtotal").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount1_temp_price").attr("realPrice"));
											$("#TransactionPurchaseOrderDetail_'.$i.'_discount").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount1_temp_price").attr("rel"));
											$.ajax({
											type: "POST",

											url: "' . CController::createUrl('ajaxCountTotal', array()) . '/totalquantity/" +$("#TransactionPurchaseOrderDetail_'.$i.'_total_quantity").val()+"/totalprice/"+$("#TransactionPurchaseOrderDetail_'.$i.'_total_price").val(),


											data: $("form").serialize(),
											dataType: "json",
											success: function(data) {
											console.log(data.unitprice);
											$("#TransactionPurchaseOrderDetail_'.$i.'_unit_price").val(data.unitprice);

											},});
											break;
											case 2:
											$("#TransactionPurchaseOrderDetail_'.$i.'_total_quantity").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount2_temp_quantity").val());
											$("#TransactionPurchaseOrderDetail_'.$i.'_total_price").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount2_temp_price").val());
											$("#TransactionPurchaseOrderDetail_'.$i.'_subtotal").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount2_temp_price").attr("realPrice"));
											$("#TransactionPurchaseOrderDetail_'.$i.'_discount").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount2_temp_price").attr("rel"));
											$.ajax({
											type: "POST",

											url: "' . CController::createUrl('ajaxCountTotal', array()) . '/totalquantity/" +$("#TransactionPurchaseOrderDetail_'.$i.'_total_quantity").val()+"/totalprice/"+$("#TransactionPurchaseOrderDetail_'.$i.'_total_price").val(),


											data: $("form").serialize(),
											dataType: "json",
											success: function(data) {
											console.log(data.unitprice);
											$("#TransactionPurchaseOrderDetail_'.$i.'_unit_price").val(data.unitprice);

											},});
											break;
											case 3:
											$("#TransactionPurchaseOrderDetail_'.$i.'_total_quantity").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount3_temp_quantity").val());
											$("#TransactionPurchaseOrderDetail_'.$i.'_total_price").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount3_temp_price").val());
											$("#TransactionPurchaseOrderDetail_'.$i.'_subtotal").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount3_temp_price").attr("realPrice"));
											$("#TransactionPurchaseOrderDetail_'.$i.'_discount").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount3_temp_price").attr("rel"));
											$.ajax({
											type: "POST",

											url: "' . CController::createUrl('ajaxCountTotal', array()) . '/totalquantity/" +$("#TransactionPurchaseOrderDetail_'.$i.'_total_quantity").val()+"/totalprice/"+$("#TransactionPurchaseOrderDetail_'.$i.'_subtotal").val(),


											data: $("form").serialize(),
											dataType: "json",
											success: function(data) {
											console.log(data.unitprice);
											$("#TransactionPurchaseOrderDetail_'.$i.'_unit_price").val(data.unitprice);

											},});
											break;
											case 4:
											$("#TransactionPurchaseOrderDetail_'.$i.'_total_quantity").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount4_temp_quantity").val());
											$("#TransactionPurchaseOrderDetail_'.$i.'_total_price").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount4_temp_price").val());
											$("#TransactionPurchaseOrderDetail_'.$i.'_subtotal").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount4_temp_price").attr("realPrice"));
											$("#TransactionPurchaseOrderDetail_'.$i.'_discount").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount4_temp_price").attr("rel"));
											$.ajax({
											type: "POST",

											url: "' . CController::createUrl('ajaxCountTotal', array()) . '/totalquantity/" +$("#TransactionPurchaseOrderDetail_'.$i.'_total_quantity").val()+"/totalprice/"+$("#TransactionPurchaseOrderDetail_'.$i.'_total_price").val(),


											data: $("form").serialize(),
											dataType: "json",
											success: function(data) {
											console.log(data.unitprice);
											$("#TransactionPurchaseOrderDetail_'.$i.'_unit_price").val(data.unitprice);

											},});
											break;
											case 5:
											$("#TransactionPurchaseOrderDetail_'.$i.'_total_quantity").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount5_temp_quantity").val());
											$("#TransactionPurchaseOrderDetail_'.$i.'_total_price").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount5_temp_price").val());
											$("#TransactionPurchaseOrderDetail_'.$i.'_subtotal").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount5_temp_price").attr("realPrice"));
											$("#TransactionPurchaseOrderDetail_'.$i.'_discount").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount5_temp_price").attr("rel"));
											$.ajax({
											type: "POST",

											url: "' . CController::createUrl('ajaxCountTotal', array()) . '/totalquantity/" +$("#TransactionPurchaseOrderDetail_'.$i.'_total_quantity").val()+"/totalprice/"+$("#TransactionPurchaseOrderDetail_'.$i.'_total_price").val(),


											data: $("form").serialize(),
											dataType: "json",
											success: function(data) {
											console.log(data.unitprice);
											$("#TransactionPurchaseOrderDetail_'.$i.'_unit_price").val(data.unitprice);

											},});
											break;

											default:
											$("#TransactionPurchaseOrderDetail_'.$i.'_total_quantity").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_quantity").val());
											$("#TransactionPurchaseOrderDetail_'.$i.'_total_price").val(jQuery("#TransactionPurchaseOrderDetail_'.$i.'_retail_price").val());
											$.ajax({
											type: "POST",

											url: "' . CController::createUrl('ajaxCountTotalNonDiscount', array()) . '/totalquantity/" +$("#TransactionPurchaseOrderDetail_'.$i.'_total_quantity").val()+"/totalprice/"+$("#TransactionPurchaseOrderDetail_'.$i.'_total_price").val(),


											data: $("form").serialize(),
											dataType: "json",
											success: function(data) {
											console.log(data.unitprice);
											$("#TransactionPurchaseOrderDetail_'.$i.'_unit_price").val(data.unitprice);
											$("#TransactionPurchaseOrderDetail_'.$i.'_total_price").val(data.price);
											$("#TransactionPurchaseOrderDetail_'.$i.'_subtotal").val(data.price);
											$("#TransactionPurchaseOrderDetail_'.$i.'_discount").val("0");
			
											},});
											break;

											}'

										));?>
									</div>
								</div>

							</div>
						</div>
					</div>

					<!-- // step 1 -->
					<div class="field" id="step1_<?php echo $i; ?>">
						<div class="row collapse" >
							<div class="small-4 columns">
								<label class="prefix">Step 1</label>
							</div>
							<div class="small-8 columns">
								<div class="row">
									<div class="small-3 columns">
										<?php echo CHtml::activeDropDownList($detail, "[$i]discount1_type", array('1' => 'Percent',	'2' => 'Amount','3'=>'Bonus'),array('prompt'=>'[--Select Discount Type--]'));?>
									</div>
									<div class="small-3 columns">
										<?php 
										echo CHtml::activeTextField($detail,"[$i]discount1_nominal"); 
											?><?php
											echo CHtml::button('Count', array(
											'id' => 'count_step1_'.$i,
											'style'=>'display:none;',
											'onclick' => 'var quantity = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_quantity").val();
											var retail = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_retail_price").val();
											var discountType = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount1_type").val();
											var discountAmount = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount1_nominal").val();
											//var price = 0;
											$.ajax({
												type: "POST",
												url: "' . CController::createUrl('ajaxCountAmount', array()) . '/discountType/" +discountType+"/discountAmount/"+discountAmount+"/retail/" +retail+"/quantity/"+quantity,


												data: $("form").serialize(),
												dataType: "json",
												success: function(data) {
													console.log(data.subtotal);
													console.log(data.totalquantity);
													console.log(data.newPrice);
													console.log(data.discountAmount);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount1_temp_price").val(data.subtotal);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount1_temp_price").attr("rel",data.discountAmount);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount1_temp_price").attr("realPrice",data.price);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount1_temp_quantity").val(data.totalquantity);


												},});'

												)); 
											?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount1_temp_price",array('readonly'=>true)); ?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount1_temp_quantity",array('readonly'=>true)); ?>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="field" id="step2_<?php echo $i; ?>">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Step 2</label>
							</div>
							<div class="small-8 columns">
								<div class="row">
									<div class="small-3 columns">
										<?php echo CHtml::activeDropDownList($detail, "[$i]discount2_type", array('1' => 'Percent','2' => 'Amount','3'=>'Bonus'),array('prompt'=>'[--Select Discount Type--]'));?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount2_nominal"); ?>
										<?php
											echo CHtml::button('Count', array(
											'id' => 'count_step2_'.$i,
											'style'=>'display:none;',
											'onclick' => 'var quantity = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_quantity").val();
											var retail = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_retail_price").val();
											var discountType = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount2_type").val();
											var discountAmount = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount2_nominal").val();
											var price = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount1_temp_price").val();;

											$.ajax({
												type: "POST",

												url: "' . CController::createUrl('ajaxCountAmountStep', array()) . '/discountType/" +discountType+"/discountAmount/"+discountAmount+"/retail/" +retail+"/quantity/"+quantity+"/price/"+price,


												data: $("form").serialize(),
												dataType: "json",
												success: function(data) {
													console.log(data.subtotal);
													console.log(data.totalquantity);
													console.log(data.newPrice);
													console.log(data.oriPrice);
													console.log(data.discountAmount);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount2_temp_price").val(data.subtotal);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount2_temp_price").attr("rel",data.discountAmount);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount2_temp_price").attr("realPrice",data.oriPrice);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount2_temp_quantity").val(data.totalquantity);
												},});'


										)); ?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount2_temp_price",array('readonly'=>true)); ?>

									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount2_temp_quantity",array('readonly'=>true)); ?>

									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="field"  id="step3_<?php echo $i; ?>">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Step 3</label>

							</div>
							<div class="small-8 columns">
								<div class="row">
									<div class="small-3 columns">
										<?php echo CHtml::activeDropDownList($detail, "[$i]discount3_type", array('1' => 'Percent',
										'2' => 'Amount','3'=>'Bonus'),array('prompt'=>'[--Select Discount Type--]'));?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount3_nominal"); ?>
											<?php
											echo CHtml::button('Count', array(
											'id' => 'count_step3_'.$i,
											'style'=>'display:none;',
											'onclick' =>'var quantity = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_quantity").val();
											var retail = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_retail_price").val();
											var discountType = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount3_type").val();
											var discountAmount = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount3_nominal").val();
											var price = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount2_temp_price").val();;

											$.ajax({
												type: "POST",

												url: "' . CController::createUrl('ajaxCountAmountStep', array()) . '/discountType/" +discountType+"/discountAmount/"+discountAmount+"/retail/" +retail+"/quantity/"+quantity+"/price/"+price,

												data: $("form").serialize(),
												dataType: "json",
												success: function(data) {
													console.log(data.subtotal);
													console.log(data.totalquantity);
													console.log(data.newPrice);
													console.log(data.discountAmount);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount3_temp_price").val(data.subtotal);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount3_temp_price").attr("rel",data.discountAmount);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount3_temp_price").attr("realPrice",data.oriPrice);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount3_temp_quantity").val(data.totalquantity);
												},});'

											)); ?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount3_temp_price",array('readonly'=>true)); ?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount3_temp_quantity",array('readonly'=>true)); ?>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="field" id="step4_<?php echo $i; ?>">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Step 4</label>
							</div>
							<div class="small-8 columns">
								<div class="row">
									<div class="small-3 columns">
										<?php echo CHtml::activeDropDownList($detail, "[$i]discount4_type", array('1' => 'Percent',
										'2' => 'Amount','3'=>'Bonus'),array('prompt'=>'[--Select Discount Type--]'));?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount4_nominal"); ?>
										<?php
											echo CHtml::button('Count', array(
											'id' => 'count_step4_'.$i,
											'style'=>'display:none;',
											'onclick' =>'var quantity = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_quantity").val();
											var retail = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_retail_price").val();
											var discountType = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount4_type").val();
											var discountAmount = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount4_nominal").val();
											var price = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount3_temp_price").val();;

											$.ajax({
												type: "POST",

												url: "' . CController::createUrl('ajaxCountAmountStep', array()) . '/discountType/" +discountType+"/discountAmount/"+discountAmount+"/retail/" +retail+"/quantity/"+quantity+"/price/"+price,


												data: $("form").serialize(),
												dataType: "json",
												success: function(data) {
													console.log(data.subtotal);
													console.log(data.totalquantity);
													console.log(data.newPrice);
													console.log(data.discountAmount);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount4_temp_price").val(data.subtotal);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount4_temp_price").attr("rel",data.discountAmount);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount4_temp_price").attr("realPrice",data.oriPrice);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount4_temp_quantity").val(data.totalquantity);
												},});'


										)); ?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount4_temp_price",array('readonly'=>true)); ?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount4_temp_quantity",array('readonly'=>true)); ?>
									</div>
								</div>
							</div>
						</div>
					</div>


					<div class="field" id="step5_<?php echo $i; ?>">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Step 5</label>
							</div>
							<div class="small-8 columns">
								<div class="row">
									<div class="small-3 columns">
										<?php echo CHtml::activeDropDownList($detail, "[$i]discount5_type", array('1' => 'Percent',
										'2' => 'Amount','3'=>'Bonus'),array('prompt'=>'[--Select Discount Type--]'));?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount5_nominal"); ?>
										<?php
											echo CHtml::button('Count', array(
											'id' => 'count_step5_'.$i,
											'style'=>'display:none;',
											'onclick'=>'var quantity = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_quantity").val();
											var retail = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_retail_price").val();
											var discountType = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount5_type").val();
											var discountAmount = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount5_nominal").val();
											var price = +jQuery("#TransactionPurchaseOrderDetail_'.$i.'_discount4_temp_price").val();;

											$.ajax({
												type: "POST",

												url: "' . CController::createUrl('ajaxCountAmountStep', array()) . '/discountType/" +discountType+"/discountAmount/"+discountAmount+"/retail/" +retail+"/quantity/"+quantity+"/price/"+price,


												data: $("form").serialize(),
												dataType: "json",
												success: function(data) {
													console.log(data.subtotal);
													console.log(data.totalquantity);
													console.log(data.newPrice);
													console.log(data.discountAmount);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount5_temp_price").val(data.subtotal);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount5_temp_price").attr("rel",data.discountAmount);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount5_temp_price").attr("realPrice",data.oriPrice);
													$("#TransactionPurchaseOrderDetail_'.$i.'_discount5_temp_quantity").val(data.totalquantity);
												},});'
										)); ?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount5_temp_price",array('readonly'=>true)); ?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount5_temp_quantity",array('readonly'=>true)); ?>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Total Quantity</label>

							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]total_quantity",array('readonly'=>true)); ?>

							</div>
						</div>
					</div>

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Unit Price</label>

							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]unit_price",array('readonly'=>true));?>

							</div>
						</div>
					</div>

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Subtotal</label>

							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]subtotal",array('readonly'=>true)); ?>

							</div>
						</div>
					</div>

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Discount</label>

							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]discount",array('readonly'=>true,)); ?>

							</div>
						</div>
					</div>

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Total</label>

							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]total_price",array('readonly'=>true)); ?>

							</div>
						</div>
					</div>
				</div>
			</div>

		</td>
	</tr>
</table>


<?php
Yii::app()->clientScript->registerScript('myjqueryCount'.$i,'

    function callme_stepbtn() {
        if (stepbtn'.$i.' == 1 ) {
			$("#TransactionPurchaseOrderDetail_'.$i.'_quantity,#TransactionPurchaseOrderDetail_'.$i.'_discount1_nominal").keyup(function(event){
				$("#count_step1_'.$i.'").click();
			});
		}else if (stepbtn'.$i.' == 2 ) {
			$("#TransactionPurchaseOrderDetail_'.$i.'_quantity,#TransactionPurchaseOrderDetail_'.$i.'_discount1_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount2_nominal").keyup(function(event){
				$("#count_step1_'.$i.'").click();
				$("#count_step2_'.$i.'").click();
			});
		}else if (stepbtn'.$i.' == 3 ) {
			$("#TransactionPurchaseOrderDetail_'.$i.'_quantity,#TransactionPurchaseOrderDetail_'.$i.'_discount1_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount2_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount3_nominal").keyup(function(event){
				$("#count_step1_'.$i.'").click();
				$("#count_step2_'.$i.'").click();
				$("#count_step3_'.$i.'").click();
			});
		}else if (stepbtn'.$i.' == 4 ) {
			$("#TransactionPurchaseOrderDetail_'.$i.'_quantity,#TransactionPurchaseOrderDetail_'.$i.'_discount1_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount2_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount3_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount4_nominal").keyup(function(event){
				$("#count_step1_'.$i.'").click();
				$("#count_step2_'.$i.'").click();
				$("#count_step3_'.$i.'").click();
				$("#count_step4_'.$i.'").click();
			});
		}else if (stepbtn'.$i.' == 5) {
			$("#TransactionPurchaseOrderDetail_'.$i.'_quantity,#TransactionPurchaseOrderDetail_'.$i.'_discount1_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount2_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount3_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount4_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount5_nominal").keyup(function(event){
				$("#count_step1_'.$i.'").click();
				$("#count_step2_'.$i.'").click();
				$("#count_step3_'.$i.'").click();
				$("#count_step4_'.$i.'").click();
				$("#count_step5_'.$i.'").click();
			});
		}
		// $("#count_'.$i.'").click();
    }

	$("#TransactionPurchaseOrderDetail_'.$i.'_quantity,#TransactionPurchaseOrderDetail_'.$i.'_discount1_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount2_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount3_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount4_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount5_nominal,#TransactionPurchaseOrderDetail_'.$i.'_discount_step").keyup(function(event){
		callme_stepbtn();
	});

	$("#add'.$i.'").click(function() {
		callme_stepbtn();
	});
');
?>

 <?php
// 	Yii::app()->clientScript->registerScript('myjavascript', '
// 		//$(".numbers").number( true,2, ".", ",");
//     ', CClientScript::POS_END);
// ?>
<?php
/* @var $this TransactionPurchaseOrderController */
/* @var $model TransactionPurchaseOrder */

$this->breadcrumbs=array(
	'Transaction Purchase Orders'=>array('admin'),
	'Manage',
	);

$this->menu=array(
	array('label'=>'List TransactionPurchaseOrder', 'url'=>array('index')),
	array('label'=>'Create TransactionPurchaseOrder', 'url'=>array('create')),
	);

// Yii::app()->clientScript->registerScript('search', "
// $('.search-button').click(function(){
// 	$('.search-form').toggle();
// 	return false;
// });
// $('.search-form form').submit(function(){
// 	$('#transaction-purchase-order-grid').yiiGridView('update', {
// 		data: $(this).serialize()
// 	});
// 	return false;
// });
// ");
Yii::app()->clientScript->registerScript('search', "
	$('.search-button').click(function(){
		$('.search-form').slideToggle(600);
		$('.bulk-action').toggle();
		$(this).toggleClass('active');
		if($(this).hasClass('active')){
			$(this).text('');
		}else {
			$(this).text('Advanced Search');
		}
		return false;
	});
	$('.search-form form').submit(function(){
		$('#transaction-request-order-grid').yiiGridView('update', {
			data: $(this).serialize()
		});
		return false;
	});
	");
	?>

	
	<div id="maincontent">
		<div class="clearfix page-action">
			<?php echo CHtml::link('<span class="fa fa-plus"></span>New Purchase Order', Yii::app()->baseUrl.'/transaction/transactionPurchaseOrder/create', array('class'=>'button success right', 'visible'=>Yii::app()->user->checkAccess("transaction.transactionPurchaseOrder.create"))) ?>
			<h1>Manage Transaction Purchase Orders</h1>
			<div class="search-bar">
				<div class="clearfix button-bar">
      			<!--<div class="left clearfix bulk-action">
	         		<span class="checkbox"><span class="fa fa-reply fa-rotate-270"></span></span>
	         		<input type="submit" value="Archive" class="button secondary cbutton" name="archive">         
	         		<input type="submit" value="Delete" class="button secondary cbutton" name="delete">      
	         	</div>-->
	         	<a href="#" class="search-button right button cbutton secondary">Advanced Search</a>
	         	<div class="clearfix"></div>
	         	<div class="search-form" style="display:none">
	         		<?php $this->renderPartial('_search',array(
	         			'model'=>$model,
	         			)); ?>
	         		</div><!-- search-form -->				
	         	</div>
	         </div>

	         <div class="grid-view">

	         	<?php $this->widget('zii.widgets.grid.CGridView', array(
	         		'id'=>'transaction-purchase-order-grid',
	         		'dataProvider'=>$model->search(),
	         		'filter'=>$model,
	         		'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
	         		'pager'=>array(
	         			'cssFile'=>false,
	         			'header'=>'',
	         			),
	         		'columns'=>array(
						//'id',
	         			array('name'=>'purchase_order_no', 'value'=>'CHTml::link($data->purchase_order_no, array("view", "id"=>$data->id))', 'type'=>'raw'),
						//'purchase_order_no',
	         			'purchase_order_date',
						//'branch_issued',
	         			// 'supplier_id',
	         			array(
	         				'name'=>'supplier_id',
	         				'value'=>'$data->supplier->name',
	         			),
						//'estimation_date',
						/*
						'payment_estimation_date',
						'PPN',
						'subtotal',
						'total',
						'total_items',
						'approved_by',
						'approved_status',
						'decline_memo',
						'notes',
						*/
						array(
							'class'=>'CButtonColumn',
							'template'=>'{edit} {print}',
							'buttons'=>array
							(
								'edit' => array
								(
									'label'=>'edit',
									'url'=>'Yii::app()->createUrl("transaction/transactionPurchaseOrder/update", array("id"=>$data->id))',
									'visible'=> '$data->status_document != "Approved" && Yii::app()->user->checkAccess("transaction.transactionPurchaseOrder.update")',
								),
								'print' => array
								(
									'label'=>'print',
									'url'=>'Yii::app()->createUrl("transaction/transactionPurchaseOrder/pdf", array("id"=>$data->id))',
									'visible'=> '$data->status_document == "Approved" && Yii::app()->user->checkAccess("transaction.transactionPurchaseOrder.pdf")',
								),
							),
							),
						),
						)); ?>
					</div>
					<fieldset>
						<legend>Pending Order List</legend>
						<h2>Request Order</h2>
						<div class="grid-view">

	         	<?php $this->widget('zii.widgets.grid.CGridView', array(
	         		'id'=>'transaction-request-order-grid',
	         		'dataProvider'=>$requestDataProvider,
	         		'filter'=>$request,
	         		'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
	         		'pager'=>array(
	         			'cssFile'=>false,
	         			'header'=>'',
	         			),
	         		'columns'=>array(
						//'id',
	         			array('name'=>'request_order_no', 'value'=>'CHTml::link($data->request_order_no, array("/transaction/transactionRequestOrder/view", "id"=>$data->id))', 'type'=>'raw'),
	         			'request_order_date',
						'status_document',
						array('header'=>'Purchases','value'=> function($data){
							if(count($data->transactionPurchaseOrderDetailRequests) >0) {
								foreach ($data->transactionPurchaseOrderDetailRequests as $key => $podetail) {
									echo $podetail->purchaseOrderDetail->purchaseOrder->purchase_order_no. "<br>";
									
								}
							}
								

							}
						)),
						)); ?>
					</div>
					</fieldset>
				</div>
			</div>
<?php
/* @var $this TransactionDeliveryOrderController */
/* @var $model TransactionDeliveryOrder */

$this->breadcrumbs=array(
	'Pending Transaction'=>array('index'),
	
	);

$this->menu=array(
	array('label'=>'List Pending Transaction', 'url'=>array('index')),
	
	);

Yii::app()->clientScript->registerScript('report', '
	 $("#tanggal_mulai").val("' . $tanggal_mulai . '");
     $("#tanggal_sampai").val("' . $tanggal_sampai . '");
    
');
//Yii::app()->clientScript->registerCssFile(Yii::app()->request->baseUrl . '/css/transaction/report.css');
?>


	
	<div id="maincontent">
		<div class="clearfix page-action">
			<?php echo CHtml::link('<span class="fa fa-plus"></span>New Delivery Order', Yii::app()->baseUrl.'/transaction/transactionDeliveryOrder/create', array('class'=>'button success right', 'visible'=>Yii::app()->user->checkAccess("transaction.transactionDeliveryOrder.create"))) ?>
			<h1>Pending Transaction</h1>
			

	         <div class="grid-view">
	
	         	
	         	</div>
	         	<fieldset>
	         		<legend>Pending Orders</legend>
					<div class="myForm" id="myForm">

					<?php echo CHtml::beginForm(array(''), 'get'); ?>
	         		 <div class="row">
                        <div class="medium-6 columns">
                            <div class="field">
                                <div class="row collapse">
                                    <div class="small-2 columns">
                                        <span class="prefix">Tanggal </span>
                                    </div>
                                    <div class="small-5 columns">
                                         <?php
                                            $this->widget('zii.widgets.jui.CJuiDatePicker', array(
                                                'name'=>'tanggal_mulai',
                                                'options'=>array(
                                                    'dateFormat'=>'yy-mm-dd',
                                                ),
                                                'htmlOptions'=>array(
                                                    'readonly'=>true,
                                                    'placeholder'=>'Mulai',
                                                ),
                                            ));
                                            ?>
                                    </div>
                                   
                                    <div class="small-5 columns">
                                         <?php
                                            $this->widget('zii.widgets.jui.CJuiDatePicker', array(
                                                'name'=>'tanggal_sampai',
                                                'options'=>array(
                                                    'dateFormat'=>'yy-mm-dd',
                                                ),
                                                'htmlOptions'=>array(
                                                    'readonly'=>true,
                                                    'placeholder'=>'Sampai',
                                                ),
                                            ));
                                            ?>
                                    </div>
                                 </div>
                            </div>
                           
                        </div>
                    </div>
                    <div class="row">
                        <div class="medium-6 columns">
                            <div class="field">
                                <div class="row collapse">
                                    <div class="small-4 columns">
                                        <span class="prefix">Status Document </span>
                                    </div>
                                     <div class="small-8 columns">
                                        <?php echo CHtml::dropDownlist('status_document', $status_document, array('Draft'=>'Draft','Revised' => 'Revised','Rejected'=>'Rejected'), array('empty'=>'-- All Status Document --')); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo CHtml::submitButton('Tampilkan', array('onclick'=>'$("#CurrentSort").val(""); return true;')); ?>
                       <?php echo CHtml::endForm(); ?>
	         		<h2>Request Order</h2>
					
						<?php $this->widget('zii.widgets.grid.CGridView', array(
							'id'=>'request-grid',
							'dataProvider'=>$requestDataProvider,
							'filter'=>$request,
							'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
			         		'pager'=>array(
			         			'cssFile'=>false,
			         			'header'=>'',
			         			),
							//'summaryText'=>'',
							'columns'=>array(
								//'id',
								//'code',
								array('name'=>'request_order_no', 'value'=>'CHTml::link($data->request_order_no, array("/transaction/transactionRequestOrder/view", "id"=>$data->id))', 'type'=>'raw'),
								// 'purchase_order_no',
								'request_order_date',
								'status_document',
								array('name'=>'requester_branch_id','value'=>'$data->requesterBranch->name'),
								array('name'=>'requester_id','value'=> '$data->user->employee->name'),
								),
						)); ?>


						<h2>Purchase Order</h2>
					
						<?php $this->widget('zii.widgets.grid.CGridView', array(
							'id'=>'purchase-grid',
							'dataProvider'=>$purchaseDataProvider,
							'filter'=>$purchase,
							'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
			         		'pager'=>array(
			         			'cssFile'=>false,
			         			'header'=>'',
			         			),
							//'summaryText'=>'',
							'columns'=>array(
								//'id',
								//'code',
								
								array('name'=>'purchase_order_no', 'value'=>'CHTml::link($data->purchase_order_no, array("/transaction/transactionRequestOrder/view", "id"=>$data->id))', 'type'=>'raw'),
								// 'purchase_order_no',

								'purchase_order_date',
								'status_document',
								array('name'=>'requester_id','value'=> '$data->user->employee->name'),
								),
						)); ?>

	         		<h2>Sales Order</h2>
					
						<?php $this->widget('zii.widgets.grid.CGridView', array(
							'id'=>'sales-grid',
							'dataProvider'=>$salesDataProvider,
							'filter'=>$sales,
							'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
			         		'pager'=>array(
			         			'cssFile'=>false,
			         			'header'=>'',
			         			),
							//'summaryText'=>'',
							'columns'=>array(
								//'id',
								//'code',
								array('name'=>'sale_order_no', 'value'=>'CHTml::link($data->sale_order_no, array("/transaction/transactionSalesOrder/view", "id"=>$data->id))', 'type'=>'raw'),
								// 'purchase_order_no',
								'sale_order_date',
								'status_document',
								array('name'=>'requester_branch_id','value'=>'$data->requesterBranch->name'),

								array('name'=>'requester_id','value'=> '$data->user->employee->name'),
								),
						)); ?>
					<h2>Transfer Request</h2>
					
						<?php $this->widget('zii.widgets.grid.CGridView', array(
							'id'=>'transfer-grid',
							'dataProvider'=>$transferDataProvider,
							'filter'=>$transfer,
							'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
			         		'pager'=>array(
			         			'cssFile'=>false,
			         			'header'=>'',
			         			),
							//'summaryText'=>'',
							'columns'=>array(
								//'id',
								//'code',
								array('name'=>'transfer_request_no', 'value'=>'CHTml::link($data->transfer_request_no, array("/transaction/transactionTransferRequest/view", "id"=>$data->id))', 'type'=>'raw'),
								// 'purchase_order_no',
								'transfer_request_date',
								'status_document',
								array('name'=>'requester_branch_id','value'=>'$data->requesterBranch->name'),
								array('name'=>'requester_id','value'=> '$data->user->employee->name'),
								),
						)); ?>
					<h2>Sent Request</h2>
					
						<?php $this->widget('zii.widgets.grid.CGridView', array(
							'id'=>'sent-grid',
							'dataProvider'=>$sentDataProvider,
							'filter'=>$sent,
							'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
			         		'pager'=>array(
			         			'cssFile'=>false,
			         			'header'=>'',
			         			),
							//'summaryText'=>'',
							'columns'=>array(
								//'id',
								//'code',
								array('name'=>'sent_request_no', 'value'=>'CHTml::link($data->sent_request_no, array("/transaction/transactionSentRequest/view", "id"=>$data->id))', 'type'=>'raw'),
								// 'purchase_order_no',
								'sent_request_date',
								'status_document',
								array('name'=>'requester_branch_id','value'=>'$data->requesterBranch->name'),
								array('name'=>'requester_id','value'=> '$data->user->employee->name'),
								),
						)); ?>
					<h2>Consignment Out</h2>
					
						<?php $this->widget('zii.widgets.grid.CGridView', array(
							'id'=>'consignment-grid',
							'dataProvider'=>$consignmentDataProvider,
							'filter'=>$consignment,
							'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
			         		'pager'=>array(
			         			'cssFile'=>false,
			         			'header'=>'',
			         			),
							//'summaryText'=>'',
							'columns'=>array(
								//'id',
								//'code',
								array('name'=>'consignment_out_no', 'value'=>'CHTml::link($data->consignment_out_no, array("/transaction/consignmentOutHeader/view", "id"=>$data->id))', 'type'=>'raw'),
								// 'purchase_order_no',
								'date_posting',
								'status',
								array('name'=>'sender_id','value'=> '$data->user->employee->name'),
								// array('name'=>'requester_branch_id','value'=>'$data->requesterBranch->name'),
								),
						)); ?>

						<h2>Consignment In</h2>
					
						<?php $this->widget('zii.widgets.grid.CGridView', array(
							'id'=>'consignment-in-grid',
							'dataProvider'=>$consignmentInDataProvider,
							'filter'=>$consignmentIn,
							'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
			         		'pager'=>array(
			         			'cssFile'=>false,
			         			'header'=>'',
			         			),
							//'summaryText'=>'',
							'columns'=>array(
								//'id',
								//'code',
								array('name'=>'consignment_in_number', 'value'=>'CHTml::link($data->consignment_in_number, array("/transaction/consignmentInHeader/view", "id"=>$data->id))', 'type'=>'raw'),
								// 'purchase_order_no',
								'date_posting',
								'status_document',
								array('name'=>'receive_id','value'=> '$data->user->employee->name'),

							),
						)); ?>
						<h2>Movement In</h2>
					
						<?php $this->widget('zii.widgets.grid.CGridView', array(
							'id'=>'movement-in-grid',
							'dataProvider'=>$movementInDataProvider,
							'filter'=>$movementIn,
							'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
			         		'pager'=>array(
			         			'cssFile'=>false,
			         			'header'=>'',
			         			),
							//'summaryText'=>'',
							'columns'=>array(
								//'id',
								//'code',
								array('name'=>'movement_in_number', 'value'=>'CHTml::link($data->movement_in_number, array("/transaction/movementInHeader/view", "id"=>$data->id))', 'type'=>'raw'),
								// 'purchase_order_no',
								'date_posting',
								'status',
								array('name'=>'user_id','value'=> '$data->user->employee->name'),
							),
						)); ?>
						<h2>Movement Out</h2>
					
						<?php $this->widget('zii.widgets.grid.CGridView', array(
							'id'=>'movement-grid',
							'dataProvider'=>$movementDataProvider,
							'filter'=>$movement,
							'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
			         		'pager'=>array(
			         			'cssFile'=>false,
			         			'header'=>'',
			         			),
							//'summaryText'=>'',
							'columns'=>array(
								//'id',
								//'code',
								array('name'=>'movement_out_no', 'value'=>'CHTml::link($data->movement_out_no, array("/transaction/movementOutHeader/view", "id"=>$data->id))', 'type'=>'raw'),
								// 'purchase_order_no',
								'date_posting',
								'status',
								array('name'=>'user_id','value'=> '$data->user->employee->name'),
							),
						)); ?>
	         	</fieldset>
	         </div>
	     </div>
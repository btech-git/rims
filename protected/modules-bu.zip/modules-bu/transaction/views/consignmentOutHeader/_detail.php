<?php if (count($consignmentOut->details)): ?>
	<table>
		<thead>
			<tr>
				<th>Product</th>
				<th>Quantity</th>
				<th>Price</th>
				<th>Total Price</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($consignmentOut->details as $i => $detail): ?>
				<tr>
					<td><?php echo CHtml::activeHiddenField($detail, "[$i]product_id", array('size'=>20,'maxlength'=>20)); ?>
							
							<?php echo CHtml::activeTextField($detail,"[$i]product_name",
								array(
									'size'=>15,
									'maxlength'=>10,
									'onclick' => '$("#product'.$i.'-dialog").dialog("open"); return false;',
					            	'value' => $detail->product_id == "" ? '': Product::model()->findByPk($detail->product_id)->name
								)); ?>

							<?php $this->beginWidget('zii.widgets.jui.CJuiDialog', array(
								'id' => 'product'.$i.'-dialog',
								// additional javascript options for the dialog plugin
								'options' => array(
									'title' => 'Product',
									'autoOpen' => false,
									'width' => 'auto',
									'modal' => true,
								),));
							?>
							
						<?php $this->widget('zii.widgets.grid.CGridView', array(
						'id'=>'product'.$i.'-grid',
						'dataProvider'=>$productDataProvider,
						'filter'=>$product,
						// 'summaryText'=>'',
						'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
						'pager'=>array(
						   'cssFile'=>false,
						   'header'=>'',
						),
						'selectionChanged'=>'js:function(id){
							$("#ConsignmentOutDetail_'.$i.'_product_id").val($.fn.yiiGridView.getSelection(id));
							$("#product'.$i.'-dialog").dialog("close");
							$.ajax({
								type: "POST",
								dataType: "JSON",
								url: "' . CController::createUrl('ajaxProduct', array('id' => '')) . '" + $.fn.yiiGridView.getSelection(id),
								data: $("form").serialize(),
								success: function(data) {
									$("#ConsignmentOutDetail_'.$i.'_product_name").val(data.name);
									$("#ConsignmentOutDetail_'.$i.'_sale_price").val(data.retail_price);
									
									

								},
							});
							$("#product'.$i.'-grid").find("tr.selected").each(function(){
			                   $(this).removeClass( "selected" );
			                });
						}',
						'columns'=>array(
							//'id',
							//'code',
							'name',
							'manufacturer_code',
							array('name'=>'product_master_category_name', 'value'=>'$data->productMasterCategory->name'),
							array('name'=>'product_sub_master_category_name', 'value'=>'$data->productSubMasterCategory->name'),
							array('name'=>'product_sub_category_name', 'value'=>'$data->productSubCategory->name'),
							'production_year',
							array('name'=>'product_brand_name', 'value'=>'$data->brand->name'),
							
						),	
					));?>
					<?php $this->endWidget(); ?>
					</td>
					<td><?php echo CHtml::activeTextField($detail,"[$i]quantity");?></td>
					<td><?php echo CHtml::activeTextField($detail,"[$i]sale_price");?></td>
					<td><?php
							echo CHtml::button('Count', array(
							'id' => 'count_'.$i,
							'style'=>'display:none',
							'onclick' =>'
								var qty = +$("#ConsignmentOutDetail_'.$i.'_quantity").val();
								var price = +$("#ConsignmentOutDetail_'.$i.'_sale_price").val();

								var total = qty * price;
								$("#ConsignmentOutDetail_'.$i.'_total_price").val(total);
								console.log(total);
							'));
						?>
						<?php echo CHtml::activeTextField($detail,"[$i]total_price");?></td>
					
					<td>
						<?php
						echo CHtml::button('X', array(
						'onclick' => CHtml::ajax(array(
							'type' => 'POST',
							'url' => CController::createUrl('ajaxHtmlRemoveDetail', array('id' => $consignmentOut->header->id, 'index' => $i)),
							'update' => '#product',
							)),
						));
						?>
					</td>
				</tr>	


				<?php
				Yii::app()->clientScript->registerScript('myjqueryCount'.$i,'
					$("#ConsignmentOutDetail_'.$i.'_sale_price,#ConsignmentOutDetail_'.$i.'_quantity").keyup(function(event){
						$("#count_'.$i.'").click();
						$("#total-button").click();
					});
				');
				?>

			<?php endforeach ?>
		</tbody>
	</table>
<?php endif ?>

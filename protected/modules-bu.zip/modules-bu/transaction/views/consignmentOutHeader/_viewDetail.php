<fieldset>
			<legend>Details</legend>

			<table>
				<thead>
					<tr>
						<th>Product Name</th>
						<th>Quantity</th>
						<!-- <th>Received Quantity</th>
						<th>Quantity Left</th> -->
						<th>Price</th>
						<th>Total Price</th>
						
					</tr>
				</thead>
				<tbody>
					<?php foreach ($details as $key => $detail): ?>
						<tr>
							<td><?php echo $detail->product->name; ?></td>
							<td><?php echo $detail->quantity; ?></td>
							<!-- <td><?php //echo $detail->qty_received == "" ? 0 : $detail->qty_received; ?></td>
							<td><?php //echo $detail->qty_request_left; ?></td> -->
							<td>Rp <?php echo $detail->sale_price; ?></td>
							<td>Rp <?php echo $detail->total_price; ?></td>
							
						</tr>
					<?php endforeach ?>
				</tbody>
			</table>
		</fieldset>	
<?php
/* @var $this ConsignmentOutHeaderController */
/* @var $consignmentOut->header ConsignmentOutHeader */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'consignment-out-header-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($consignmentOut->header); ?>

	<div class="row">
		<div class="large-6 columns">
	    	<div class="row collapse prefix-radius">
		        <div class="small-4 columns">
		        	<?php echo $form->labelEx($consignmentOut->header,'consignment_out_no', array('class'=>'prefix')); ?>
		        </div>
		        <div class="small-8 columns">
		        	<?php echo $form->textField($consignmentOut->header,'consignment_out_no',array('size'=>30,'maxlength'=>30)); ?>
					<?php echo $form->error($consignmentOut->header,'consignment_out_no'); ?>
		     	</div>
    		</div>
		</div>
	    <div class="large-6 columns">
	      <div class="row collapse prefix-radius">
	        <div class="small-4 columns">
	          	<?php echo $form->labelEx($consignmentOut->header,'sender_id', array('class'=>'prefix')); ?>
	        </div>
	        <div class="small-8 columns">
	          	<?php echo $form->textField($consignmentOut->header,'sender_id',array('readonly'=>true,'value'=>$consignmentOut->header->isNewRecord ? Yii::app()->user->getId() : $consignmentOut->header->sender_id)); ?>
				<?php echo $form->error($consignmentOut->header,'sender_id'); ?>
	        </div>
	      </div>
	    </div>

	</div>

	<div class="row">
		<div class="large-6 columns">
			<div class="row collapse prefix-radius">
		        <div class="small-4 columns">
		        	<?php echo $form->labelEx($consignmentOut->header,'date_posting', array('class'=>'prefix')); ?>
		        </div>
		        <div class="small-8 columns">
		        	<?php //echo $form->textField($consignmentOut->header,'date_posting'); ?>
		        	<?php $this->widget('zii.widgets.jui.CJuiDatePicker',array(
									'model' => $consignmentOut->header,
									'attribute' => "date_posting",
									'options'=>array(
										'dateFormat' => 'yy-mm-dd',
										'changeMonth'=>true,
										'changeYear'=>true,
										'yearRange'=>'1900:2020'
										),
									'htmlOptions'=>array(
										'value'=>date('Y-m-d'),
				                        //'value'=>$customer->header->isNewRecord ? '' : Customer::model()->findByPk($customer->header->id)->birthdate,
										),
									));
						?>
					<?php echo $form->error($consignmentOut->header,'date_posting'); ?>
		      	</div>
			</div>
		</div>

	    <div class="large-6 columns">
	      <div class="row collapse prefix-radius">
	        <div class="small-4 columns">
	          	<?php echo $form->labelEx($consignmentOut->header,'branch_id', array('class'=>'prefix')); ?>
	        </div>
	        <div class="small-8 columns">
	          	<?php //echo $form->textField($consignmentOut->header,'branch_id'); ?>
	          	<?php echo $form->dropDownlist($consignmentOut->header,'branch_id',CHtml::listData(Branch::model()->findAll(),'id','name'),array('prompt'=>'[--Select Branch--]')); ?>
				<?php echo $form->error($consignmentOut->header,'branch_id'); ?>
	        </div>
	      </div>
	    </div>

	</div>


	<div class="row">
		<div class="small-12 medium-6 columns">

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($consignmentOut->header,'status', array('class'=>'prefix')); ?>
					</div>
					<div class="small-8 columns">
						<?php //echo $form->textField($consignmentOut->header,'status',array('size'=>10,'maxlength'=>10)); ?>
						<?php if($consignmentOut->header->isNewRecord){
									echo $form->textField($consignmentOut->header,'status',array('value'=>'Draft','readonly'=>true));
								}else{
									echo $form->dropDownList($consignmentOut->header, 'status', array('Draft'=>'Draft','Revised' => 'Revised','Rejected'=>'Rejected','Approved'=>'Approved','Done'=>'Done'),array('prompt'=>'[--Select status Document--]'));
								} 
						?>
						<?php echo $form->error($consignmentOut->header,'status'); ?>
					</div>
				</div>
			</div>		

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($consignmentOut->header,'customer_id', array('class'=>'prefix')); ?>
					</div>
					<div class="small-2 columns">
						<a class="button expand" href="<?php echo Yii::app()->baseUrl.'/master/customer/create';?>"><span class="fa fa-plus"></span>Add</a>
					</div>
					<div class="small-6 columns">
						<?php echo CHtml::activeHiddenField($consignmentOut->header,'customer_id'); ?>
								<?php echo CHtml::activeTextField($consignmentOut->header,'customer_name',array(
									'size'=>15,
									'maxlength'=>10,
									'readonly'=>true,
										//'disabled'=>true,
									'onclick' => '$("#customer-dialog").dialog("open"); return false;',
									'onkeypress' => 'if (event.keyCode == 13) { $("#customer-dialog").dialog("open"); return false; }',
									'value' =>$consignmentOut->header->customer_id == "" ? '': Customer::model()->findByPk($consignmentOut->header->customer_id)->name
									)
								);
								?>
									<?php $this->beginWidget('zii.widgets.jui.CJuiDialog', array(
										'id' => 'customer-dialog',
										// additional javascript options for the dialog plugin
										'options' => array(
											'title' => 'Customer',
											'autoOpen' => false,
											'width' => 'auto',
											'modal' => true,
											),)
									);
									?>

									<?php $this->widget('zii.widgets.grid.CGridView', array(
										'id'=>'customer-grid',
										'dataProvider'=>$customerDataProvider,
										'filter'=>$customer,
										'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
										'pager'=>array(
											'cssFile'=>false,
											'header'=>'',
											),
										'selectionChanged'=>'js:function(id){
											$("#ConsignmentOutHeader_customer_id").val($.fn.yiiGridView.getSelection(id));
											$("#customer-dialog").dialog("close");
											$.ajax({
												type: "POST",
												dataType: "JSON",
												url: "' . CController::createUrl('ajaxCustomer', array('id' => '')) . '" + $.fn.yiiGridView.getSelection(id),
												data: $("form").serialize(),
												success: function(data) {
													$("#ConsignmentOutHeader_customer_name").val(data.name);		                        	
													                      	
												},
											});
										$("#customer-grid").find("tr.selected").each(function(){
													$(this).removeClass( "selected" );
												});
										}',
										'columns'=>array('name')
										)
									); ?>
						<?php $this->endWidget(); ?>
						
						<?php echo $form->error($consignmentOut->header,'customer_id'); ?>
					</div>
				</div>
			</div>		

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($consignmentOut->header,'delivery_date', array('class'=>'prefix')); ?>
					</div>
					<div class="small-8 columns">
						<?php //echo $form->textField($consignmentOut->header,'delivery_date'); ?>
						<?php $this->widget('zii.widgets.jui.CJuiDatePicker',array(
									'model' => $consignmentOut->header,
									'attribute' => "delivery_date",
									'options'=>array(
										'dateFormat' => 'yy-mm-dd',
										'changeMonth'=>true,
										'changeYear'=>true,
										'yearRange'=>'1900:2020'
										),
									'htmlOptions'=>array(
										'value'=>date('Y-m-d'),
				                        //'value'=>$customer->header->isNewRecord ? '' : Customer::model()->findByPk($customer->header->id)->birthdate,
										),
									));
						?>
						<?php echo $form->error($consignmentOut->header,'delivery_date'); ?>
					</div>
				</div>
			</div>	

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<?php echo $form->labelEx($consignmentOut->header,'periodic', array('class'=>'prefix')); ?>
					</div>
					<div class="small-7 columns">
						<?php echo $form->textField($consignmentOut->header,'periodic'); ?>
						<?php echo $form->error($consignmentOut->header,'periodic'); ?>
					</div>
					<div class="small-1 columns">
						<label class="postfix" >days</label>
					</div>
				</div>
			</div>

		</div>
	</div>
	<div class="row">

				<div class="large-6 columns">
			      <div class="row collapse prefix-radius">
			        <div class="small-4 columns">
			        	<?php echo $form->labelEx($consignmentOut->header,'total_price', array('class'=>'prefix')); ?>
			        </div>
			        <div class="small-8 columns">
			        	<?php echo $form->textField($consignmentOut->header,'total_price',array('size'=>18,'maxlength'=>18,'readonly'=>true)); ?>
						<?php echo $form->error($consignmentOut->header,'total_price'); ?>
			        </div>
			      </div>
			    </div>

			    <div class="large-6 columns">
			      <div class="row collapse prefix-radius">
			        <div class="small-4 columns">
			        	<?php echo $form->labelEx($consignmentOut->header,'total_quantity', array('class'=>'prefix')); ?>
			        </div>
			        <div class="small-8 columns">
			        	<?php echo $form->textField($consignmentOut->header,'total_quantity',array('readonly'=>true)); ?>
						<?php echo $form->error($consignmentOut->header,'total_quantity'); ?>
			        </div>
			      </div>
			    </div>

		    </div>
		<fieldset>
				<legend>Detail Product</legend>
				<div class="row">
					<div class="large-5 columns">
						<div class="small-6 columns">
							<?php 
								echo CHtml::button('Add Details', array(
									'id' => 'detail-button',
									'name' => 'Detail',
									'style' =>'width:100%',
									'onclick' => '
										jQuery.ajax({
											type: "POST",
											url: "' . CController::createUrl('ajaxHtmlAddDetail', array('id' => $consignmentOut->header->id)) . '",
											data: jQuery("form").serialize(),
											success: function(html) {
												jQuery("#product").html(html);
											},
										});
			 							
									
								',
									)); 
								?>
						</div>
						<!-- <div class="small-4 columns">
							
							<?php 
								// echo CHtml::button('Add New Product', array(
								// 	'id' => 'detail-button',
								// 	'name' => 'Detail',
								// 	'style' =>'width:100%',
								// 	//'target'=>'_blank',
								// 	'onclick' => ' 
								// 		window.location.href = "'.Yii::app()->baseUrl.'/master/product/create/"',
									
								
								//  )); 
							?>
						</div> -->
						<div class="small-6 columns">
							
							<?php 
								echo CHtml::button('Count Total', array(
									'id' => 'total-button',
									'name' => 'Total',
									'style' =>'width:100%',
									'onclick' => '
									$.ajax({
					                  type: "POST",
					                  url: "' . CController::createUrl('ajaxGetTotal', array('id' => $consignmentOut->header->id,)) . '",
					                  data: $("form").serialize(),
					                  dataType: "json",
					                  success: function(data) {
					                      //console.log(data.total);
					                  	//console.log(data.requestType);
					                      $("#ConsignmentOutHeader_total_price").val(data.total);
					                      $("#ConsignmentOutHeader_total_quantity").val(data.total_items);
					                      
					                  },
					                });',)); 
	                		?>
						
						</div>
					</div>
				</div>

				<br>
				<div class="row">
					<div class="large-12 columns">
						<div class="detail" id="product">
							<?php $this->renderPartial('_detail', array('consignmentOut'=>$consignmentOut,'product'=>$product,
									'productDataProvider'=>$productDataProvider,
								));
							?>
						</div>
					</div>	
				</div>
			</fieldset>
			<div class="field buttons text-center">
				<?php echo CHtml::submitButton($consignmentOut->header->isNewRecord ? 'Create' : 'Save', array('class'=>'button cbutton')); ?>
			</div>
		

<?php $this->endWidget(); ?>

</div><!-- form -->
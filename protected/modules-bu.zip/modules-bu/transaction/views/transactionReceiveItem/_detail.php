	
	<?php if($receiveItem->header->request_type == 'Purchase Order'){
			$itemHeaders= TransactionReceiveItem::model()->findAllByAttributes(array('purchase_order_id'=>$receiveItem->header->purchase_order_id));
	
	}elseif($receiveItem->header->request_type == 'Transfer Request'){ ?>
	<?php $itemHeaders= TransactionReceiveItem::model()->findAllByAttributes(array('transfer_request_id'=>$receiveItem->header->transfer_request_id)); ?>
	<?php }else $itemHeaders= array(); ?>

	<?php if (count($itemHeaders)!= 0): ?>
		<table>
		<caption>History</caption>
		<thead>
			<tr>
				<td>Product</td>
				<td>Qty Request</td>
				<td>Qty Received</td>
				<td>Qty Request Left</td>
				<td>Note</td>
				<td>Barcode</td>
			</tr>
		</thead>
		<tbody>
		<?php foreach ($itemHeaders as $key => $itemHeader): ?>
			<?php $receiveItemDetails = TransactionReceiveItemDetail::model()->findAllByAttributes(array('receive_item_id'=>$itemHeader->id)); ?>
			<?php foreach ($receiveItemDetails as $key => $receiveItemDetail): ?>
		
			<tr>
				<td><?php echo $receiveItemDetail->product_id; ?></td>
				<td><?php echo $receiveItemDetail->qty_request; ?></td>
				<td><?php echo $receiveItemDetail->qty_received; ?></td>
				<td><?php echo $receiveItemDetail->qty_request_left; ?></td>
				<td><?php echo $receiveItemDetail->note; ?></td>
				<td><?php echo $receiveItemDetail->barcode_product; ?></td>
			</tr>
		
		<?php endforeach ?>
	<?php endforeach ?>
	<?php endif ?>
	
	
	
	</tbody>
	</table>
	

	<?php if(count($receiveItem->details) != 0) {	?>
	<?php $request = isset($_POST['TransactionReceiveItem']['request_type'])? $_POST['TransactionReceiveItem']['request_type'] : $receiveItem->header->request_type; ?>
	<table>
		<thead>
	
			<tr>
				<td>Product</td>
				<td>Qty Request</td>
				<td class ="additional <?php echo $request != "Internal Delivery Order" ? 'hide' : ''; ?>">Qty Delivered</td>
				<td class ="additional <?php echo $request != "Internal Delivery Order" ? 'hide' : ''; ?>">Qty Delivered Left</td>
				<td>Qty Request Left</td>
				<td>Qty Received</td>
				<td>Note</td>
				<td>Barcode</td>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($receiveItem->details as $i => $detail): ?>
				<tr>
					
					<td><?php echo CHtml::activeHiddenField($detail,"[$i]purchase_order_detail_id");  ?>
					<?php echo CHtml::activeHiddenField($detail,"[$i]transfer_request_detail_id");  ?>
					<?php echo CHtml::activeHiddenField($detail,"[$i]delivery_order_detail_id");  ?>
					<?php echo CHtml::activeHiddenField($detail,"[$i]consignment_in_detail_id");  ?>
							<?php echo CHtml::activeHiddenField($detail,"[$i]product_id");  ?>
							<?php $product = Product::model()->findByPK($detail->product_id); ?>
							<?php echo CHtml::activeTextField($detail,"[$i]product_name",array('value'=>$product->name,'readOnly'=>true));  ?>
					</td>
					<td><?php echo CHtml::activeTextField($detail,"[$i]qty_request",array('readOnly'=>true)); ?></td>
					<?php 
						$deliverValue ="";
						if($request == "Internal Delivery Order"){
							$delivered = TransactionDeliveryOrderDetail::model()->findByPK($detail->delivery_order_detail_id);
							$deliverValue = $delivered->quantity_delivery;
						}
						

					 ?>
					<td class="additional <?php echo $request != "Internal Delivery Order" ? 'hide' : ''; ?>"><?php echo CHtml::activeTextField($detail,"[$i]quantity_delivered",array('readOnly'=>true,
					));  ?></td>
					<td class="additional <?php echo $request != "Internal Delivery Order" ? 'hide' : ''; ?>"><?php echo CHtml::activeTextField($detail,"[$i]quantity_delivered_left",array('readOnly'=>true,
					));  ?></td>
						<td><?php echo CHtml::activeTextField($detail,"[$i]qty_request_left",array('rel'=>$detail->qty_request_left,'readOnly'=>true,
					));  ?></td>
					</td>
					<td><?php echo CHtml::activeTextField($detail,"[$i]qty_received",array('rel'=>$detail->qty_received,'onchange'=>
								'
								var nilaiawal = +$("#TransactionReceiveItemDetail_'.$i.'_qty_received").attr("rel");
								var quantity = +jQuery("#TransactionReceiveItemDetail_'.$i.'_qty_request").val();
								var receive = +jQuery("#TransactionReceiveItemDetail_'.$i.'_qty_received").val();
								var temp = +jQuery("#TransactionReceiveItemDetail_'.$i.'_qty_request_left").val();
								
								var delivered = +jQuery("#TransactionReceiveItemDetail_'.$i.'_quantity_delivered").val();
								var deliveredLeft = +jQuery("#TransactionReceiveItemDetail_'.$i.'_quantity_delivered_left").val();
								var type = jQuery("#TransactionReceiveItem_request_type").val()
								//alert(quantity);
								if(type == "Internal Delivery Order"){
									var count = deliveredLeft + nilaiawal;

								}
								else
								{
									var count = temp + nilaiawal;
								}
								
								console.log(nilaiawal);
								
								if(receive > count)
								{
									alert("Quantity Receive Cannot be Greater than available Quantity");
									$( "#save" ).prop( "disabled", true );
								}else{
									$( "#save" ).prop( "disabled", false );

								}
								//jQuery("#TransactionReceiveItemDetail_'.$i.'_qty_request_left").val(count);
								//console.log(count);
								

								'));  ?></td>
					
				
					<td><?php echo CHtml::activeTextField($detail,"[$i]note");  ?></td>
					<td><?php echo CHtml::activeTextField($detail,"[$i]barcode_product"); ?></td>
					<td>
							<?php
						    echo CHtml::button('X', array(
						     	'onclick' => CHtml::ajax(array(
							       	'type' => 'POST',
							       	'url' => CController::createUrl('ajaxHtmlRemoveDetail', array('id' => $receiveItem->header->id, 'index' => $i)),
							       	'update' => '.detail',
					      		)),
					     	));
				     	?>
						</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
		
	</table>
	<?php }?>
	
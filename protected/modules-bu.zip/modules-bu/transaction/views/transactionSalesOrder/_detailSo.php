<table>
	<tr>
		<td width="10%">Product : <?php echo CHtml::activeHiddenField($detail, "[$i]product_id", array('size'=>20,'maxlength'=>20)); ?></td>
		<td width="85%">		
			<?php echo CHtml::activeTextField($detail,"[$i]product_name",array(
				'size'=>15,
				'maxlength'=>10,
				'readonly'=>true,
				'value' => $detail->product_id == "" ? '': Product::model()->findByPk($detail->product_id)->name
				)
			);
			?>
		</td>
		<td width="5%">
			<?php
			echo CHtml::button('X', array(
				'onclick' => CHtml::ajax(array(
					'type' => 'POST',
					'url' => CController::createUrl('ajaxHtmlRemoveDetail', array('id' => $salesOrder->header->id, 'index' => $i)),
					'update' => '#detail',
					)),
				)
			);
			?>
		</td>
	</tr>
	<tr>
		<td colspan="3">
			<div class="row">
				<div class="medium-6 columns">
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Quantity</label>
							</div>
							<div class="small-7 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]quantity"); ?>
								 
								
							</div>
							<div class="small-1 columns">
								<?php echo CHtml::button('...', array(
							            'id' => 'real-button',
							            'name' => 'Real',
							            
							            'onclick' => ' 
							            if($("#TransactionSalesOrder_requester_branch_id").val() == ""){
							            	alert("Please choose Branch First");
							            }else{
							            	javascript:window.open("'. CController::createUrl('showProduct', array('productId'=>$detail->product_id,'branchId'=>$salesOrder->header->requester_branch_id)) .'","x","height=600,width=600,left=100"); return false;
							            }
							              
							              '
							            )); ?>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Selling Price</label>
							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]retail_price",array('readonly'=>true)); ?>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Unit</label>
							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]unit_id"); ?>
							</div>
						</div>
					</div>

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">hpp</label>
							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]hpp",array('readonly'=>true, 'value'=>$detail->product_id !="" ? Product::model()->findByPk($detail->product_id)->hpp:'0')); ?>
							</div>
						</div>
					</div>
					
				</div>

				<div class="medium-6 columns">

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Discount Step</label>
							</div>
							<div class="small-8 columns">
								<div class="row">
									<div class="small-8 columns">
										<?php echo CHtml::activeDropDownList($detail, "[$i]discount_step", array('1' => '1', '2' => '2','3'=>'3','4'=>'4','5'=>'5'),array(
											'prompt'=>'[--Select Discount step--]')
										); 
										?>
									</div>
									<div class="small-2 columns">
										<?php echo CHtml::button('Add', array(
											'id'=>'add'.$i,
											'onclick' => '
											var step = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount_step").val();
											stepbtn'.$i.' = step;
											switch (step) {
												case 1:
												$("#step1_'.$i.'").show();
												$("#step2_'.$i.'").hide();
												$("#step3_'.$i.'").hide();
												$("#step4_'.$i.'").hide();
												$("#step5_'.$i.'").hide();
												break;
												case 2:
												$("#step1_'.$i.'").show();
												$("#step2_'.$i.'").show();
												$("#step3_'.$i.'").hide();
												$("#step4_'.$i.'").hide();
												$("#step5_'.$i.'").hide();
												break;
												case 3:
												$("#step1_'.$i.'").show();
												$("#step2_'.$i.'").show();
												$("#step3_'.$i.'").show();
												$("#step4_'.$i.'").hide();
												$("#step5_'.$i.'").hide();
												break;
												case 4:
												$("#step1_'.$i.'").show();
												$("#step2_'.$i.'").show();
												$("#step3_'.$i.'").show();
												$("#step4_'.$i.'").show();
												$("#step5_'.$i.'").hide();
												break;
												case 5:
												$("#step1_'.$i.'").show();
												$("#step2_'.$i.'").show();
												$("#step3_'.$i.'").show();
												$("#step4_'.$i.'").show();
												$("#step5_'.$i.'").show();
												break;

												default:
												$("#step1_'.$i.'").hide();
												$("#step2_'.$i.'").hide();
												$("#step3_'.$i.'").hide();
												$("#step4_'.$i.'").hide();
												$("#step5_'.$i.'").hide();

												break;
											}

											'
											)
										);
										?>
									</div>
									<div class="small-2 columns text-right">
										<?php echo CHtml::button('Count', array(
											'id' => 'count_'.$i,
											'onclick' =>

											'var step = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount_step").val();
											switch (step) {
												case 1:
												$("#TransactionSalesOrderDetail_'.$i.'_total_quantity").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount1_temp_quantity").val());
												$("#TransactionSalesOrderDetail_'.$i.'_total_price").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount1_temp_price").val());
												$("#TransactionSalesOrderDetail_'.$i.'_subtotal").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount1_temp_price").attr("realPrice"));
											$("#TransactionSalesOrderDetail_'.$i.'_discount").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount1_temp_price").attr("rel"));
												$.ajax({
													type: "POST",

													url: "' . CController::createUrl('ajaxCountTotal', array()) . '/totalquantity/" +$("#TransactionSalesOrderDetail_'.$i.'_total_quantity").val()+"/totalprice/"+$("#TransactionSalesOrderDetail_'.$i.'_total_price").val(),


													data: $("form").serialize(),
													dataType: "json",
													success: function(data) {
														console.log(data.unitprice);
														$("#TransactionSalesOrderDetail_'.$i.'_unit_price").val(data.unitprice);

													},});
												break;
												case 2:
													$("#TransactionSalesOrderDetail_'.$i.'_total_quantity").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount2_temp_quantity").val());
													$("#TransactionSalesOrderDetail_'.$i.'_total_price").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount2_temp_price").val());
													$("#TransactionSalesOrderDetail_'.$i.'_subtotal").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount2_temp_price").attr("realPrice"));
													$("#TransactionSalesOrderDetail_'.$i.'_discount").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount2_temp_price").attr("rel"));
													$.ajax({
														type: "POST",

														url: "' . CController::createUrl('ajaxCountTotal', array()) . '/totalquantity/" +$("#TransactionSalesOrderDetail_'.$i.'_total_quantity").val()+"/totalprice/"+$("#TransactionSalesOrderDetail_'.$i.'_total_price").val(),


														data: $("form").serialize(),
														dataType: "json",
														success: function(data) {
															console.log(data.unitprice);
															$("#TransactionSalesOrderDetail_'.$i.'_unit_price").val(data.unitprice);

														},});
												break;
												case 3:
													$("#TransactionSalesOrderDetail_'.$i.'_total_quantity").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount3_temp_quantity").val());
													$("#TransactionSalesOrderDetail_'.$i.'_total_price").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount3_temp_price").val());
													$("#TransactionSalesOrderDetail_'.$i.'_subtotal").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount3_temp_price").attr("realPrice"));
													$("#TransactionSalesOrderDetail_'.$i.'_discount").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount3_temp_price").attr("rel"));
													$.ajax({
													type: "POST",

													url: "' . CController::createUrl('ajaxCountTotal', array()) . '/totalquantity/" +$("#TransactionSalesOrderDetail_'.$i.'_total_quantity").val()+"/totalprice/"+$("#TransactionSalesOrderDetail_'.$i.'_total_price").val(),


													data: $("form").serialize(),
													dataType: "json",
													success: function(data) {
														console.log(data.unitprice);
														$("#TransactionSalesOrderDetail_'.$i.'_unit_price").val(data.unitprice);

													},});
												break;
												case 4:
													$("#TransactionSalesOrderDetail_'.$i.'_total_quantity").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount4_temp_quantity").val());
													$("#TransactionSalesOrderDetail_'.$i.'_total_price").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount4_temp_price").val());
													$("#TransactionSalesOrderDetail_'.$i.'_subtotal").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount4_temp_price").attr("realPrice"));
													$("#TransactionSalesOrderDetail_'.$i.'_discount").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount4_temp_price").attr("rel"));
													$.ajax({
													type: "POST",

													url: "' . CController::createUrl('ajaxCountTotal', array()) . '/totalquantity/" +$("#TransactionSalesOrderDetail_'.$i.'_total_quantity").val()+"/totalprice/"+$("#TransactionSalesOrderDetail_'.$i.'_total_price").val(),

													data: $("form").serialize(),
													dataType: "json",
													success: function(data) {
														console.log(data.unitprice);
														$("#TransactionSalesOrderDetail_'.$i.'_unit_price").val(data.unitprice);

													},});
												break;
												case 5:
													$("#TransactionSalesOrderDetail_'.$i.'_total_quantity").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount5_temp_quantity").val());
													$("#TransactionSalesOrderDetail_'.$i.'_total_price").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount5_temp_price").val());
													$("#TransactionSalesOrderDetail_'.$i.'_subtotal").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount5_temp_price").attr("realPrice"));
													$("#TransactionSalesOrderDetail_'.$i.'_discount").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_discount5_temp_price").attr("rel"));
													$.ajax({
													type: "POST",

													url: "' . CController::createUrl('ajaxCountTotal', array()) . '/totalquantity/" +$("#TransactionSalesOrderDetail_'.$i.'_total_quantity").val()+"/totalprice/"+$("#TransactionSalesOrderDetail_'.$i.'_total_price").val(),


													data: $("form").serialize(),
													dataType: "json",
													success: function(data) {
														console.log(data.unitprice);
														$("#TransactionSalesOrderDetail_'.$i.'_unit_price").val(data.unitprice);

													},});
												break;

												default:
													$("#TransactionSalesOrderDetail_'.$i.'_total_quantity").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_quantity").val());
													$("#TransactionSalesOrderDetail_'.$i.'_total_price").val(jQuery("#TransactionSalesOrderDetail_'.$i.'_retail_price").val());
													
													$("#TransactionSalesOrderDetail_'.$i.'_discount").val("0");
													$.ajax({
														type: "POST",

														url: "' . CController::createUrl('ajaxCountTotalNonDiscount', array()) . '/totalquantity/" +$("#TransactionSalesOrderDetail_'.$i.'_total_quantity").val()+"/totalprice/"+$("#TransactionSalesOrderDetail_'.$i.'_total_price").val(),


														data: $("form").serialize(),
														dataType: "json",
														success: function(data) {
															console.log(data.unitprice);
															$("#TransactionSalesOrderDetail_'.$i.'_unit_price").val(data.unitprice);
															$("#TransactionSalesOrderDetail_'.$i.'_total_price").val(data.price);
															$("#TransactionSalesOrderDetail_'.$i.'_subtotal").val(data.price);
					
														},});
													break;

												}'
											));?>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- //step1 -->
					<div class="field" id="step1_<?php echo $i; ?>">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Step 1</label>
							</div>
							<div class="small-8 columns">
								<div class="row">
									<div class="small-3 columns">
										<?php echo CHtml::activeDropDownList($detail, "[$i]discount1_type", array('1' => 'Percent','2' => 'Amount','3'=>'Bonus'),array('prompt'=>'[--Select Discount Type--]'));?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount1_nominal");
										
										?>
										<?php echo CHtml::button('Count', array(
											'id' => 'count_step1_'.$i,
											'style'=>'display:none;',
											'onclick' =>'var quantity = +jQuery("#TransactionSalesOrderDetail_'.$i.'_quantity").val();
											var retail = +jQuery("#TransactionSalesOrderDetail_'.$i.'_retail_price").val();
											var discountType = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount1_type").val();
											var discountAmount = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount1_nominal").val();
											$.ajax({
												type: "POST",

												url: "' . CController::createUrl('ajaxCountAmount', array()) . '/discountType/" +discountType+"/discountAmount/"+discountAmount+"/retail/" +retail+"/quantity/"+quantity,


												data: $("form").serialize(),
												dataType: "json",
												success: function(data) {
													console.log(data.subtotal);
													console.log(data.totalquantity);
													console.log(data.newPrice);
													console.log(data.discountAmount);
													$("#TransactionSalesOrderDetail_'.$i.'_discount1_temp_price").val(data.subtotal);
													$("#TransactionSalesOrderDetail_'.$i.'_discount1_temp_price").attr("rel",data.discountAmount);
													$("#TransactionSalesOrderDetail_'.$i.'_discount1_temp_price").attr("realPrice",data.price);
													$("#TransactionSalesOrderDetail_'.$i.'_discount1_temp_quantity").val(data.totalquantity);

												},});'
										));?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount1_temp_price",array('readonly'=>true)); ?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount1_temp_quantity",array('readonly'=>true)); ?>
									</div>
								</div>
							</div>
						</div>
					</div>

					<!-- //step2 -->
					<div class="field" id="step2_<?php echo $i; ?>">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Step 2</label>
							</div>
							<div class="small-8 columns">
								<div class="row">
									<div class="small-3 columns">
										<?php echo CHtml::activeDropDownList($detail, "[$i]discount2_type", array('1' => 'Percent', '2' => 'Amount','3'=>'Bonus'),array('prompt'=>'[--Select Discount Type--]'));?>

									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount2_nominal"); 
										
										?>
										<?php echo CHtml::button('Count', array(
											'id' => 'count_step2_'.$i,
											'style'=>'display:none;',
											'onclick' =>'var quantity = +jQuery("#TransactionSalesOrderDetail_'.$i.'_quantity").val();
											var retail = +jQuery("#TransactionSalesOrderDetail_'.$i.'_retail_price").val();
											var discountType = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount2_type").val();
											var discountAmount = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount2_nominal").val();
											var price = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount1_temp_price").val();;

											$.ajax({
												type: "POST",

												url: "' . CController::createUrl('ajaxCountAmountStep', array()) . '/discountType/" +discountType+"/discountAmount/"+discountAmount+"/retail/" +retail+"/quantity/"+quantity+"/price/"+price,


												data: $("form").serialize(),
												dataType: "json",
												success: function(data) {
													console.log(data.subtotal);
													console.log(data.totalquantity);
													console.log(data.newPrice);
													$("#TransactionSalesOrderDetail_'.$i.'_discount2_temp_price").val(data.subtotal);
													$("#TransactionSalesOrderDetail_'.$i.'_discount2_temp_price").attr("rel",data.discountAmount);
													$("#TransactionSalesOrderDetail_'.$i.'_discount2_temp_price").attr("realPrice",data.oriPrice);
													$("#TransactionSalesOrderDetail_'.$i.'_discount2_temp_quantity").val(data.totalquantity);
												},});')); ?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount2_temp_price",array('readonly'=>true)); ?>

									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount2_temp_quantity",array('readonly'=>true)); ?>
									</div>
								</div>
							</div>
						</div>
					</div>

					<!-- //step3 -->
					<div class="field" id="step3_<?php echo $i; ?>">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Step 3</label>
							</div>
							<div class="small-8 columns">
								<div class="row">
									<div class="small-3 columns">
										<?php echo CHtml::activeDropDownList($detail, "[$i]discount3_type", array('1' => 'Percent', '2' => 'Amount','3'=>'Bonus'),array('prompt'=>'[--Select Discount Type--]'));?>
										
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount3_nominal"
										); 
										?>
										<?php echo CHtml::button('Count', array(
											'id' => 'count_step3_'.$i,
											'style'=>'display:none;',
											'onclick' =>'var quantity = +jQuery("#TransactionSalesOrderDetail_'.$i.'_quantity").val();
											var retail = +jQuery("#TransactionSalesOrderDetail_'.$i.'_retail_price").val();
											var discountType = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount3_type").val();
											var discountAmount = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount3_nominal").val();
											var price = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount2_temp_price").val();;

											$.ajax({
												type: "POST",

												url: "' . CController::createUrl('ajaxCountAmountStep', array()) . '/discountType/" +discountType+"/discountAmount/"+discountAmount+"/retail/" +retail+"/quantity/"+quantity+"/price/"+price,


												data: $("form").serialize(),
												dataType: "json",
												success: function(data) {
													console.log(data.subtotal);
													console.log(data.totalquantity);
													console.log(data.newPrice);
													$("#TransactionSalesOrderDetail_'.$i.'_discount3_temp_price").val(data.subtotal);
													$("#TransactionSalesOrderDetail_'.$i.'_discount3_temp_price").attr("rel",data.discountAmount);
													$("#TransactionSalesOrderDetail_'.$i.'_discount3_temp_price").attr("realPrice",data.oriPrice);
													$("#TransactionSalesOrderDetail_'.$i.'_discount3_temp_quantity").val(data.totalquantity);
												},});'


												)
										); ?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount3_temp_price",array('readonly'=>true, )); ?>

									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount3_temp_quantity",array('readonly'=>true)); ?>

									</div>
								</div>

							</div>
						</div>
					</div>

					<!-- //step4 -->
					<div class="field" id="step4_<?php echo $i; ?>">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Step 4</label>
							</div>
							<div class="small-8 columns">
								<div class="row">
									<div class="small-3 columns">
										<?php echo CHtml::activeDropDownList($detail, "[$i]discount4_type", array('1' => 'Percent','2' => 'Amount','3'=>'Bonus'),array('prompt'=>'[--Select Discount Type--]'));?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount4_nominal"
										); 
										?>
										<?php echo CHtml::button('Count', array(
											'id' => 'count_step4_'.$i,
											'style'=>'display:none;',
											'onclick' =>'var quantity = +jQuery("#TransactionSalesOrderDetail_'.$i.'_quantity").val();
											var retail = +jQuery("#TransactionSalesOrderDetail_'.$i.'_retail_price").val();
											var discountType = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount4_type").val();
											var discountAmount = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount4_nominal").val();
											var price = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount3_temp_price").val();;

											$.ajax({
												type: "POST",

												url: "' . CController::createUrl('ajaxCountAmountStep', array()) . '/discountType/" +discountType+"/discountAmount/"+discountAmount+"/retail/" +retail+"/quantity/"+quantity+"/price/"+price,


												data: $("form").serialize(),
												dataType: "json",
												success: function(data) {
													console.log(data.subtotal);
													console.log(data.totalquantity);
													console.log(data.newPrice);
													$("#TransactionSalesOrderDetail_'.$i.'_discount4_temp_price").val(data.subtotal);
													$("#TransactionSalesOrderDetail_'.$i.'_discount4_temp_price").attr("rel",data.discountAmount);
													$("#TransactionSalesOrderDetail_'.$i.'_discount4_temp_price").attr("realPrice",data.oriPrice);
													$("#TransactionSalesOrderDetail_'.$i.'_discount4_temp_quantity").val(data.totalquantity);
												},});'


												)
										); 
										?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount4_temp_price",array('readonly'=>true, )); ?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount4_temp_quantity",array('readonly'=>true)); ?>
									</div>
								</div>
							</div>
						</div>
					</div>

					<!-- //spte 5 -->
					<div class="field" id="step5_<?php echo $i; ?>">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Step 5</label>
							</div>
							<div class="small-8 columns">
								<div class="row">
									<div class="small-3 columns">
										<?php echo CHtml::activeDropDownList($detail, "[$i]discount5_type", array('1' => 'Percent','2' => 'Amount','3'=>'Bonus'),array('prompt'=>'[--Select Discount Type--]'));?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount5_nominal"
										); 
										?>
										<?php echo CHtml::button('Count', array(
											'id' => 'count_step5_'.$i,
											'style'=>'display:none;',
											'onclick' =>'var quantity = +jQuery("#TransactionSalesOrderDetail_'.$i.'_quantity").val();
											var retail = +jQuery("#TransactionSalesOrderDetail_'.$i.'_retail_price").val();
											var discountType = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount5_type").val();
											var discountAmount = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount5_nominal").val();
											var price = +jQuery("#TransactionSalesOrderDetail_'.$i.'_discount4_temp_price").val();;

											$.ajax({
												type: "POST",

												url: "' . CController::createUrl('ajaxCountAmountStep', array()) . '/discountType/" +discountType+"/discountAmount/"+discountAmount+"/retail/" +retail+"/quantity/"+quantity+"/price/"+price,


												data: $("form").serialize(),
												dataType: "json",
												success: function(data) {
													console.log(data.subtotal);
													console.log(data.totalquantity);
													console.log(data.newPrice);
													$("#TransactionSalesOrderDetail_'.$i.'_discount5_temp_price").val(data.subtotal);
													$("#TransactionSalesOrderDetail_'.$i.'_discount5_temp_price").attr("rel",data.discountAmount);
													$("#TransactionSalesOrderDetail_'.$i.'_discount5_temp_price").attr("realPrice",data.oriPrice);
													$("#TransactionSalesOrderDetail_'.$i.'_discount5_temp_quantity").val(data.totalquantity);
												},});'


												)
										); 
										?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount5_temp_price",array('readonly'=>true, )); ?>
									</div>
									<div class="small-3 columns">
										<?php echo CHtml::activeTextField($detail,"[$i]discount5_temp_quantity",array('readonly'=>true)); ?>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Total Quantity</label>
							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]total_quantity",array('readonly'=>true)); ?>
							</div>
						</div>
					</div>

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Unit Price</label>
							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]unit_price",array('readonly'=>true, ));?>
							</div>
						</div>
					</div>

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Subtotal</label>
							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]subtotal",array('readonly'=>true, )); ?>
							</div>
						</div>
					</div>

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Discount</label>
							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]discount",array('readonly'=>true, )); ?>
							</div>
						</div>
					</div>

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix">Total Price</label>
							</div>
							<div class="small-8 columns">
								<?php echo CHtml::activeTextField($detail,"[$i]total_price",array('readonly'=>true, )); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</td>
	</tr>
</table>


<?php
Yii::app()->clientScript->registerScript('myjqueryCount'.$i,'

    function callme_stepbtn() {
        if (stepbtn'.$i.' == 1 ) {
			$("#TransactionSalesOrderDetail_'.$i.'_quantity,#TransactionSalesOrderDetail_'.$i.'_discount1_nominal").keyup(function(event){
				$("#count_step1_'.$i.'").click();
			});
		}else if (stepbtn'.$i.' == 2 ) {
			$("#TransactionSalesOrderDetail_'.$i.'_quantity,#TransactionSalesOrderDetail_'.$i.'_discount1_nominal,#TransactionSalesOrderDetail_'.$i.'_discount2_nominal").keyup(function(event){
				$("#count_step1_'.$i.'").click();
				$("#count_step2_'.$i.'").click();
			});
		}else if (stepbtn'.$i.' == 3 ) {
			$("#TransactionSalesOrderDetail_'.$i.'_quantity,#TransactionSalesOrderDetail_'.$i.'_discount1_nominal,#TransactionSalesOrderDetail_'.$i.'_discount2_nominal,#TransactionSalesOrderDetail_'.$i.'_discount3_nominal").keyup(function(event){
				$("#count_step1_'.$i.'").click();
				$("#count_step2_'.$i.'").click();
				$("#count_step3_'.$i.'").click();
			});
		}else if (stepbtn'.$i.' == 4 ) {
			$("#TransactionSalesOrderDetail_'.$i.'_quantity,#TransactionSalesOrderDetail_'.$i.'_discount1_nominal,#TransactionSalesOrderDetail_'.$i.'_discount2_nominal,#TransactionSalesOrderDetail_'.$i.'_discount3_nominal,#TransactionSalesOrderDetail_'.$i.'_discount4_nominal").keyup(function(event){
				$("#count_step1_'.$i.'").click();
				$("#count_step2_'.$i.'").click();
				$("#count_step3_'.$i.'").click();
				$("#count_step4_'.$i.'").click();
			});
		}else if (stepbtn'.$i.' == 5) {
			$("#TransactionSalesOrderDetail_'.$i.'_quantity,#TransactionSalesOrderDetail_'.$i.'_discount1_nominal,#TransactionSalesOrderDetail_'.$i.'_discount2_nominal,#TransactionSalesOrderDetail_'.$i.'_discount3_nominal,#TransactionSalesOrderDetail_'.$i.'_discount4_nominal,#TransactionSalesOrderDetail_'.$i.'_discount5_nominal").keyup(function(event){
				$("#count_step1_'.$i.'").click();
				$("#count_step2_'.$i.'").click();
				$("#count_step3_'.$i.'").click();
				$("#count_step4_'.$i.'").click();
				$("#count_step5_'.$i.'").click();
			});
		}
		// $("#count_'.$i.'").click();
    }

	$("#TransactionSalesOrderDetail_'.$i.'_quantity,#TransactionSalesOrderDetail_'.$i.'_discount1_nominal,#TransactionSalesOrderDetail_'.$i.'_discount2_nominal,#TransactionSalesOrderDetail_'.$i.'_discount3_nominal,#TransactionSalesOrderDetail_'.$i.'_discount4_nominal,#TransactionSalesOrderDetail_'.$i.'_discount5_nominal,#TransactionSalesOrderDetail_'.$i.'_discount_step").keyup(function(event){
		callme_stepbtn();
	});

	$("#add'.$i.'").click(function() {
		callme_stepbtn();
	});
');
?>


<?php
	Yii::app()->clientScript->registerScript('myjavascript', '
		$(".numbers").number( true,2, ".", ",");
    ', CClientScript::POS_END);
?>
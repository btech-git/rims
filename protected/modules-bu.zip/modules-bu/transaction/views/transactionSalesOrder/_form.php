<?php
/* @var $this TransactionPurchaseOrderController */
/* @var $salesOrder->header TransactionPurchaseOrder */
/* @var $form CActiveForm */
?>
<div class="clearfix page-action">
<?php echo CHtml::link('<span class="fa fa-list"></span>Manage Sales Order', Yii::app()->baseUrl.'/transaction/transactionSalesOrder/admin', array('class'=>'button cbutton right', 'visible'=>Yii::app()->user->checkAccess("transaction.transactionSalesOrder.admin"))) ?>
<h1><?php if($salesOrder->header->id==""){ echo "New Transaction Sales Order"; }else{ echo "Update Transaction Sales Order";}?></h1>
<!-- begin FORM -->
<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'transaction-purchase-order-form',
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($salesOrder->header); ?>
	<?php echo $form->errorSummary($salesOrder->details); ?>

	<div class="row">
		<div class="small-12 medium-6 columns">			 

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
					  <label class="prefix"><?php echo $form->labelEx($salesOrder->header,'sale_order_no'); ?></label>
					  </div>
					<div class="small-8 columns">
						<?php echo $form->textField($salesOrder->header,'sale_order_no',array('size'=>30,'maxlength'=>30)); ?>
						<?php echo $form->error($salesOrder->header,'sale_order_no'); ?>
					</div>
				</div>
		 	</div>

		 	<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
					  <label class="prefix"><?php echo $form->labelEx($salesOrder->header,'sale_order_date'); ?></label>
					  </div>
					<div class="small-8 columns">
						
						<?php //echo $form->textField($salesOrder->header,'purchase_order_date'); ?>
						<?php $this->widget('zii.widgets.jui.CJuiDatePicker',array(
                    'model' => $salesOrder->header,
                     'attribute' => "sale_order_date",
                     // additional javascript options for the date picker plugin
                     'options'=>array(
                         'dateFormat' => 'yy-mm-dd',
                         'changeMonth'=>true,
        								 'changeYear'=>true,
        								 'yearRange'=>'1900:2020'
                     ),
                      'htmlOptions'=>array(
                      	'value'=>$salesOrder->header->isNewRecord ? date('Y-m-d') : $salesOrder->header->sale_order_date,
                        //'value'=>$customer->header->isNewRecord ? '' : Customer::model()->findByPk($customer->header->id)->birthdate,
                        ),
                 ));
                ?>
						<?php echo $form->error($salesOrder->header,'sale_order_date'); ?>
					</div>
				</div>
		 	</div>

			<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
						<label class="prefix"><?php echo $form->labelEx($salesOrder->header,'status_document'); ?></label>
					</div>
					<div class="small-8 columns">
						<?php echo $form->textField($salesOrder->header,'status_document',array('value'=>$salesOrder->header->isNewRecord ? 'Draft' : $salesOrder->header->status_document,'readonly'=>true)); ?>
							<?php //if($salesOrder->header->isNewRecord)
							// {
								
							// 	echo $form->textField($salesOrder->header,'status_document',array('value'=>'Draft','readonly'=>true));
							// }
							// else
							// {
							// 	echo $form->dropDownList($salesOrder->header, 'status_document', array('Draft'=>'Draft','Revised' => 'Revised','Rejected'=>'Rejected','Approved'=>'Approved','Done'=>'Done'),array('prompt'=>'[--Select Status Document--]'));
							// } 
						?>
						<?php echo $form->error($salesOrder->header,'status_document'); ?>
					</div>
				</div>
		 	</div>
		 	<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
					  <label class="prefix"><?php echo $form->labelEx($salesOrder->header,'customer_id'); ?></label>
					  </div>
					 <div class="small-2 columns">
						<a class="button expand" href="<?php echo Yii::app()->baseUrl.'/master/customer/create';?>"><span class="fa fa-plus"></span>Add</a>
					</div>
					<div class="small-6 columns">
						
						<?php echo CHtml::activeHiddenField($salesOrder->header,'customer_id'); ?>
						<?php //echo CHtml::activeHiddenField($salesOrder->header,'cust_type'); ?>
						<?php //echo CHtml::activeHiddenField($salesOrder->header,'coa'); ?>
					<?php echo CHtml::activeTextField($salesOrder->header,'customer_name',
						array(
							'size'=>15,
							'maxlength'=>10,
							'readonly'=>true,
							//'disabled'=>true,
							'onclick' => '$("#customer-dialog").dialog("open"); return false;',
			            	'onkeypress' => 'if (event.keyCode == 13) { $("#customer-dialog").dialog("open"); return false; }',
			            	'value' =>$salesOrder->header->customer_id == "" ? '': Customer::model()->findByPk($salesOrder->header->customer_id)->name
						));
					?>

					<?php $this->beginWidget('zii.widgets.jui.CJuiDialog', array(
						'id' => 'customer-dialog',
						// additional javascript options for the dialog plugin
						'options' => array(
							'title' => 'Customer',
							'autoOpen' => false,
							'width' => 'auto',
							'modal' => true,
						),));
					?>

					<?php $this->widget('zii.widgets.grid.CGridView', array(
						'id'=>'customer-grid',
						'dataProvider'=>$customerDataProvider,
						'filter'=>$customer,
						'selectionChanged'=>'js:function(id){
							$("#TransactionSalesOrder_customer_id").val($.fn.yiiGridView.getSelection(id));
							$("#customer-dialog").dialog("close");
							$.ajax({
								type: "POST",
								dataType: "JSON",
								url: "' . CController::createUrl('ajaxCustomer', array('id' => '')) . '" + $.fn.yiiGridView.getSelection(id),
								data: $("form").serialize(),
								success: function(data) {
									$("#TransactionSalesOrder_customer_name").val(data.name);		                        	
									$("#TransactionSalesOrder_cust_type").val(data.type);		                        	
									$("#TransactionSalesOrder_coa_customer").val(data.coa);		                        	
									$("#TransactionSalesOrder_coa_name").val(data.coa_name);		                        	
									$("#TransactionSalesOrder_estimate_payment_date").val(data.paymentEstimation);		
									//$("#detail-button").attr("disabled", false);
									if(data.coa == ""){
										$("#payment-text").show();
										$("#payment-ddl").hide();
										$("#payment-ddl select").attr("disabled","disabled");
									}
									else{
										$("#payment-text").hide();
										$("#payment-ddl").show();
										$("#payment-ddl select").prop("disabled", false);
									}
									// if(data.type == "Company"){
									// 	if(data.coa == ""){
									// 		$("#payment-text").show();
									// 		$("#payment-ddl").hide();
									// 	}
									// 	else{
									// 		$("#payment-text").hide();
									// 		$("#payment-ddl").show();
									// 	}
									// }
									// else{
									// 		$("#payment-text").hide();
									// 		$("#payment-ddl").show();
									// 	}
									
								},
							});
						}',
						'template' => '{items}<div class="clearfix">{summary}{pager}</div>',
						'pager'=>array(
						   'cssFile'=>false,
						   'header'=>'',
						),
						'columns'=>array(
							//'kode',
							'name',
							'email',
							'customer_type',
						),
					)); ?>
					<?php $this->endWidget(); ?>
					
						<?php echo $form->error($salesOrder->header,'customer_id'); ?>
					</div>
				</div>
		 	</div>

		 	<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
					  <label class="prefix"><?php echo $form->labelEx($salesOrder->header,'requester_id'); ?></label>
					  </div>
					<div class="small-8 columns">
						<?php echo $form->hiddenField($salesOrder->header,'requester_id',array('size'=>30,'maxlength'=>30,'value'=>$salesOrder->header->isNewRecord ?Yii::app()->user->getId() : $salesOrder->header->requester_id,'readonly'=>true)); ?>
						<?php echo $form->textField($salesOrder->header,'requester_name',array('size'=>30,'maxlength'=>30,'value'=>$salesOrder->header->isNewRecord ?Yii::app()->user->getName() : $salesOrder->header->user->username,'readonly'=>true)); ?>
						<?php echo $form->error($salesOrder->header,'requester_id'); ?>
					</div>
				</div>
		 	</div>

		 	<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
					  <label class="prefix"><?php echo $form->labelEx($salesOrder->header,'requester_branch_id'); ?></label>
					  </div>
					<div class="small-8 columns">
						<?php //echo $form->dropDownlist($salesOrder->header,'requester_branch_id',CHtml::listData(Branch::model()->findAll(),'id','name'),array('prompt'=>'[--Select Branch--]',
						// 		'onchange'=> 'jQuery.ajax({
						// 				type: "POST",
						// 				url: "' . CController::createUrl('ajaxGetCompanyBank') . '",
						// 				data: jQuery("form").serialize(),
						// 				success: function(data){
						// 		    	console.log(data);
						// 		    	jQuery("#TransactionSalesOrder_company_bank_id").html(data);
						// 			},
						// 		});'
						// )); 
						?>
						<?php echo $form->hiddenField($salesOrder->header,'requester_branch_id',array('value'=>$salesOrder->header->isNewRecord ? Branch::model()->findByPk(User::model()->findByPk(Yii::app()->user->getId())->branch_id)->id : $salesOrder->header->requester_branch_id,'readonly'=>true)); ?>
							<?php echo $form->textField($salesOrder->header,'requester_branch_name',array('value'=>$salesOrder->header->isNewRecord ? Branch::model()->findByPk(User::model()->findByPk(Yii::app()->user->getId())->branch_id)->name : $salesOrder->header->requesterBranch->name,'readonly'=>true)); ?>
								<?php //echo $form->dropDownlist($requestOrder->header,'requester_branch_id',CHtml::listData(Branch::model()->findAll(),'id','name'),array('prompt'=>'[--Select Branch--]')); ?>
						<?php echo $form->error($salesOrder->header,'requester_branch_id'); ?>
					</div>
				</div>
		 	</div>


					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix"><?php echo $form->labelEx($salesOrder->header,'company_bank_id'); ?></label>
							</div>
							<div class="small-8 columns">
								<?php 
									$branchId = $salesOrder->header->isNewRecord ? User::model()->findByPk(Yii::app()->user->getId())->branch_id : $salesOrder->header->requester_branch_id;
									$branch = Branch::model()->findByPk($branchId);
									$company = Company::model()->findByPk($branch->company_id);
									
								 ?>
								<?php echo $form->dropDownlist($salesOrder->header,'company_bank_id',$company == NULL ? array() :CHtml::listData(CompanyBank::model()->findAllByAttributes(array('company_id'=>$company->id), array('order' => 'account_name')),'id','name'),array('prompt'=>'[--Select Company Bank--]',
										// 'onchange'=> 'jQuery.ajax({
						    //               		type: "POST",
						    //               		url: "' . CController::createUrl('ajaxGetCoa') . '",
						    //               		data: jQuery("form").serialize(),
						    //               		dataType: "json",
										// 		success: function(data) {
						    //                     	console.log(data);
						    //                     	jQuery("#TransactionSalesOrder_coa_id").val(data.coa);
						    //                     	jQuery("#TransactionSalesOrder_coa_name").val(data.coa_name);
						    //                 	},
						    //             	});'
								)); ?>
								<?php echo $form->error($salesOrder->header,'company_bank_id'); ?>
							</div>
						</div>
					</div>		

					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix"><?php echo $form->labelEx($salesOrder->header,'coa_customer'); ?></label>
							</div>
							<div class="small-8 columns">
								<?php echo $form->hiddenField($salesOrder->header,'coa_customer'); ?>
								<?php echo $form->textField($salesOrder->header,'coa_name',array('readonly'=>true,'value'=>$salesOrder->header->coa_customer != ""? Coa::model()->findByPk($salesOrder->coa_customer)->name : '')); ?>
								
								
								<?php echo $form->error($salesOrder->header,'coa_customer'); ?>
							</div>
						</div>
					</div> 

		 	<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
					  <label class="prefix"><?php echo $form->labelEx($salesOrder->header,'estimate_arrival_date'); ?></label>
					  </div>
					<div class="small-8 columns">
						
						<?php $this->widget('zii.widgets.jui.CJuiDatePicker',array(
                    'model' => $salesOrder->header,
                     'attribute' => "estimate_arrival_date",
                     // additional javascript options for the date picker plugin
                     'options'=>array(
                         'dateFormat' => 'yy-mm-dd',
                         'changeMonth'=>true,
        								 'changeYear'=>true,
        								 'yearRange'=>'1900:2020'
                     ),
                      'htmlOptions'=>array(
                      	'value'=>$salesOrder->header->isNewRecord ? date('Y-m-d') : $salesOrder->header->estimate_arrival_date,
                        //'value'=>$customer->header->isNewRecord ? '' : Customer::model()->findByPk($customer->header->id)->birthdate,
                        ),
                 ));
                ?>
						<?php echo $form->error($salesOrder->header,'estimate_arrival_date'); ?>
					</div>
				</div>
		 	</div>

		 	<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
					  <label class="prefix"><?php echo $form->labelEx($salesOrder->header,'estimate_payment_date'); ?></label>
					  </div>
					<div class="small-8 columns">
						
						<?php $this->widget('zii.widgets.jui.CJuiDatePicker',array(
                    'model' => $salesOrder->header,
                     'attribute' => "estimate_payment_date",
                     // additional javascript options for the date picker plugin
                     'options'=>array(
                         'dateFormat' => 'yy-mm-dd',
                         'changeMonth'=>true,
        								 'changeYear'=>true,
        								 'yearRange'=>'1900:2020'
                     ),
                      'htmlOptions'=>array(
                      	'value'=>$salesOrder->header->isNewRecord ? date('Y-m-d') : $salesOrder->header->estimate_payment_date,
                        //'value'=>$customer->header->isNewRecord ? '' : Customer::model()->findByPk($customer->header->id)->birthdate,
                        ),
                 ));
                ?>
						<?php echo $form->error($salesOrder->header,'estimate_payment_date'); ?>
					</div>
				</div>
		 	</div>
			
		 	<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix"><?php echo $form->labelEx($salesOrder->header,'payment_type'); ?></label>
							</div>
							<div class="small-8 columns">
								
								<div id="payment-text">
									<?php echo $form->textField($salesOrder->header, 'payment_type',array('readonly'=>true,'value'=>'Cash')); ?>
								</div>
								<div id="payment-ddl">
									<?php echo $form->dropDownList($salesOrder->header, 'payment_type', array('Cash'=>'Cash','Credit' => 'Credit'),array('prompt'=>'[--Select Payment type--]','onchange'=> 'jQuery.ajax({
						                  		type: "POST",
						                  		url: "' . CController::createUrl('ajaxGetDate', array('type' => '')) . '" + $(this).val(),
						                  		data: jQuery("form").serialize(),
						                  		dataType: "json",
						                  		success: function(data){
						                        	// console.log(data.tanggal);
						                        	// console.log(data.type);
						                        	jQuery("#TransactionSalesOrder_estimate_payment_date").val(data.tanggal);
						                    	},
						                	});')); ?>
								</div>
								
								<?php echo $form->error($salesOrder->header,'payment_type'); ?>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix"><?php echo $form->labelEx($salesOrder->header,'ppn'); ?></label>
							</div>
							<div class="small-8 columns">
								<?php //echo $form->textArea($requestOrder->header,'status_document',array('rows'=>6, 'cols'=>50)); ?>
								<?php echo $form->dropDownList($salesOrder->header, 'ppn', array('1'=>'PPN','2' => 'Non PPN')); ?>
								<?php echo $form->error($salesOrder->header,'ppn'); ?>
							</div>
						</div>
					</div>
			
		 	<div class="field">
			 	<div class="row collapse">
			 			<div class="small-12 columns">
			 				<?php echo CHtml::button('Add Details', array(
								'id' => 'detail-button',
								'name' => 'Detail',
								
								
								'onclick' => '$("#product-dialog").dialog("open"); return false;
									jQuery.ajax({
									type: "POST",
									url: "' . CController::createUrl('ajaxHtmlAddDetail', array('id' => $salesOrder->header->id)) . '",
									data: jQuery("form").serialize(),
									success: function(html) {
										jQuery("#detail").html(html);
									},
								});',
								)
							); ?>
							
							<?php
			    Yii::app()->clientScript->registerScript('updateGridView', '
			        $.updateGridView = function(gridID, name, value) {
			            $("#"+gridID+" input[name=\""+name+"\"], #"+gridID+" select[name=\""+name+"\"]").val(value);
			            $.fn.yiiGridView.update(gridID, {data: $.param(
			                $("#"+gridID+" .filters input, #"+gridID+" .filters select")
			            )});
			        }
			    ', CClientScript::POS_READY);
			?>
					<?php $this->beginWidget('zii.widgets.jui.CJuiDialog', array(
						'id' => 'product-dialog',
						// additional javascript options for the dialog plugin
						'options' => array(
							'title' => 'Product',
							'autoOpen' => false,
							'width' => 'auto',
							'modal' => true,
						),));
					?>
					
					<div class="row">
						<div class="small-12 columns" style="padding-left: 0px; padding-right: 0px;">

							<?php $this->widget('zii.widgets.grid.CGridView', array(
									'id'=>'product-grid',
									'dataProvider'=>$productDataProvider,
									'filter'=>$product,
									'template' => '<div style="overflow-x:scroll ; overflow-y: hidden; margin-bottom: 1.25rem;">{items}</div><div class="clearfix">{summary}{pager}</div>',	
									'pager'=>array(
									   'cssFile'=>false,
									   'header'=>'',
									),
									'selectionChanged'=>'js:function(id){
										
										$("#product-dialog").dialog("close");
										$.ajax({
											type: "POST",
											dataType: "html",
											url: "' . CController::createUrl('ajaxHtmlAddDetail', array('id'=>$salesOrder->header->id,'productId'=>'')). '" + $.fn.yiiGridView.getSelection(id),
											data: $("form").serialize(),
											success: function(data) {
												$("#detail").html(data);
												
												
												
										
											},
										});
										
										
										
										$("#product-grid").find("tr.selected").each(function(){
						                   $(this).removeClass( "selected" );
						                });
									}',
									'columns'=>array(
										'id',
										//'code',
										'name',
										'manufacturer_code',
										array('name'=>'product_master_category_name', 'value'=>'$data->productMasterCategory->name'),
										array('name'=>'product_sub_master_category_name', 'value'=>'$data->productSubMasterCategory->name'),
										array('name'=>'product_sub_category_name', 'value'=>'$data->productSubCategory->name'),
										'production_year',
										array('name'=>'product_brand_name', 'value'=>'$data->brand->name'),
										//array('name'=>'product_supplier','value'=>'$data->product_supplier'),
									),
								));?>
							</div>
						</div>
						<?php $this->endWidget(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
			<div id="detail">
		 		<?php $this->renderPartial('_detailSalesOrder', array('salesOrder'=>$salesOrder,)); ?>
		 	</div>

		<div class="row">
		<div class="small-12 medium-6 columns">			 
			<div class="field">
				<div class="row collapse">
					<div class="small-12 columns">
						<?php echo CHtml::button('Total', array(
								'id' => 'detail-button',
								'name' => 'Detail',
								'onclick' => '
								$.ajax({
                  type: "POST",
                  url: "' . CController::createUrl('ajaxGetTotal', array('id' => $salesOrder->header->id,)) . '",
                  data: $("form").serialize(),
                  dataType: "json",
                  success: function(data) {
                      //console.log(data.total);
                  	console.log(data.requestType);
                      
                      $("#TransactionSalesOrder_total_price").val(data.total);
						$("#TransactionSalesOrder_total_quantity").val(data.totalItems);
						$("#TransactionSalesOrder_subtotal").val(data.subtotal);
						$("#TransactionSalesOrder_price_before_discount").val(data.priceBeforeDisc);
						$("#TransactionSalesOrder_discount").val(data.discount);
						$("#TransactionSalesOrder_ppn_price").val(data.ppn);
                      

                  },
                });',)); ?>
					</div>
				</div>
			</div>
			<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix"><?php echo $form->labelEx($salesOrder->header,'price_before_discount'); ?></label>
							</div>
							<div class="small-8 columns">
								<?php echo $form->textField($salesOrder->header,'price_before_discount',array('size'=>18,'maxlength'=>18,'readonly'=>'true')); ?>
								<?php echo $form->error($salesOrder->header,'price_before_discount'); ?>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix"><?php echo $form->labelEx($salesOrder->header,'discount'); ?></label>
							</div>
							<div class="small-8 columns">
								<?php echo $form->textField($salesOrder->header,'discount',array('size'=>18,'maxlength'=>18,'readonly'=>'true')); ?>
								<?php echo $form->error($salesOrder->header,'discount'); ?>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix"><?php echo $form->labelEx($salesOrder->header,'subtotal'); ?></label>
							</div>
							<div class="small-8 columns">
								<?php echo $form->textField($salesOrder->header,'subtotal',array('size'=>18,'maxlength'=>18,'readonly'=>'true')); ?>
								<?php echo $form->error($salesOrder->header,'subtotal'); ?>
							</div>
						</div>
					</div>
					<div class="field">
						<div class="row collapse">
							<div class="small-4 columns">
								<label class="prefix"><?php echo $form->labelEx($salesOrder->header,'ppn_price'); ?></label>
							</div>
							<div class="small-8 columns">
								<?php echo $form->textField($salesOrder->header,'ppn_price',array('size'=>18,'maxlength'=>18,'readonly'=>'true')); ?>
								<?php echo $form->error($salesOrder->header,'ppn_price'); ?>
							</div>
						</div>
					</div>
		 	<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
					  <label class="prefix"><?php echo $form->labelEx($salesOrder->header,'total_price'); ?></label>
					  </div>
					<div class="small-8 columns">
						
						<?php echo $form->textField($salesOrder->header,'total_price',array('size'=>18,'maxlength'=>18)); ?>
						<?php echo $form->error($salesOrder->header,'total_price'); ?>
					</div>
				</div>
		 	</div>		

		 			

		 	<div class="field">
				<div class="row collapse">
					<div class="small-4 columns">
					  <label class="prefix"><?php echo $form->labelEx($salesOrder->header,'total_quantity'); ?></label>
					  </div>
					<div class="small-8 columns">
						
						<?php echo $form->textField($salesOrder->header,'total_quantity'); ?>
						<?php echo $form->error($salesOrder->header,'total_quantity'); ?>
					</div>
				</div>
		 	</div>

		 


		</div>
	</div>

	<div class="field buttons text-center">
		<?php echo CHtml::submitButton($salesOrder->header->isNewRecord ? 'Create' : 'Save', array('class'=>'button cbutton')); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->


<?php
	Yii::app()->clientScript->registerScriptFile(Yii::app()->baseUrl . '/js/vendor/jquery.number.min.js', CClientScript::POS_HEAD);
	Yii::app()->clientScript->registerScript('myjavascript', '
		//$(".numbers").number( true,2, ".", ",");
    ', CClientScript::POS_END);
?>
<script>
var type = $("#TransactionSalesOrder_cust_type").val();
var coa = $("#TransactionSalesOrder_coa_customer").val();
	
		if(coa == ""){
			$("#payment-text").show();
			$("#payment-ddl").hide();
			$("#payment-ddl select").attr("disabled","disabled");
		}
		else{
			$("#payment-text").hide();
			$("#payment-ddl").show();
			$("#payment-ddl select").prop("disabled", false);
		}
	// if(type == "Company"){}
	// else{
	// 		$("#payment-text").hide();
	// 		$("#payment-ddl").show();
	// 	}
	
</script>
<?php if (count($sentDetails)>0): ?>
		<table>
			<thead>
				<tr>
					<td>Product</td>
					<td>Quantity</td>
					<td>Unit Price (HPP)</td>
					<td>Unit</td>
					<td>Amount</td>
					
				</tr>
			</thead>
			<tbody>
				<?php foreach ($sentDetails as $key => $sentDetail): ?>
					<tr>
						<td><?php echo $sentDetail->product_id != "" ? $sentDetail->product->name : '-'; ?></td>
						<td><?php echo $sentDetail->quantity; ?></td>
						<td><?php echo $sentDetail->unit_price; ?></td>
						<td><?php echo $sentDetail->unit_id; ?></td>
						<td><?php echo $sentDetail->amount; ?></td>
						
						
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>

	<?php else: ?>
		<?php echo "No Detail Available!"; ?>
	<?php endif ?>
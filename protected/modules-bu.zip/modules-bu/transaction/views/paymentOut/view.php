<?php
/* @var $this PaymentOutController */
/* @var $model PaymentOut */

$this->breadcrumbs=array(
	'Payment Outs'=>array('index'),
	$model->id,
);

$this->menu=array(
	array('label'=>'List PaymentOut', 'url'=>array('index')),
	array('label'=>'Create PaymentOut', 'url'=>array('create')),
	array('label'=>'Update PaymentOut', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Delete PaymentOut', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage PaymentOut', 'url'=>array('admin')),
);
?>

<!--<h1>View PaymentOut #<?php echo $model->id; ?></h1>-->
<div id="maincontent">
	<div class="clearfix page-action">
		<?php $ccontroller = Yii::app()->controller->id; ?>
		<?php $ccaction = Yii::app()->controller->action->id; ?>
		<?php echo CHtml::link('<span class="fa fa-th-list"></span>Manage Payment Out', Yii::app()->baseUrl.'/transaction/paymentOut/admin' , array('class'=>'button cbutton right','style'=>'margin-right:10px', 'visible'=>Yii::app()->user->checkAccess("transaction.paymentOut.admin"))) ?>
		<?php if ($model->status != 'Approved'): ?>
			<?php //echo CHtml::link('<span class="fa fa-edit"></span>Edit', Yii::app()->baseUrl.'/transaction/paymentOut/update?id=' . $model->id, array('class'=>'button cbutton right','style'=>'margin-right:10px', 'visible'=>Yii::app()->user->checkAccess("transaction.paymentOut.update"))) ?>
			<?php echo CHtml::link('<span class="fa fa-edit"></span>Update Approval', Yii::app()->baseUrl.'/transaction/paymentOut/updateApproval?headerId=' . $model->id , array('class'=>'button cbutton right','style'=>'margin-right:10px', 'visible'=>Yii::app()->user->checkAccess("transaction.paymentOut.updateApproval"))) ?>
		<?php endif; ?>
		<h1>View PaymentOut #<?php echo $model->id; ?></h1>

		<?php //$this->widget('zii.widgets.CDetailView', array(
			// 'data'=>$model,
			// 'attributes'=>array(
			// 	'id',
			// 'purchase_order_id',
			// 'payment_number',
			// 'payment_date',
			// 'supplier_id',
			// 'payment_amount',
			// 'notes',
			// 'user_id',
			// 'branch_id',
			// ),
		//)); ?>
	</div>
	<div class="row">
		<div class="large-12 columns">
			<fieldset>
				<legend>Payment</legend>
					<div class="row">
					<div class="large-6 columns">
						
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Payment #</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo $model->payment_number; ?>"> 
								</div>
							</div>
						</div>
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Payment Date</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo $model->payment_date; ?>"> 
								</div>
							</div>
						</div>
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Payment Amount</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo $model->payment_amount; ?>"> 
								</div>
							</div>
						</div>
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Payment type</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo $model->payment_type; ?>"> 
								</div>
							</div>
						</div>
						<?php if ($model->payment_type == "Giro"): ?>
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">No giro</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" value="<?php echo $model->nomor_giro; ?>"> 
									</div>
								</div>
							</div>
						<?php endif ?>
							
						
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Status</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo $model->status; ?>"> 
								</div>
							</div>
						</div>

					</div>
			

					<div class="large-6 columns">
						
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">User</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo $model->user_id; ?>"> 
								</div>
							</div>
						</div>
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Branch</span>
								</div>
								<div class="small-8 columns">
									<input type="text" readonly="true" value="<?php echo $model->branch->name; ?>"> 
								</div>
							</div>
						</div>
						<div class="field">
							<div class="row collapse">
								<div class="small-4 columns">
									<span class="prefix">Notes</span>
								</div>
								<div class="small-8 columns">
									<textarea name="" id="" cols="30" rows="4" readonly="true"><?php echo $model->notes; ?></textarea>
									
								</div>
							</div>

						</div>
					</div>
				</div>
				
			</fieldset>

			<fieldset>
				<legend>Approval Status</legend>
				<table>
					<thead>
						<tr>
				 			<th>Approval type</th>
				 			<th>Revision</th>
				 			<th>date</th>
				 			<th>note</th>
				 			<th>supervisor</th>
				 		</tr>
					</thead>
					<tbody>
						<?php foreach ($revisionHistories as $key => $history): ?>
							<tr>
					 			<td><?php echo $history->approval_type; ?></td>
					 			<td><?php echo $history->revision; ?></td>
					 			<td><?php echo $history->date; ?></td>
					 			<td><?php echo $history->note; ?></td>
					 			<td><?php echo $history->supervisor_id; ?></td>
					 		</tr>
						<?php endforeach ?>
					</tbody>
				</table>
			</fieldset>

			<fieldset>
						<legend>Purchase Order</legend>
						<div class="large-6 columns">
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Purchase Date</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" id="Purchase_purchase_order_date" value="<?php echo $model->purchase_order_id != "" ? $model->purchaseOrder->purchase_order_date :'' ?>" > 
									</div>
								</div>
							</div>
							
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Status</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" id="Purchase_status_document" value="<?php echo $model->purchase_order_id != "" ? $model->purchaseOrder->status_document :'' ?>"> 
									</div>
								</div>
							</div>
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Payment Status</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" id="Purchase_payment_status" value="<?php echo $model->purchase_order_id != "" ? $model->purchaseOrder->payment_status :'' ?>"> 
									</div>
								</div>
							</div>
						</div>
						
						<div class="large-6 columns">
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Total Price</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" id="Purchase_total_price" value="<?php echo $model->purchase_order_id != "" ? $model->purchaseOrder->total_price :'' ?>"> 
									</div>
								</div>
							</div>
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Payment Amount</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" id="Purchase_payment_amount" value="<?php echo $model->purchaseOrder->payment_amount != "" ? $model->purchaseOrder->payment_amount : '0,00' ?>"> 
									</div>
								</div>
							</div>
							<div class="field">
								<div class="row collapse">
									<div class="small-4 columns">
										<span class="prefix">Payment Left</span>
									</div>
									<div class="small-8 columns">
										<input type="text" readonly="true" value="<?php echo $model->purchaseOrder->payment_left != "" ? $model->purchaseOrder->payment_left : '0,00' ?>"> 
									</div>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Supplier</legend>
			
						
							<div class="large-6 columns">

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Name</span>
										</div>
										<div class="small-8 columns">
											
											<input type="text" readonly="true" id="Supplier_supplier_name" value="<?php echo $model->purchase_order_id != "" ? $model->purchaseOrder->supplier->name :'' ?>"> 
										</div>
									</div>
								</div>
								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Email</span>
										</div>
										<div class="small-8 columns">
											<input type="text" readonly="true" id="Supplier_email_personal" value="<?php echo $model->supplier_id != "" ? $model->supplier->email_personal : ''; ?>"> 
										</div>
									</div>
								</div>

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Company</span>
										</div>
										<div class="small-8 columns">
											
											<input type="text" readonly="true" id="Supplier_company" value="<?php echo $model->purchase_order_id != "" ? $model->purchaseOrder->supplier->company :'' ?>"> 
										</div>
									</div>
								</div>

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Email Company</span>
										</div>
										<div class="small-8 columns">
											
											<input type="text" readonly="true" id="Supplier_email_company" value="<?php echo $model->purchase_order_id != "" ? $model->purchaseOrder->supplier->email_company :'' ?>"> 
										</div>
									</div>
								</div>


								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Company Attribute</span>
										</div>
										<div class="small-8 columns">
											<input type="text" readonly="true" id="Supplier_company_attribute" value="<?php echo $model->supplier_id != "" ? $model->supplier->company_attribute :'' ?>"> 
										</div>
									</div>
								</div>

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Address</span>
										</div>
										<div class="small-8 columns">
											<textarea name="" id="Supplier_supplier_address" cols="30" rows="5" readonly="true"><?php echo $model->supplier_id != "" ? $model->supplier->address. '&#13;&#10;'. $model->supplier->province->name . '&#13;&#10;'. $model->supplier->city->name.'&#13;&#10;'.$model->supplier->zipcode : ''; ?></textarea>
										</div>
									</div>
								</div>

								


							</div> <!-- end div large -->
						
						
							<div class="large-6 columns">

								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Phone</span>
										</div>
										<div class="small-8 columns">
											<?php $getPhone = ""; ?>
											<?php if ($model->supplier_id != ""): ?>
												<?php $phones = SupplierPhone::model()->findAllByAttributes(array('supplier_id'=>$model->supplier_id,'status'=>'Active')); ?>
												
												<?php if (count($phones) > 0): ?>
													
													<?php foreach ($phones as $key => $phone): ?>
														<?php $getPhone = $phone->phone_no . '&#13;&#10;';  ?>
														<!-- <input type="text" readonly="true" value="<?php //?>">  -->
													<?php endforeach ?>
													</textarea>
												
												<?php endif ?>
												
											<?php endif ?>
											<textarea name="" id="Supplier_phones" cols="30" rows="5" readonly="true"><?php echo $getPhone; ?></textarea>
											
											
											
										</div>
									</div>
								</div>
								<div class="field">
									<div class="row collapse">
										<div class="small-4 columns">
											<span class="prefix">Mobile</span>
										</div>
										<div class="small-8 columns">
										<?php $getMobile = "" ?>
										<?php if ($model->supplier_id != ""): ?>
											<?php $mobiles = SupplierMobile::model()->findAllByAttributes(array('supplier_id'=>$model->supplier_id,'status'=>'Active')); ?>
											
											<?php if (count($mobiles) > 0): ?>
												
												<?php foreach ($mobiles as $key => $mobile): ?>
													<?php $getMobile .= $mobile->mobile_no. '&#13;&#10;'; ?>
													
												<?php endforeach ?>
												
											
												
											<?php endif ?>
											
										<?php endif ?>
											
											<textarea name="" id="Supplier_mobiles" cols="30" rows="5" readonly="true"><?php echo $getMobile ?></textarea>
											
										</div>
									</div>
								</div>
								
							
						</div>
					</fieldset>
			<fieldset>
				<legend>Attached Images</legend>

				<?php foreach ($postImages as $postImage):
										$dir = dirname(Yii::app()->request->scriptFile) . '/images/uploads/paymentOut/' . $model->id . '/' . $postImage->filename;
										$src = Yii::app()->baseUrl . '/images/uploads/paymentOut/' . $model->id . '/' . $postImage->filename;
									?>
									<div class="row">
										<div class="small-3 columns">
											<div style="margin-bottom:.5rem">
												<?php echo CHtml::image($src, $model->payment_number . "Image"); ?>
											</div>
										</div>
										<div class="small-8 columns">
											<div style="padding:.375rem .5rem; border:1px solid #ccc; background:#fff; font-size:.8125rem; line-height:1.4; margin-bottom:.5rem;">
												<?php echo (Yii::app()->baseUrl . '/images/uploads/paymentOut/' . $model->id . '/' . $postImage->filename); ?>
											</div>
										</div>
										
									</div>
									<?php endforeach; ?>
			</fieldset>
					
		</div>
	</div>
</div>

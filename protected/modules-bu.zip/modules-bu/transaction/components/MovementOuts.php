<?php

class MovementOuts extends CComponent
{
	public $header;
	public $details;
	
	

	public function __construct($header, array $details)
	{
		$this->header = $header;
		$this->details = $details;
		
	}

	
	public function addDetail($detailId,$type)
	{
		
		// $detail = new MovementInDetail();
	
		// $this->details[] = $detail;
		if($type == 1){
			$deliveryOrderDetail = TransactionDeliveryOrderDetail::model()->findByPk($detailId);
			$detail = new MovementOutDetail();
			$detail->delivery_order_detail_id = $deliveryOrderDetail->id;
			$detail->product_id = $deliveryOrderDetail->product_id;
			$detail->quantity_transaction = $deliveryOrderDetail->quantity_delivery;
			$this->details[] = $detail;
		}
		elseif ($type == 2) {
			$returnOrderDetail = TransactionReturnOrderDetail::model()->findByPk($detailId);
			$detail = new MovementOutDetail();
			$detail->return_order_detail_id = $returnOrderDetail->id;
			$detail->product_id = $returnOrderDetail->product_id;
			$detail->quantity_transaction = $returnOrderDetail->qty_reject;
			$this->details[] = $detail;
		}
		elseif ($type == 3) {
			$registrationProduct = RegistrationProduct::model()->findByPk($detailId);
			$detail = new MovementOutDetail();
			$detail->registration_product_id = $registrationProduct->id;
			$detail->product_id = $registrationProduct->product_id;
			$detail->quantity_transaction = $registrationProduct->quantity;
			$this->details[] = $detail;
		}
		
		
		
	}
	

	public function removeDetailAt($index)
	{
		array_splice($this->details, $index, 1);
		//var_dump(CJSON::encode($this->details));
	}
	public function removeDetailAll()
	{
		$this->details = array();
	}

	public function save($dbConnection)
	{
		$dbTransaction = $dbConnection->beginTransaction();
		try
		{
			$valid = $this->validate() && $this->flush();
			if ($valid){
				$dbTransaction->commit();
				//print_r('1');
			} else {
				$dbTransaction->rollback();
				//print_r('2');
			}

		}
		catch (Exception $e)
		{
			$dbTransaction->rollback();
			$valid = false;
			//print_r($e);
		}

		return $valid;
		//print_r('success');
	}

	public function validate()
	{
		$valid = $this->header->validate();

		
		if (count($this->details) > 0)
		{
			foreach ($this->details as $detail)
			{

				$fields = array('quantity');
				$valid = $detail->validate($fields) && $valid;
			}
		}
		else {
			$valid = true;
		}
		
		return $valid;
	}

	public function validateDetailsCount()
	{
		$valid = true;
		if (count($this->details) === 0)
		{
			$valid = false;
			$this->header->addError('error', 'Form tidak ada data untuk insert database. Minimal satu data detail untuk melakukan penyimpanan.');
		}

		return $valid;
	}


	public function flush()
	{
		$isNewRecord = $this->header->isNewRecord;
		$valid = $this->header->save();
		//echo "valid";

		$movementOutDetails  = MovementOutDetail::model()->findAllByAttributes(array('movement_out_header_id'=>$this->header->id));
		$detail_id = array();
		foreach($movementOutDetails as $movementOutDetail)
		{
			$detail_id[]=$movementOutDetail->id;
		}
		$new_detail= array();

		//print_r($this->details);
		//save request detail
		foreach ($this->details as $detail)
		{
			
			
			if($detail->id == ""){
				// $moveCriteria = new CDbCriteria();
				// $moveCriteria->condition = "product_id =".$detail->product_id ." AND warehouse_id = ".$detail->warehouse_id . " AND movement_out_header_id = ". $this->header->id ." AND id != ''";
				// $moveDetail = MovementOutDetail::model()->find($moveCriteria);
				$moveDetail = MovementOutDetail::model()->findByAttributes(array('movement_out_header_id'=>$this->header->id,'product_id'=>$detail->product_id,'warehouse_id'=>$detail->warehouse_id));
				if(count($moveDetail) != 0)
				{
					$moveDetail->quantity += $detail->quantity;
					$moveDetail->save() && $valid;
					//echo "test";
				}
				else{
					$detail->movement_out_header_id = $this->header->id;
					//$detail->request_order_quantity_rest = $detail->quantity;
					$valid = $detail->save() && $valid;
					//echo $detail->movement_out_header_id;

				}
			}//end if
			else{
				$detail->movement_out_header_id = $this->header->id;
					//$detail->request_order_quantity_rest = $detail->quantity;
				$valid = $detail->save() && $valid;
			}
				
			$movementType = $this->header->movement_type;
			if($movementType == 1){
				$criteria = new CDbCriteria;
				$criteria->together = 'true';
				$criteria->with = array('movementOutHeader');
				$criteria->condition="movementOutHeader.delivery_order_id =".$this->header->delivery_order_id ." AND movement_out_header_id != ".$this->header->id;
				$mvmntDetails = MovementOutDetail::model()->findAll($criteria);
				$quantity = 0;
				foreach($mvmntDetails as $mvmntDetail){
					$quantity += $mvmntDetail->quantity;
				}
				$deliveryDetail = TransactionDeliveryOrderDetail::model()->findByAttributes(array('id'=>$detail->delivery_order_detail_id,'delivery_order_id'=>$this->header->delivery_order_id));
				$deliveryDetail->quantity_movement_left = $detail->quantity_transaction -($detail->quantity + $quantity);
				$deliveryDetail->quantity_movement = $quantity + $detail->quantity;
				$deliveryDetail->save(false);
			}
			elseif ($movementType == 2) {
				$criteria = new CDbCriteria;
				$criteria->together = 'true';
				$criteria->with = array('movementOutHeader');
				$criteria->condition="movementOutHeader.return_order_id =".$this->header->return_order_id ." AND movement_out_header_id != ".$this->header->id;
				$mvmntDetails = MovementOutDetail::model()->findAll($criteria);
				$quantity = 0;
				foreach($mvmntDetails as $mvmntDetail){
					$quantity += $mvmntDetail->quantity;
				}
				$deliveryDetail = TransactionReturnOrderDetail::model()->findByAttributes(array('id'=>$detail->return_order_detail_id,'return_order_id'=>$this->header->return_order_id));
				$deliveryDetail->quantity_movement_left = $detail->quantity_transaction -($detail->quantity + $quantity);
				$deliveryDetail->quantity_movement = $quantity + $detail->quantity;
				$deliveryDetail->save(false);
			}
			elseif ($movementType == 3) {
				$criteria = new CDbCriteria;
				$criteria->together = 'true';
				$criteria->with = array('movementOutHeader');
				$criteria->condition="movementOutHeader.registration_transaction_id =".$this->header->registration_transaction_id ." AND movement_out_header_id != ".$this->header->id;
				$mvmntDetails = MovementOutDetail::model()->findAll($criteria);
				$quantity = 0;
				foreach($mvmntDetails as $mvmntDetail){
					$quantity += $mvmntDetail->quantity;
				}
				$deliveryDetail = RegistrationProduct::model()->findByAttributes(array('id'=>$detail->registration_product_id,'registration_transaction_id'=>$this->header->registration_transaction_id));
				$deliveryDetail->quantity_movement_left = $detail->quantity_transaction -($detail->quantity + $quantity);
				$deliveryDetail->quantity_movement = $quantity + $detail->quantity;
				$deliveryDetail->save(false);
			}
			
			
			//echo $detail->quantity;
			//echo "Movement: ".$deliveryDetail->quantity_movement;
			
			$new_detail[] = $detail->id;
			//echo 'test';
			if($detail->id == ""){
				echo $detail->quantity;
			}
			//echo $detail->id;
		}



		//delete details
		$delete_array= array_diff($detail_id, $new_detail);
		if($delete_array != NULL)
		{
			$criteria = new CDbCriteria;
			$criteria->addInCondition('id',$delete_array);
			MovementOutDetail::model()->deleteAll($criteria);
		}

		//print_r($this->details);
		return $valid;

	}
}

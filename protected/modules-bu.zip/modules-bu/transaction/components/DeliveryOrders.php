<?php

class DeliveryOrders extends CComponent
{
	public $header;
	public $details;
	
	// /public $detailApprovals;
	
	// public $picPhoneDetails;
	// public $picMobileDetails;

	public function __construct($header, array $details)
	{
		$this->header = $header;
		$this->details = $details;
		
		//$this->detailApprovals = $detailApprovals;
	}

	
	public function addDetail($requestType,$requestId)
	{
		
		if($requestType	== 1){
			$sales = TransactionSalesOrderDetail::model()->findAllByAttributes(array('sales_order_id'=>$requestId));
			foreach ($sales as $key => $sale) {
				$detail = new TransactionDeliveryOrderDetail();
				$detail->product_id = $sale->product_id;
				$detail->quantity_request = $sale->quantity;
				
				//$detail->quantity_request_left =$left;
				$detail->quantity_request_left = $sale->sales_order_quantity_left;
				//added 20 july 10 pm
				$detail->sales_order_detail_id = $sale->id;
				$this->details[] = $detail;
			} //endforeach

		}//end if
		elseif($requestType == 2){
			$sents = TransactionSentRequestDetail::model()->findAllByAttributes(array('sent_request_id'=>$requestId));
			foreach ($sents as $key => $sent) {
				$detail = new TransactionDeliveryOrderDetail();
				$detail->product_id = $sent->product_id;
				$detail->quantity_request = $sent->quantity;
				$detail->quantity_request_left = $sent->sent_request_quantity_left;
				//added 20 july 10 pm
				$detail->sent_request_detail_id = $sent->id;
				$this->details[] = $detail;
			}
		}
		elseif($requestType == 3){
			$consignments = ConsignmentOutDetail::model()->findAllByAttributes(array('consignment_out_id'=>$requestId));
			foreach ($consignments as $key => $consignment) {
				$detail = new TransactionDeliveryOrderDetail();
				$detail->product_id = $consignment->product_id;
				$detail->quantity_request = $consignment->quantity;
				$detail->quantity_request_left = $consignment->qty_request_left;
				//added 20 july 10 pm
				$detail->consignment_out_detail_id = $consignment->id;
				$this->details[] = $detail;
			}
		}
		elseif($requestType == 4){
			$transfers = TransactionTransferRequestDetail::model()->findAllByAttributes(array('transfer_request_id'=>$requestId));
			foreach ($transfers as $key => $transfer) {
				$detail = new TransactionDeliveryOrderDetail();
				$detail->product_id = $transfer->product_id;
				$detail->quantity_request = $transfer->quantity;
				$detail->quantity_request_left = $transfer->quantity_delivery_left;
				$detail->transfer_request_detail_id = $transfer->id;
				$this->details[] = $detail;	
			}
		}
		
	}
	

	public function removeDetailAt()
	{	
		//array_splice($this->details, $index, 1);
		//var_dump(CJSON::encode($this->details));
		$this->details = array();
	}
	public function removeDetail($index)
	{	
		array_splice($this->details, $index, 1);
		//var_dump(CJSON::encode($this->details));
		//$this->details = array();
	}

	

	public function save($dbConnection)
	{
		$dbTransaction = $dbConnection->beginTransaction();
		try
		{
			$valid = $this->validate() && $this->flush();
			if ($valid){
				$dbTransaction->commit();
				//print_r('1');
			} else {
				$dbTransaction->rollback();
				//print_r('2');
			}

		}
		catch (Exception $e)
		{
			$dbTransaction->rollback();
			$valid = false;
			//print_r($e);
		}

		return $valid;
		//print_r('success');
	}

	public function validate()
	{
		$valid = $this->header->validate();

		
		if (count($this->details) > 0)
		{
			foreach ($this->details as $detail)
			{

				$fields = array('unit_price');
				$valid = $detail->validate($fields) && $valid;
			}
		}
		else {
			$valid = true;
		}
		

		

		//print_r($valid);
		return $valid;
	}

	public function validateDetailsCount()
	{
		$valid = true;
		if (count($this->details	) === 0)
		{
			$valid = false;
			$this->header->addError('error', 'Form tidak ada data untuk insert database. Minimal satu data detail untuk melakukan penyimpanan.');
		}

		return $valid;
	}


	public function flush()
	{
		$isNewRecord = $this->header->isNewRecord;
		$valid = $this->header->save();
		//echo "valid";

		$requestDetails  = TransactionDeliveryOrderDetail::model()->findAllByAttributes(array('delivery_order_id'=>$this->header->id));
		$detail_id = array();
		foreach($requestDetails as $requestDetail)
		{
			$detail_id[]=$requestDetail->id;
		}
		$new_detail= array();

		//save request detail
		foreach ($this->details as $detail)
		{
			$detail->delivery_order_id = $this->header->id;
			//echo $this->header->request_type;
			$left_quantity =0;
			if($this->header->request_type == 'Sales Order'){
				//echo $this->header->request_type;
				$criteria = new CDbCriteria;
				$criteria->together = 'true';
				$criteria->with = array('deliveryOrder');
				$criteria->condition="deliveryOrder.sales_order_id =".$this->header->sales_order_id ." AND delivery_order_id != ".$this->header->id;
				//$criteria->condition="sales_order_detail_id =".$detail->sales_order_detail_id ." AND delivery_order_id != ".$this->header->id;
				$receiveItemDetails = TransactionDeliveryOrderDetail::model()->findAll($criteria);
				
				
				$quantity = 0;
				
				//print_r($receiveItemDetails);
				foreach($receiveItemDetails as $receiveItemDetail)
				{
					$quantity += $receiveItemDetail->quantity_delivery;
					
				}

				$purchaseOrderDetail = TransactionSalesOrderDetail::model()->findByAttributes(array('id'=>$detail->sales_order_detail_id,'sales_order_id'=>$this->header->sales_order_id));
				$purchaseOrderDetail->sales_order_quantity_left = $detail->quantity_request - ($detail->quantity_delivery + $quantity);
				$purchaseOrderDetail->delivery_quantity = $quantity + $detail->quantity_delivery;
				$left_quantity = $purchaseOrderDetail->sales_order_quantity_left;
				$purchaseOrderDetail->save(false);

				$salesOrder = TransactionSalesOrder::model()->findByPk($this->header->sales_order_id);
				$branch = Branch::model()->findByPk($this->header->sender_branch_id);
				// foreach($salesOrder->transactionSalesOrderDetails as $key =>$soDetail )
				// {
					$jumlah = $detail->quantity_delivery * $detail->salesOrderDetail->unit_price;
					//echo $this->header->recipient_branch_id;

					//save coa product master
					$coaMasterInventory = Coa::model()->findByPk($detail->salesOrderDetail->product->productMasterCategory->coaInventoryInTransit->id);
					$getCoaMasterInventory = $branch->coa_prefix.'.'.$coaMasterInventory->code;
					$coaMasterInventoryWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaMasterInventory));
					//echo $coaInventoryWithCode;
					$jurnalUmumMasterInventory = new JurnalUmum;
					$jurnalUmumMasterInventory->kode_transaksi = $this->header->delivery_order_no;
					$jurnalUmumMasterInventory->tanggal_transaksi = $this->header->delivery_date;
					// $jurnalUmumPersediaan->coa_id = $poDetail->product->productSubMasterCategory->coaInventoryInTransit->id == "" ?4:5; 
					$jurnalUmumMasterInventory->coa_id = $coaMasterInventoryWithCode->id;
					$jurnalUmumMasterInventory->branch_id = $this->header->sender_branch_id;
					$jurnalUmumMasterInventory->total = $jumlah;
					$jurnalUmumMasterInventory->debet_kredit = 'D';
					$jurnalUmumMasterInventory->tanggal_posting = date('Y-m-d');
					//echo $jurnalUmumInventory->tanggal_posting;
					$jurnalUmumMasterInventory->save();

					//save coa product sub master
					$coaInventory = Coa::model()->findByPk($detail->salesOrderDetail->product->productSubMasterCategory->coaInventoryInTransit->id);
					$getCoaInventory = $branch->coa_prefix.'.'.$coaInventory->code;
					$coaInventoryWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaInventory));
					//echo $coaInventoryWithCode;
					$jurnalUmumInventory = new JurnalUmum;
					$jurnalUmumInventory->kode_transaksi = $this->header->delivery_order_no;
					$jurnalUmumInventory->tanggal_transaksi = $this->header->delivery_date;
					// $jurnalUmumPersediaan->coa_id = $poDetail->product->productSubMasterCategory->coaInventoryInTransit->id == "" ?4:5; 
					$jurnalUmumInventory->coa_id = $coaInventoryWithCode->id;
					$jurnalUmumInventory->branch_id = $this->header->sender_branch_id;
					$jurnalUmumInventory->total = $jumlah;
					$jurnalUmumInventory->debet_kredit = 'D';
					$jurnalUmumInventory->tanggal_posting = date('Y-m-d');
					//echo $jurnalUmumInventory->tanggal_posting;
					$jurnalUmumInventory->save();
						
					//____________________________________________________________________________________
					//save coa persediaan master
					$coaMasterPersediaan = Coa::model()->findByPk($detail->salesOrderDetail->product->productMasterCategory->coaPersediaanBarangDagang->id);
					$getMasterCoaPersediaan = $branch->coa_prefix.'.'.$coaMasterPersediaan->code;
					$coaMasterPersediaanWithCode = Coa::model()->findByAttributes(array('code'=>$getMasterCoaPersediaan));
					
					$jurnalUmumMasterPersediaan = new JurnalUmum;
					$jurnalUmumMasterPersediaan->kode_transaksi = $this->header->delivery_order_no;
					$jurnalUmumMasterPersediaan->tanggal_transaksi = $this->header->delivery_date;
					// $jurnalUmumOutstanding->coa_id = $purchaseOrder->supplier->coaOutstandingOrder->id==""?6:7;
					$jurnalUmumMasterPersediaan->coa_id = $coaMasterPersediaanWithCode->id;
					$jurnalUmumMasterPersediaan->branch_id = $this->header->sender_branch_id;
					$jurnalUmumMasterPersediaan->total = $jumlah;
					$jurnalUmumMasterPersediaan->debet_kredit = 'K';
					$jurnalUmumMasterPersediaan->tanggal_posting = date('Y-m-d');
					$jurnalUmumMasterPersediaan->save();
	

					//save coa persediaan sub master
					$coaPersediaan = Coa::model()->findByPk($detail->salesOrderDetail->product->productSubMasterCategory->coaPersediaanBarangDagang->id);
					$getCoaPersediaan = $branch->coa_prefix.'.'.$coaPersediaan->code;
					$coaPersediaanWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaPersediaan));
					
					$jurnalUmumPersediaan = new JurnalUmum;
					$jurnalUmumPersediaan->kode_transaksi = $this->header->delivery_order_no;
					$jurnalUmumPersediaan->tanggal_transaksi = $this->header->delivery_date;
					// $jurnalUmumOutstanding->coa_id = $purchaseOrder->supplier->coaOutstandingOrder->id==""?6:7;
					$jurnalUmumPersediaan->coa_id = $coaPersediaanWithCode->id;
					$jurnalUmumPersediaan->branch_id = $this->header->sender_branch_id;
					$jurnalUmumPersediaan->total = $jumlah;
					$jurnalUmumPersediaan->debet_kredit = 'K';
					$jurnalUmumPersediaan->tanggal_posting = date('Y-m-d');
					$jurnalUmumPersediaan->save();

				//}

				/*$salesOrder = TransactionSalesOrder::model()->findByPk($this->header->sales_order_id);
				foreach($salesOrder->transactionSalesOrderDetails as $key =>$soDetail )
					{
						//$coa = $soDetail->product->productSubMasterCategory->coa->id;
						$cPenjualan = CoaDetail::model()->findByAttributes(array('coa_id'=>$soDetail->product->productSubMasterCategory->coaPenjualanBarangDagang->id,'branch_id'=>$soDetail->salesOrder->requester_branch_id));
						if(count($cPenjualan)!= 0){
							if($soDetail->product->productSubMasterCategory->coaPenjualanBarangDagang->normal_balance == "D"){
								$cPenjualan->debit += $soDetail->subtotal;
							}
							else{
								$cPenjualan->credit += $soDetail->subtotal;
							}
							//$cPersediaan->save(false);
						}
						else{
							$cPenjualan = new CoaDetail;
							$cPenjualan->coa_id = $soDetail->product->productSubMasterCategory->coaPenjualanBarangDagang->id;
							$cPenjualan->branch_id = $salesOrder->requester_branch_id;
							if($soDetail->product->productSubMasterCategory->coaPenjualanBarangDagang->normal_balance == "D"){
								$cPenjualan->debit += $soDetail->subtotal;
							}
							else{
								$cPenjualan->credit += $soDetail->subtotal;
							}
							
						}
						$cPenjualan->save(false);

						$cDiskon = CoaDetail::model()->findByAttributes(array('coa_id'=>$soDetail->product->productSubMasterCategory->coaDiskonPenjualan->id,'branch_id'=>$salesOrder->requester_branch_id));
						if(count($cDiskon)!=0){
							if($soDetail->product->productSubMasterCategory->coaDiskonPenjualan->normal_balance == "D"){
								$cDiskon->debit += $soDetail->discount;
							}
							else{
								$cDiskon->credit += $soDetail->discount;
							}

						}
						else{
							$cDiskon = new CoaDetail;
							$cDiskon->coa_id = $soDetail->product->productSubMasterCategory->coaDiskonPenjualan->id;
							$cDiskon->branch_id = $salesOrder->requester_branch_id;
							if($soDetail->product->productSubMasterCategory->coaDiskonPenjualan->normal_balance == "D"){
								$cDiskon->debit += $soDetail->discount;
							}
							else{
								$cDiskon->credit += $soDetail->discount;
							}

						}
						$cDiskon->save(false);
						if($salesOrder->ppn == 1){
							$coaPpn = Coa::model()->findByPk(287);
							$cPpnKeluaran = CoaDetail::model()->findByAttributes(array('coa_id'=>$coaPpn->id,'branch_id'=>$salesOrder->requester_branch_id));
							if(count($cPpnKeluaran)!=0){
								if($coaPpn->normal_balance == "D"){
									$cPpnKeluaran->debit += ($soDetail->subtotal - $soDetail->discount)*0.10;
								}
								else{
									$cPpnKeluaran->credit += ($soDetail->subtotal - $soDetail->discount)*0.10;
								}
							}
							else{
								$cPpnKeluaran = new CoaDetail;
								$cPpnKeluaran->coa_id = 287;
								$cPpnKeluaran->branch_id = $salesOrder->requester_branch_id;
								if($coaPpn->normal_balance == "D"){
									$cPpnKeluaran->debit += ($soDetail->subtotal - $soDetail->discount)*0.10;
								}
								else{
									$cPpnKeluaran->credit += ($soDetail->subtotal - $soDetail->discount)*0.10;
								}
							}
							$cPpnKeluaran->save(false);
							$jurnalUmumPpn = new JurnalUmum;
							$jurnalUmumPpn->kode_transaksi = $salesOrder->sale_order_no;
							$jurnalUmumPpn->tanggal_transaksi = $salesOrder->sale_order_date;
							$jurnalUmumPpn->coa_id = 287;
							$jurnalUmumPpn->total = ($soDetail->subtotal - $soDetail->discount)*0.10;
							$jurnalUmumPpn->debet_kredit = 'K';
							$jurnalUmumPpn->tanggal_posting = date('Y-m-d');
							$jurnalUmumPpn->save();
						}
						
						$jurnalUmumPersediaan = new JurnalUmum;
						$jurnalUmumPersediaan->kode_transaksi = $salesOrder->sale_order_no;
						$jurnalUmumPersediaan->tanggal_transaksi = $salesOrder->sale_order_date;
						$jurnalUmumPersediaan->coa_id = $soDetail->product->productSubMasterCategory->coaPenjualanBarangDagang->id;
						$jurnalUmumPersediaan->total = $soDetail->subtotal;
						$jurnalUmumPersediaan->debet_kredit = 'K';
						$jurnalUmumPersediaan->tanggal_posting = date('Y-m-d');
						$jurnalUmumPersediaan->save();

						$jurnalUmumDiskon = new JurnalUmum;
						$jurnalUmumDiskon->kode_transaksi = $salesOrder->sale_order_no;
						$jurnalUmumDiskon->tanggal_transaksi = $salesOrder->sale_order_date;
						$jurnalUmumDiskon->coa_id = $soDetail->product->productSubMasterCategory->coaDiskonPenjualan->id;
						$jurnalUmumDiskon->total = $soDetail->discount;
						$jurnalUmumDiskon->debet_kredit = 'K';
						$jurnalUmumDiskon->tanggal_posting = date('Y-m-d');
						$jurnalUmumDiskon->save();

						$coaHpp = CoaDetail::model()->findByAttributes(array('coa_id'=>$soDetail->product->productSubMasterCategory->coaHpp->id,'branch_id'=>$salesOrder->requester_branch_id));
						if(count($coaHpp)!=0){
							$coaHpp->debit += $salesOrder->total_price;
						}
						else{
							$coaHpp = new CoaDetail;
							$coaHpp->coa_id = $soDetail->product->productSubMasterCategory->coaHpp->id;
							$coaHpp->branch_id = $salesOrder->requester_branch_id;
							$coaHpp->debit += $salesOrder->total_price;
						}
						$coaHpp->save(false);
						$jurnalUmum = new JurnalUmum;
						$jurnalUmum->kode_transaksi = $salesOrder->sale_order_no;
						$jurnalUmum->tanggal_transaksi = $salesOrder->sale_order_date;
						$jurnalUmum->coa_id = $soDetail->product->productSubMasterCategory->coaHpp->id;
						$jurnalUmum->total = $salesOrder->total_price;
						$jurnalUmum->debet_kredit = 'D';
						$jurnalUmum->tanggal_posting = date('Y-m-d');
						$jurnalUmum->save();


					}
					if($salesOrder->payment_type == 'Cash'){
						$coaCash = CoaDetail::model()->findByAttributes(array('coa_id'=>3,'branch_id'=>$salesOrder->requester_branch_id));
						if(count($coaCash)!=0){
							$coaCash->debit += $salesOrder->total_price;
						}
						else{
							$coaCash = new CoaDetail;
							$coaCash->coa_id = 3;
							$coaCash->branch_id = $salesOrder->requester_branch_id;
							$coaCash->debit += $salesOrder->total_price;
						}
						$coaCash->save(false);
						$jurnalUmum = new JurnalUmum;
						$jurnalUmum->kode_transaksi = $salesOrder->sale_order_no;
						$jurnalUmum->tanggal_transaksi = $salesOrder->sale_order_date;
						$jurnalUmum->coa_id = 3;
						$jurnalUmum->total = $salesOrder->total_price;
						$jurnalUmum->debet_kredit = 'D';
						$jurnalUmum->tanggal_posting = date('Y-m-d');
						$jurnalUmum->save();
					}
					elseif($salesOrder->payment_type == 'Credit'){
						if($salesOrder->customer->coa != "")
						{	
							$coaCredit = CoaDetail::model()->findByAttributes(array('coa_id'=>$salesOrder->customer->coa->id,'branch_id'=>$salesOrder->requester_branch_id));
							if(count($coaCredit)!=0){
								$coaCredit->debit += $salesOrder->total_price;
							}
							else{
								$coaCredit = new CoaDetail;
								$coaCredit->coa_id = $salesOrder->customer->coa->id;
								$coaCredit->branch_id = $salesOrder->requester_branch_id;
								$coaCredit->debit += $salesOrder->total_price;
							}
							$coaCredit->save(false);
							$jurnalUmum = new JurnalUmum;
							$jurnalUmum->kode_transaksi = $salesOrder->sale_order_no;
							$jurnalUmum->tanggal_transaksi = $salesOrder->sale_order_date;
							$jurnalUmum->coa_id = $salesOrder->customer->coa->id;
							$jurnalUmum->total = $salesOrder->total_price;
							$jurnalUmum->debet_kredit = 'D';
							$jurnalUmum->tanggal_posting = date('Y-m-d');
							$jurnalUmum->save();
						}
					}*/

			}
				else if($this->header->request_type == 'Sent Request'){
				$criteria = new CDbCriteria;
				$criteria->together = 'true';
				$criteria->with = array('deliveryOrder');
				$criteria->condition="deliveryOrder.sent_request_id =".$this->header->sent_request_id ." AND delivery_order_id != ".$this->header->id;
				//$criteria->condition="sent_request_detail_id =".$detail->sent_request_detail_id ." AND delivery_order_id != ".$this->header->id;
				$deliveryItemDetails = TransactionDeliveryOrderDetail::model()->findAll($criteria);
				
				$quantity = 0;
				//print_r($receiveItemDetails);
				foreach($deliveryItemDetails as $deliveryItemDetail)
				{
					$quantity += $deliveryItemDetail->quantity_delivery;
				
				}
				$sentRequestDetail = TransactionSentRequestDetail::model()->findByAttributes(array('id'=>$detail->sent_request_detail_id,'sent_request_id'=>$this->header->sent_request_id));
				$sentRequestDetail->sent_request_quantity_left = $detail->quantity_request -($detail->quantity_delivery + $quantity);
				$sentRequestDetail->delivery_quantity = $quantity + $detail->quantity_delivery;
				$left_quantity = $sentRequestDetail->sent_request_quantity_left;
				$sentRequestDetail->save(false);
			}
			else if($this->header->request_type == 'Consignment Out'){

				$criteria = new CDbCriteria;
				$criteria->together = 'true';
				$criteria->with = array('deliveryOrder');
				$criteria->condition="deliveryOrder.consignment_out_id =".$this->header->consignment_out_id ." AND delivery_order_id != ".$this->header->id;
				$deliveryItemDetails = TransactionDeliveryOrderDetail::model()->findAll($criteria);
				//$criteria = new CDbCriteria;
				
				
				$quantity = 0;
				//print_r($receiveItemDetails);
				foreach($deliveryItemDetails as $deliveryItemDetail)
				{
					$quantity += $deliveryItemDetail->quantity_delivery;
					
				}
				$consignmentDetail = ConsignmentOutDetail::model()->findByAttributes(array('id'=>$detail->consignment_out_detail_id,'consignment_out_id'=>$this->header->consignment_out_id));
				$consignmentDetail->qty_request_left = $detail->quantity_request -($detail->quantity_delivery + $quantity);
				$consignmentDetail->qty_sent = $quantity + $detail->quantity_delivery;
				$left_quantity = $consignmentDetail->qty_request_left;
				$consignmentDetail->save(false);
				$consignment = ConsignmentOutHeader::model()->findByPk($this->header->consignment_out_id);
				$branch = Branch::model()->findByPk($this->header->sender_branch_id);
				//coa piutang ganti dengan consignment Inventory
				$salePrice = $detail->consignmentOutDetail->sale_price * $detail->quantity_delivery;
				$hppPrice = $detail->product->hpp * $detail->quantity_delivery;

					//save consignment product master category
					$coaMasterConsignment = Coa::model()->findByPk($detail->product->productMasterCategory->coaConsignmentInventory->id);
					$getCoaMasterConsignment = $branch->coa_prefix.'.'.$coaMasterConsignment->code;
					$coaMasterConsignmentWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaMasterConsignment));
					$jurnalMasterUmumConsignment = new JurnalUmum;
					$jurnalMasterUmumConsignment->kode_transaksi = $this->header->delivery_order_no;
					$jurnalMasterUmumConsignment->tanggal_transaksi = $this->header->delivery_date;
					$jurnalMasterUmumConsignment->coa_id = $coaMasterConsignmentWithCode->id;
					$jurnalMasterUmumConsignment->branch_id = $this->header->sender_branch_id;
					$jurnalMasterUmumConsignment->total = $salePrice;
					$jurnalMasterUmumConsignment->debet_kredit = 'D';
					$jurnalMasterUmumConsignment->tanggal_posting = date('Y-m-d');
					$jurnalMasterUmumConsignment->save();


					//save consignment product sub master category
					$coaConsignment = Coa::model()->findByPk($detail->product->productSubMasterCategory->coaConsignmentInventory->id);
					$getCoaConsignment = $branch->coa_prefix.'.'.$coaConsignment->code;
					$coaConsignmentWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaConsignment));
					$jurnalUmumConsignment = new JurnalUmum;
					$jurnalUmumConsignment->kode_transaksi = $this->header->delivery_order_no;
					$jurnalUmumConsignment->tanggal_transaksi = $this->header->delivery_date;
					$jurnalUmumConsignment->coa_id = $coaConsignmentWithCode->id;
					$jurnalUmumConsignment->branch_id = $this->header->sender_branch_id;
					$jurnalUmumConsignment->total = $salePrice;
					$jurnalUmumConsignment->debet_kredit = 'D';
					$jurnalUmumConsignment->tanggal_posting = date('Y-m-d');
					$jurnalUmumConsignment->save();

					//save coa hpp product master category
					$coaMasterHpp = Coa::model()->findByPk($detail->product->productMasterCategory->coaHpp->id);
					$getCoMasteraHpp = $branch->coa_prefix.'.'.$coaMasterHpp->code;
					$coaMasterHppWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaMasterHpp));
					$jurnalUmumMasterHpp = new JurnalUmum;
					$jurnalUmumMasterHpp->kode_transaksi = $this->header->delivery_order_no;
					$jurnalUmumMasterHpp->tanggal_transaksi = $this->header->delivery_date;
					$jurnalUmumMasterHpp->coa_id = $coaMasterHppWithCode->id;
					$jurnalUmumMasterHpp->branch_id = $this->header->sender_branch_id;
					$jurnalUmumMasterHpp->total = $hppPrice;
					$jurnalUmumMasterHpp->debet_kredit = 'D';
					$jurnalUmumMasterHpp->tanggal_posting = date('Y-m-d');
					$jurnalUmumMasterHpp->save();

					//save coa hpp product sub master category
					$coaHpp = Coa::model()->findByPk($detail->product->productSubMasterCategory->coaHpp->id);
					$getCoaHpp = $branch->coa_prefix.'.'.$coaHpp->code;
					$coaHppWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaHpp));
					$jurnalUmumHpp = new JurnalUmum;
					$jurnalUmumHpp->kode_transaksi = $this->header->delivery_order_no;
					$jurnalUmumHpp->tanggal_transaksi = $this->header->delivery_date;
					$jurnalUmumHpp->coa_id = $coaHppWithCode->id;
					$jurnalUmumHpp->branch_id = $this->header->sender_branch_id;
					$jurnalUmumHpp->total = $hppPrice;
					$jurnalUmumHpp->debet_kredit = 'D';
					$jurnalUmumHpp->tanggal_posting = date('Y-m-d');
					$jurnalUmumHpp->save();


					//K 
					//save coa penjualan barang product master
					$coaMasterPenjualan = Coa::model()->findByPk($detail->product->productMasterCategory->coaPenjualanBarangDagang->id);
					$getCoaMasterPenjualan = $branch->coa_prefix.'.'.$coaMasterPenjualan->code;
					$coaMasterPenjualanWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaMasterPenjualan));
					$jurnalUmumMasterPenjualan = new JurnalUmum;
					$jurnalUmumMasterPenjualan->kode_transaksi = $this->header->delivery_order_no;
					$jurnalUmumMasterPenjualan->tanggal_transaksi = $this->header->delivery_date;
					$jurnalUmumMasterPenjualan->coa_id = $coaMasterPenjualanWithCode->id;
					$jurnalUmumMasterPenjualan->branch_id = $this->header->sender_branch_id;
					$jurnalUmumMasterPenjualan->total = $salePrice;
					$jurnalUmumMasterPenjualan->debet_kredit = 'K';
					$jurnalUmumMasterPenjualan->tanggal_posting = date('Y-m-d');
					$jurnalUmumMasterPenjualan->save();

					//save coa penjualan barang product sub master
					$coaPenjualan = Coa::model()->findByPk($detail->product->productSubMasterCategory->coaPenjualanBarangDagang->id);
					$getCoaPenjualan = $branch->coa_prefix.'.'.$coaPenjualan->code;
					$coaPenjualanWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaPenjualan));
					$jurnalUmumPenjualan = new JurnalUmum;
					$jurnalUmumPenjualan->kode_transaksi = $this->header->delivery_order_no;
					$jurnalUmumPenjualan->tanggal_transaksi = $this->header->delivery_date;
					$jurnalUmumPenjualan->coa_id = $coaPenjualanWithCode->id;
					$jurnalUmumPenjualan->branch_id = $this->header->sender_branch_id;
					$jurnalUmumPenjualan->total = $salePrice;
					$jurnalUmumPenjualan->debet_kredit = 'K';
					$jurnalUmumPenjualan->tanggal_posting = date('Y-m-d');
					$jurnalUmumPenjualan->save();

					//save coa persediaan product master
					$coaMasterPersediaan = Coa::model()->findByPk($detail->product->productMasterCategory->coaPersediaanBarangDagang->id);
					$getCoaMasterPersediaan = $branch->coa_prefix.'.'.$coaMasterPersediaan->code;
					$coaMasterPersediaanWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaMasterPersediaan));
					$jurnalUmumMasterPersediaan = new JurnalUmum;
					$jurnalUmumMasterPersediaan->kode_transaksi = $this->header->delivery_order_no;
					$jurnalUmumMasterPersediaan->tanggal_transaksi = $this->header->delivery_date;
					$jurnalUmumMasterPersediaan->coa_id = $coaMasterPersediaanWithCode->id;
					$jurnalUmumMasterPersediaan->branch_id = $this->header->sender_branch_id;
					$jurnalUmumMasterPersediaan->total = $hppPrice;
					$jurnalUmumMasterPersediaan->debet_kredit = 'K';
					$jurnalUmumMasterPersediaan->tanggal_posting = date('Y-m-d');
					$jurnalUmumMasterPersediaan->save();

					//save coa persedian product sub master
					$coaPersediaan = Coa::model()->findByPk($detail->product->productSubMasterCategory->coaPersediaanBarangDagang->id);
					$getCoaPersediaan = $branch->coa_prefix.'.'.$coaPersediaan->code;
					$coaPersediaanWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaPersediaan));
					$jurnalUmumPersediaan = new JurnalUmum;
					$jurnalUmumPersediaan->kode_transaksi = $this->header->delivery_order_no;
					$jurnalUmumPersediaan->tanggal_transaksi = $this->header->delivery_date;
					$jurnalUmumPersediaan->coa_id = $coaPersediaanWithCode->id;
					$jurnalUmumPersediaan->branch_id = $this->header->sender_branch_id;
					$jurnalUmumPersediaan->total = $hppPrice;
					$jurnalUmumPersediaan->debet_kredit = 'K';
					$jurnalUmumPersediaan->tanggal_posting = date('Y-m-d');
					$jurnalUmumPersediaan->save();

						
			}
			else if($this->header->request_type == 'Transfer Request'){
				$criteria = new CDbCriteria;
				$criteria->together = 'true';
				$criteria->with = array('deliveryOrder');
				$criteria->condition="deliveryOrder.transfer_request_id =".$this->header->transfer_request_id ." AND delivery_order_id != ".$this->header->id;
				$deliveryItemDetails = TransactionDeliveryOrderDetail::model()->findAll($criteria);
				
				$quantity = 0;
				//print_r($receiveItemDetails);
				foreach($deliveryItemDetails as $deliveryItemDetail)
				{
					$quantity += $deliveryItemDetail->quantity_delivery;
				
				}
				$transferRequestDetail = TransactionTransferRequestDetail::model()->findByAttributes(array('id'=>$detail->transfer_request_detail_id,'transfer_request_id'=>$this->header->transfer_request_id));
				$transferRequestDetail->quantity_delivery_left = $detail->quantity_request -($detail->quantity_delivery + $quantity);
				$transferRequestDetail->quantity_delivery =  $quantity + $detail->quantity_delivery;
				$left_quantity = $transferRequestDetail->quantity_delivery_left;
				$transferRequestDetail->save(false);
				$detail->quantity_receive_left = $detail->quantity_delivery;

				$transfer = TransactionTransferRequest::model()->findByPk($this->header->transfer_request_id);
				$branch = Branch::model()->findByPk($this->header->sender_branch_id);
				$hppPrice = $detail->product->hpp * $detail->quantity_delivery;

				$interbranch = Branch::model()->findByPk($this->header->destination_branch);
				$coaInterbranch = Coa::model()->findByPk($this->header->senderBranch->coa_interbranch_inventory);
				$getCoaInterbranch = $interbranch->coa_prefix.'.'.$coaInterbranch->code;
				$coaInterbranchWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaInterbranch));
				$jurnalUmumInterbranch = new JurnalUmum;
				$jurnalUmumInterbranch->kode_transaksi = $this->header->delivery_order_no;
				$jurnalUmumInterbranch->tanggal_transaksi = $this->header->delivery_date;
				$jurnalUmumInterbranch->coa_id = $coaInterbranchWithCode->id;
				$jurnalUmumInterbranch->branch_id = $this->header->sender_branch_id;
				$jurnalUmumInterbranch->total = $hppPrice;
				$jurnalUmumInterbranch->debet_kredit = 'D';
				$jurnalUmumInterbranch->tanggal_posting = date('Y-m-d');
				$jurnalUmumInterbranch->save();

				//save coa persediaan product master
				$coaMasterPersediaan = Coa::model()->findByPk($detail->product->productMasterCategory->coaPersediaanBarangDagang->id);
				$getCoaMasterPersediaan = $branch->coa_prefix.'.'.$coaMasterPersediaan->code;
				$coaMasterPersediaanWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaMasterPersediaan));
				$jurnalUmumMasterPersediaan = new JurnalUmum;
				$jurnalUmumMasterPersediaan->kode_transaksi = $this->header->delivery_order_no;
				$jurnalUmumMasterPersediaan->tanggal_transaksi = $this->header->delivery_date;
				$jurnalUmumMasterPersediaan->coa_id = $coaMasterPersediaanWithCode->id;
				$jurnalUmumMasterPersediaan->branch_id = $this->header->sender_branch_id;
				$jurnalUmumMasterPersediaan->total = $hppPrice;
				$jurnalUmumMasterPersediaan->debet_kredit = 'K';
				$jurnalUmumMasterPersediaan->tanggal_posting = date('Y-m-d');
				$jurnalUmumMasterPersediaan->save();

				//save coa persedian product sub master
				$coaPersediaan = Coa::model()->findByPk($detail->product->productSubMasterCategory->coaPersediaanBarangDagang->id);
				$getCoaPersediaan = $branch->coa_prefix.'.'.$coaPersediaan->code;
				$coaPersediaanWithCode = Coa::model()->findByAttributes(array('code'=>$getCoaPersediaan));
				$jurnalUmumPersediaan = new JurnalUmum;
				$jurnalUmumPersediaan->kode_transaksi = $this->header->delivery_order_no;
				$jurnalUmumPersediaan->tanggal_transaksi = $this->header->delivery_date;
				$jurnalUmumPersediaan->coa_id = $coaPersediaanWithCode->id;
				$jurnalUmumPersediaan->branch_id = $this->header->sender_branch_id;
				$jurnalUmumPersediaan->total = $hppPrice;
				$jurnalUmumPersediaan->debet_kredit = 'K';
				$jurnalUmumPersediaan->tanggal_posting = date('Y-m-d');
				$jurnalUmumPersediaan->save();

			}
			$detail->quantity_request_left = $left_quantity;
			$valid = $detail->save() && $valid;
			$new_detail[] = $detail->id;
			//echo 'test';
		}


		//delete pricelist
		$delete_array= array_diff($detail_id, $new_detail);
		if($delete_array != NULL)
		{
			$criteria = new CDbCriteria;
			$criteria->addInCondition('id',$delete_array);
			TransactionDeliveryOrderDetail::model()->deleteAll($criteria);
		}

		
		return $valid;

	
}
}
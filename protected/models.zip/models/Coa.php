<?php

/**
 * This is the model class for table "{{coa}}".
 *
 * The followings are the available columns in table '{{coa}}':
 * @property integer $id
 * @property string $name
 * @property string $code
 * @property integer $coa_category_id
 * @property integer $coa_sub_category_id
 * @property string $normal_balance
 * @property string $opening_balance
 * @property string $closing_balance
 * @property string $debit
 * @property string $credit
 *
 * The followings are the available model relations:
 * @property CashTransaction[] $cashTransactions
 * @property CashTransactionDetail[] $cashTransactionDetails
 * @property CoaCategory $coaCategory
 * @property CoaSubCategory $coaSubCategory
 * @property CoaDetail[] $coaDetails
 * @property CompanyBank[] $companyBanks
 * @property Customer[] $customers
 * @property ProductSubMasterCategory[] $productSubMasterCategories
 * @property ServiceCategory[] $serviceCategories
 * @property Supplier[] $suppliers
 * @property TransactionPurchaseOrder[] $transactionPurchaseOrders
 * @property TransactionSalesOrder[] $transactionSalesOrders
 */
class Coa extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public $bulan;
	public $coa_category_name;
	public $coa_sub_category_name;

	public function tableName()
	{
		return '{{coa}}';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('name, code, coa_category_id, coa_sub_category_id', 'required'),
			array('coa_category_id, coa_sub_category_id', 'numerical', 'integerOnly'=>true),
			array('name', 'length', 'max'=>50),
			array('normal_balance', 'length', 'max'=>10),
			array('code','length','max'=>15),
			array('status', 'length', 'max'=>20),
			array('cash_transaction', 'length', 'max'=>5),
			array('opening_balance, closing_balance, debit, credit', 'length', 'max'=>18),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, code, coa_category_id, coa_sub_category_id, coa_category_name, coa_sub_category_name, opening_balance, closing_balance, debit, credit, normal_balance', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'cashTransactions' => array(self::HAS_MANY, 'CashTransaction', 'coa_id'),
			'cashTransactionDetails' => array(self::HAS_MANY, 'CashTransactionDetail', 'coa_id'),
			'coaCategory' => array(self::BELONGS_TO, 'CoaCategory', 'coa_category_id'),
			'coaSubCategory' => array(self::BELONGS_TO, 'CoaSubCategory', 'coa_sub_category_id'),
			'coaDetails' => array(self::HAS_MANY, 'CoaDetail', 'coa_id'),
			'companyBanks' => array(self::HAS_MANY, 'CompanyBank', 'coa_id'),
			'customers' => array(self::HAS_MANY, 'Customer', 'coa_id'),
			'productSubMasterCategories' => array(self::HAS_MANY, 'ProductSubMasterCategory', 'coa_id'),
			'serviceCategories' => array(self::HAS_MANY, 'ServiceCategory', 'coa_id'),
			'suppliers' => array(self::HAS_MANY, 'Supplier', 'coa_id'),
			'transactionPurchaseOrders' => array(self::HAS_MANY, 'TransactionPurchaseOrder', 'coa_id'),
			'transactionSalesOrders' => array(self::HAS_MANY, 'TransactionSalesOrder', 'coa_id'),
			
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'code' => 'Code',
			'coa_category_id' => 'Coa Category',
			'coa_sub_category_id' => 'Coa Sub Category',
			'normal_balance' => 'Normal Balance',
			'opening_balance' => 'Opening Balance',
			'closing_balance' => 'Closing Balance',
			'debit' => 'Debit',
			'credit' => 'Credit',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that ctotalan return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('t.id',$this->id);
		$criteria->compare('t.name',$this->name,true);
		$criteria->compare('t.code',$this->code,true);
		$criteria->compare('coa_category_id',$this->coa_category_id);
		$criteria->compare('coa_sub_category_id',$this->coa_sub_category_id);
		$criteria->compare('normal_balance',$this->normal_balance,true);
		$criteria->compare('opening_balance',$this->opening_balance,true);
		$criteria->compare('closing_balance',$this->closing_balance,true);
		$criteria->compare('debit',$this->debit,true);
		$criteria->compare('credit',$this->credit,true);

		$criteria->together=true;
		$criteria->with = array('coaCategory','coaSubCategory');
		$criteria->compare('coaCategory.name',$this->coa_category_name,true);
		$criteria->compare('coaSubCategory.name',$this->coa_sub_category_name,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Coa the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}

<?php

/**
 * This is the model class for table "{{transaction_purchase_order_detail}}".
 *
 * The followings are the available columns in table '{{transaction_purchase_order_detail}}':
 * @property integer $id
 * @property integer $purchase_order_id
 * @property integer $product_id
 * @property integer $unit_id
 * @property string $retail_price
 * @property integer $quantity
 * @property string $unit_price
 * @property integer $amount
 * @property integer $discount_step
 * @property integer $discount1_type
 * @property string $discount1_nominal
 * @property integer $discount1_temp_quantity
 * @property string $discount1_temp_price
 * @property integer $discount2_type
 * @property string $discount2_nominal
 * @property integer $discount2_temp_quantity
 * @property string $discount2_temp_price
 * @property integer $discount3_type
 * @property string $discount3_nominal
 * @property integer $discount3_temp_quantity
 * @property string $discount3_temp_price
 * @property integer $discount4_type
 * @property string $discount4_nominal
 * @property integer $discount4_temp_quantity
 * @property string $discount4_temp_price
 * @property integer $discount5_type
 * @property string $discount5_nominal
 * @property integer $discount5_temp_quantity
 * @property string $discount5_temp_price
 * @property integer $total_quantity
 * @property string $subtotal
 * @property string $discount
 * @property string $total_price
 * @property integer $receive_quantity
 * @property integer $purchase_order_quantity_left
 *
 * The followings are the available model relations:
 * @property TransactionPurchaseOrder $purchaseOrder
 * @property Product $product
 * @property TransactionPurchaseOrderDetailRequest[] $transactionPurchaseOrderDetailRequests
 * @property TransactionReceiveItemDetail[] $transactionReceiveItemDetails
 */
class TransactionPurchaseOrderDetail extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public $request_order_id;
	public $request_order_detail_id;
	public $request_quantity;
	public $request_price;
	public $request_order_no;
	public $branch_id;
	public $branch_name;
	public $product_name;
	public $estimate_date_arrival;
	public $purchaseQuantity;
	public $hpp;
	public function tableName()
	{
		return '{{transaction_purchase_order_detail}}';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('purchase_order_id, retail_price, quantity, unit_price, total_quantity, subtotal, discount_step, total_price', 'required'),
			array('purchase_order_id, product_id, unit_id, quantity, amount, discount_step, discount1_type, discount1_temp_quantity, discount2_type, discount2_temp_quantity, discount3_type, discount3_temp_quantity, discount4_type, discount4_temp_quantity, discount5_type, discount5_temp_quantity, total_quantity, receive_quantity, purchase_order_quantity_left', 'numerical', 'integerOnly'=>true),
			array('retail_price, unit_price, discount1_temp_price, discount2_temp_price, discount3_temp_price, discount4_temp_price, discount5_temp_price, subtotal, discount, total_price', 'length', 'max'=>18),
			array('discount1_nominal, discount2_nominal, discount3_nominal, discount4_nominal, discount5_nominal', 'length', 'max'=>10),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, purchase_order_id, product_id, unit_id, retail_price, quantity, unit_price, amount, discount_step, discount1_type, discount1_nominal, discount1_temp_quantity, discount1_temp_price, discount2_type, discount2_nominal, discount2_temp_quantity, discount2_temp_price, discount3_type, discount3_nominal, discount3_temp_quantity, discount3_temp_price, discount4_type, discount4_nominal, discount4_temp_quantity, discount4_temp_price, discount5_type, discount5_nominal, discount5_temp_quantity, discount5_temp_price, total_quantity, subtotal, discount, total_price, receive_quantity, purchase_order_quantity_left', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'purchaseOrder' => array(self::BELONGS_TO, 'TransactionPurchaseOrder', 'purchase_order_id'),
			'product' => array(self::BELONGS_TO, 'Product', 'product_id'),
			'transactionPurchaseOrderDetailRequests' => array(self::HAS_MANY, 'TransactionPurchaseOrderDetailRequest', 'purchase_order_detail_id'),
			'transactionReceiveItemDetails' => array(self::HAS_MANY, 'TransactionReceiveItemDetail', 'purchase_order_detail_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'purchase_order_id' => 'Purchase Order',
			'product_id' => 'Product',
			'unit_id' => 'Unit',
			'retail_price' => 'Retail Price',
			'quantity' => 'Quantity',
			'unit_price' => 'Unit Price',
			'amount' => 'Amount',
			'discount_step' => 'Discount Step',
			'discount1_type' => 'Discount1 Type',
			'discount1_nominal' => 'Discount1 Nominal',
			'discount1_temp_quantity' => 'Discount1 Temp Quantity',
			'discount1_temp_price' => 'Discount1 Temp Price',
			'discount2_type' => 'Discount2 Type',
			'discount2_nominal' => 'Discount2 Nominal',
			'discount2_temp_quantity' => 'Discount2 Temp Quantity',
			'discount2_temp_price' => 'Discount2 Temp Price',
			'discount3_type' => 'Discount3 Type',
			'discount3_nominal' => 'Discount3 Nominal',
			'discount3_temp_quantity' => 'Discount3 Temp Quantity',
			'discount3_temp_price' => 'Discount3 Temp Price',
			'discount4_type' => 'Discount4 Type',
			'discount4_nominal' => 'Discount4 Nominal',
			'discount4_temp_quantity' => 'Discount4 Temp Quantity',
			'discount4_temp_price' => 'Discount4 Temp Price',
			'discount5_type' => 'Discount5 Type',
			'discount5_nominal' => 'Discount5 Nominal',
			'discount5_temp_quantity' => 'Discount5 Temp Quantity',
			'discount5_temp_price' => 'Discount5 Temp Price',
			'total_quantity' => 'Total Quantity',
			'subtotal' => 'Subtotal',
			'discount' => 'Discount',
			'total_price' => 'Total Price',
			'receive_quantity' => 'Receive Quantity',
			'purchase_order_quantity_left' => 'Purchase Order Quantity Left',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('purchase_order_id',$this->purchase_order_id);
		$criteria->compare('product_id',$this->product_id);
		$criteria->compare('unit_id',$this->unit_id);
		$criteria->compare('retail_price',$this->retail_price,true);
		$criteria->compare('quantity',$this->quantity);
		$criteria->compare('unit_price',$this->unit_price,true);
		$criteria->compare('amount',$this->amount);
		$criteria->compare('discount_step',$this->discount_step);
		$criteria->compare('discount1_type',$this->discount1_type);
		$criteria->compare('discount1_nominal',$this->discount1_nominal,true);
		$criteria->compare('discount1_temp_quantity',$this->discount1_temp_quantity);
		$criteria->compare('discount1_temp_price',$this->discount1_temp_price,true);
		$criteria->compare('discount2_type',$this->discount2_type);
		$criteria->compare('discount2_nominal',$this->discount2_nominal,true);
		$criteria->compare('discount2_temp_quantity',$this->discount2_temp_quantity);
		$criteria->compare('discount2_temp_price',$this->discount2_temp_price,true);
		$criteria->compare('discount3_type',$this->discount3_type);
		$criteria->compare('discount3_nominal',$this->discount3_nominal,true);
		$criteria->compare('discount3_temp_quantity',$this->discount3_temp_quantity);
		$criteria->compare('discount3_temp_price',$this->discount3_temp_price,true);
		$criteria->compare('discount4_type',$this->discount4_type);
		$criteria->compare('discount4_nominal',$this->discount4_nominal,true);
		$criteria->compare('discount4_temp_quantity',$this->discount4_temp_quantity);
		$criteria->compare('discount4_temp_price',$this->discount4_temp_price,true);
		$criteria->compare('discount5_type',$this->discount5_type);
		$criteria->compare('discount5_nominal',$this->discount5_nominal,true);
		$criteria->compare('discount5_temp_quantity',$this->discount5_temp_quantity);
		$criteria->compare('discount5_temp_price',$this->discount5_temp_price,true);
		$criteria->compare('total_quantity',$this->total_quantity);
		$criteria->compare('subtotal',$this->subtotal,true);
		$criteria->compare('discount',$this->discount,true);
		$criteria->compare('total_price',$this->total_price,true);
		$criteria->compare('receive_quantity',$this->receive_quantity);
		$criteria->compare('purchase_order_quantity_left',$this->purchase_order_quantity_left);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return TransactionPurchaseOrderDetail the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
	
}

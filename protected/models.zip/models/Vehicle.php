<?php

/**
 * This is the model class for table "{{vehicle}}".
 *
 * The followings are the available columns in table '{{vehicle}}':
 * @property integer $id
 * @property string $plate_number
 * @property string $machine_number
 * @property string $frame_number
 * @property integer $car_make_id
 * @property integer $car_model_id
 * @property integer $car_sub_model_id
 * @property integer $car_sub_model_detail_id
 * @property integer $color_id
 * @property string $year
 * @property integer $customer_id
 * @property integer $customer_pic_id
 * @property string $chasis_code
 * @property string $transmission
 * @property string $fuel_type
 * @property integer $power
 * @property string $drivetrain
 * @property string $notes
 *
 * The followings are the available model relations:
 * @property RegistrationTransaction[] $registrationTransactions
 * @property VehicleCarMake $carMake
 * @property VehicleCarModel $carModel
 * @property VehicleCarSubModel $carSubModel
 * @property VehicleCarSubModelDetail $carSubModelDetail
 * @property Colors $color
 * @property Customer $customer
 * @property CustomerPic $customerPic
 * @property VehicleInspection[] $vehicleInspections
 */
class Vehicle extends CActiveRecord
{
	public $customer_name;
	public $car_make;
	public $car_model;
	public $car_sub_model;
	public $color;
	public $car_make_code;
	public $car_model_code;
	public $car_color;
	
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return '{{vehicle}}';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('plate_number, machine_number, frame_number, car_make_id, car_model_id, car_sub_model_id, car_sub_model_detail_id, color_id, transmission, fuel_type, drivetrain', 'required'),
			array('car_make_id, car_model_id, car_sub_model_id, car_sub_model_detail_id, color_id, customer_id, customer_pic_id, power', 'numerical', 'integerOnly'=>true),
			array('plate_number, year, drivetrain', 'length', 'max'=>10),
			array('plate_number','unique','message'=>'Plate number already exists.'),
			array('machine_number, frame_number, chasis_code, transmission', 'length', 'max'=>30),
			array('fuel_type', 'length', 'max'=>20),
			array('notes', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, plate_number, machine_number, frame_number, car_make_id, car_model_id, car_sub_model_id, car_sub_model_detail_id, color_id, year, customer_id, customer_pic_id, chasis_code, transmission, fuel_type, power, drivetrain, notes, car_make,color,car_color,car_model,car_sub_model,color', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'registrationTransactions' => array(self::HAS_MANY, 'RegistrationTransaction', 'vehicle_id'),
			'carMake' => array(self::BELONGS_TO, 'VehicleCarMake', 'car_make_id'),
			'carModel' => array(self::BELONGS_TO, 'VehicleCarModel', 'car_model_id'),
			'carSubModel' => array(self::BELONGS_TO, 'VehicleCarSubModel', 'car_sub_model_id'),
			'carSubModelDetail' => array(self::BELONGS_TO, 'VehicleCarSubModelDetail', 'car_sub_model_detail_id'),
			'color' => array(self::BELONGS_TO, 'Colors', 'color_id'),
			'customer' => array(self::BELONGS_TO, 'Customer', 'customer_id'),
			'customerPic' => array(self::BELONGS_TO, 'CustomerPic', 'customer_pic_id'),
			'vehicleInspections' => array(self::HAS_MANY, 'VehicleInspection', 'vehicle_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'plate_number' => 'Plate Number',
			'machine_number' => 'Machine Number',
			'frame_number' => 'Frame Number',
			'car_make_id' => 'Car Make',
			'car_model_id' => 'Car Model',
			'car_sub_model_id' => 'Car Sub Model',
			'car_sub_model_detail_id' => 'Car Sub Model Detail',
			'color_id' => 'Color',
			'year' => 'Year',
			'customer_id' => 'Customer',
			'customer_pic_id' => 'Customer Pic',
			'chasis_code' => 'Chasis Code',
			'transmission' => 'Transmission',
			'fuel_type' => 'Fuel Type',
			'power' => 'Power',
			'drivetrain' => 'Drivetrain',
			'notes' => 'Notes',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('plate_number',$this->plate_number,true);
		$criteria->compare('machine_number',$this->machine_number,true);
		$criteria->compare('frame_number',$this->frame_number,true);
		$criteria->compare('car_make_id',$this->car_make_id);
		$criteria->compare('car_model_id',$this->car_model_id);
		$criteria->compare('car_sub_model_id',$this->car_sub_model_id);
		$criteria->compare('car_sub_model_detail_id',$this->car_sub_model_detail_id);
		$criteria->compare('color_id',$this->color_id);
		$criteria->compare('year',$this->year,true);
		$criteria->compare('customer_id',$this->customer_id);
		$criteria->compare('customer_pic_id',$this->customer_pic_id);
		$criteria->compare('chasis_code',$this->chasis_code,true);
		$criteria->compare('transmission',$this->transmission,true);
		$criteria->compare('fuel_type',$this->fuel_type,true);
		$criteria->compare('power',$this->power);
		$criteria->compare('drivetrain',$this->drivetrain,true);
		$criteria->compare('notes',$this->notes,true);

		$criteria->together = 'true';
		//$criteria->with = array('carMake','carModel','carSubModel','color');
		$criteria->with = array('carMake','carModel','carSubModel');
		$criteria->compare('carMake.name', $this->car_make, true);
		$criteria->compare('carModel.name', $this->car_model, true);
		$criteria->compare('carSubModel.name', $this->car_sub_model, true);
		//$criteria->compare('color.name', $this->color, true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			'sort' => array(
            'defaultOrder' => 'plate_number',
            'attributes' => array(
	                'car_make' => array(
	                    'asc' => 'carMake.name ASC',
	                    'desc' => 'carMake.name DESC',
	                ),
	                'car_model' => array(
	                    'asc' => 'carModel.name ASC',
	                    'desc' => 'carModel.name DESC',
	                ),
	                'car_sub_model' => array(
	                    'asc' => 'carSubModel.name ASC',
	                    'desc' => 'carSubModel.name DESC',
	                ),
	                // 'color' => array(
	                //     'asc' => 'color.name ASC',
	                //     'desc' => 'color.name DESC',
	                // ),
	                '*',
	            ),
	        ),
	        'pagination' => array(
	            'pageSize' => 10,
	        ),
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Vehicle the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
	
	/**
	 * Function to return campaign no to display in create booking grid (admin)
	 */
	function getColor($data, $row) {
		$color = '';
    	if ($data->color_id) {
			$colors = Colors::model()->findByPk($data->color_id);
				if($colors['name'])
					$color = $colors['name'];
				
		}
    		return $color;
	}
}

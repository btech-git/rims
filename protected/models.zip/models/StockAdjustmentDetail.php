<?php

/**
 * This is the model class for table "{{stock_adjustment_detail}}".
 *
 * The followings are the available columns in table '{{stock_adjustment_detail}}':
 * @property integer $id
 * @property integer $stock_adjustment_header_id
 * @property integer $product_id
 * @property integer $warehouse_id
 * @property integer $stock_in
 * @property integer $stock_out
 */
class StockAdjustmentDetail extends CActiveRecord
{
	// public $headerStatus;
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return '{{stock_adjustment_detail}}';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('stock_adjustment_header_id, product_id, warehouse_id, stock_in, stock_out', 'required'),
			array('stock_adjustment_header_id, product_id, warehouse_id, stock_in, stock_out', 'numerical', 'integerOnly'=>true),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, stock_adjustment_header_id, product_id, warehouse_id, stock_in, stock_out', 'safe', 'on'=>'search'),
			);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'stockAdjustmentHeader' => array(self::BELONGS_TO, 'StockAdjustmentHeader', 'stock_adjustment_header_id'),
			'warehouse' => array(self::BELONGS_TO, 'Warehouse', 'warehouse_id'),
			'product' => array(self::BELONGS_TO, 'Product', 'product_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'stock_adjustment_header_id' => 'Stock Adjustment Header',
			'product_id' => 'Product',
			'warehouse_id' => 'Warehouse',
			'stock_in' => 'Stock In',
			'stock_out' => 'Stock Out',
			);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('stock_adjustment_header_id',$this->stock_adjustment_header_id);
		$criteria->compare('product_id',$this->product_id);
		$criteria->compare('warehouse_id',$this->warehouse_id);
		$criteria->compare('stock_in',$this->stock_in);
		$criteria->compare('stock_out',$this->stock_out);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			));
	}


	protected function afterSave()
	{

		if(!$this->isNewRecord AND $this->stockAdjustmentHeader->status == 'Approved') {
			$inventoryDetail= new InventoryDetail();
			$inventoryDetail->inventory_id = $this->getInventoryId($this->product_id,$this->warehouse_id);
			$inventoryDetail->product_id = $this->product_id;
			$inventoryDetail->warehouse_id = $this->warehouse_id;
			$inventoryDetail->transaction_type = 'adjustment';
			$inventoryDetail->transaction_number = 'TR-AJS'.$this->stock_adjustment_header_id;//$this->stockAdjustmentHeader->stock_adjustment_header_id;
			$inventoryDetail->transaction_date = date("Y-m-d");
			$inventoryDetail->stock_in = $this->stock_in;
			$inventoryDetail->stock_out = $this->stock_out;
			$inventoryDetail->notes = 'Data From Stock Adjustment';
			$inventoryDetail->save();
		}

		return parent::afterSave();
	}


	public function getInventoryId ($productId, $warehouseId) {
		$InventoryID = Inventory::model()->findByAttributes(array(
		  'product_id' => $productId,
		  'warehouse_id' => $warehouseId,
		));

		if ($InventoryID !== null) {
                return $InventoryID->id;
        } else {
    		$insertInventory = new Inventory();
    		$insertInventory->product_id = $productId;
    		$insertInventory->warehouse_id = $warehouseId;
    		$insertInventory->status = 'Active';
    		if ($insertInventory->save()) {
    			return $insertInventory->id;
    		}else{
                return '';
    		}

        }
	}


	public function getCurrentStock($header_id, $product_id, $warehouse_id, $posisi)
	{
		$model = self::model()->findByAttributes(array('stock_adjustment_header_id'=>$header_id,'product_id'=>$product_id, 'warehouse_id'=>$warehouse_id)); 

		// echo $model->total_stock;
		// var_dump($model); die("S");
		if ($model != NULL) {
			return ($posisi == 'stockin')? $model->stock_in : $model->stock_out; 
			// return $model->total_stock;
		}else{
			return 0;
		}
	}


	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return StockAdjustmentDetail the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}

<?php

class InsuranceCompanyController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/backend';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete','ajaxGetCity','ajaxHtmlAddPriceDetail','ajaxHtmlRemovePriceDetail','ajaxHtmlPrice'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$pricelists = InsuranceCompanyPricelist::model()->findAllByAttributes(array('insurance_company_id'=>$id));
		$this->render('view',array(
			'model'=>$this->loadModel($id),
			'pricelists'=>$pricelists,
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		// if(isset($_POST['InsuranceCompany']))
		// {
		// 	$model->attributes=$_POST['InsuranceCompany'];
		// 	if($model->save())
		// 		$this->redirect(array('view','id'=>$model->id));
		// }
		$service = new Service('search');
      	$service->unsetAttributes();  // clear any default values
      	if (isset($_GET['Service']))
        	$service->attributes = $_GET['Service'];

		$serviceCriteria = new CDbCriteria;
		//$positionCriteria->compare('code',$position->code.'%',true,'AND', false);
		$serviceCriteria->compare('t.name',$service->name,true);
		
		$serviceCriteria->together = 'true';
		$serviceCriteria->with = array('serviceCategory','serviceType');
		$serviceCriteria->compare('serviceCategory.name', $service->service_category_name == NULL ? $service->service_category_name : $service->service_category_name , true);
		$serviceCriteria->compare('serviceType.name', $service->service_type_name == NULL ? $service->service_type_name : $service->service_type_name, true);

  	$serviceDataProvider = new CActiveDataProvider('Service', array(
    	'criteria'=>$serviceCriteria,
  	));

  	$serviceArray = array();
		$insurance = $this->instantiate(null);
		$this->performAjaxValidation($insurance->header);

		if(isset($_POST['InsuranceCompany']))
		{


			$this->loadState($insurance);
			if ($insurance->save(Yii::app()->db)){
				$this->redirect(array('view', 'id' => $insurance->header->id));
			} 
			
		}

		$this->render('create',array(
			'insurance'=>$insurance,
			'service'=>$service,
			'serviceDataProvider'=>$serviceDataProvider,
			'serviceArray'=>$serviceArray,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		//$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);
		$service = new Service('search');
      	$service->unsetAttributes();  // clear any default values
      	if (isset($_GET['Service']))
        	$service->attributes = $_GET['Service'];

		$serviceCriteria = new CDbCriteria;
		//$positionCriteria->compare('code',$position->code.'%',true,'AND', false);
		$serviceCriteria->compare('name',$service->name,true);

		$serviceCriteria->together = 'true';
		$serviceCriteria->with = array('serviceCategory','serviceType');
		$serviceCriteria->compare('serviceCategory.name', $service->service_category_name == NULL ? $service->service_category_name : $service->service_category_name , true);
		$serviceCriteria->compare('serviceType.name', $service->service_type_name == NULL ? $service->service_type_name : $service->service_type_name, true);


  	$serviceDataProvider = new CActiveDataProvider('Service', array(
    	'criteria'=>$serviceCriteria,
  	));
  	$serviceChecks = InsuranceCompanyPricelist::model()->findAllByAttributes(array('insurance_company_id'=>$id));
		$serviceArray = array();
		foreach ($serviceChecks as $key => $serviceCheck) {
			array_push($serviceArray,$serviceCheck->service_id);
		}
		$insurance = $this->instantiate($id);

		$this->performAjaxValidation($insurance->header);

		if(isset($_POST['InsuranceCompany']))
		{
			$this->loadState($insurance);
			if ($insurance->save(Yii::app()->db)){
				$this->redirect(array('view', 'id' => $insurance->header->id));
			} else {
				
			}
		}

		$this->render('update',array(
			'insurance'=>$insurance,
			'service'=>$service,
			'serviceDataProvider'=>$serviceDataProvider,
			'serviceArray'=>$serviceArray,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('InsuranceCompany');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new InsuranceCompany('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['InsuranceCompany']))
			$model->attributes=$_GET['InsuranceCompany'];

		$this->render('admin',array(
			'model'=>$model,
		));
	}

	//Add Price Detail
	public function actionAjaxHtmlAddPriceDetail($id,$serviceId)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			$insurance = $this->instantiate($id); 	
			$this->loadState($insurance);

			$insurance->addPriceDetail($serviceId);
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
      Yii::app()->clientscript->scriptMap['jquery.js'] = false;
      $this->renderPartial('_detailPrice', array('insurance'=>$insurance), false, true);
		}
	}

	//Delete Price Detail
	public function actionAjaxHtmlRemovePriceDetail($id, $index)
	{
		if (Yii::app()->request->isAjaxRequest)
		{

			$insurance = $this->instantiate($id);
			$this->loadState($insurance);
			//print_r(CJSON::encode($salesOrder->details));
			$insurance->removePriceDetailAt($index);
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
      Yii::app()->clientscript->scriptMap['jquery.js'] = false;
			$this->renderPartial('_detailPrice', array('insurance'=>$insurance), false, true);
		}
	}

	public function actionAjaxHtmlPrice($id)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			//$model = $this->loadModel($id);

			$prices = InsuranceCompanyPricelist::model()->findAllByAttributes(array('insurance_company_id'=>$id));

			$this->renderPartial('_price-dialog', array(
				'prices' => $prices,
			), false, true);
		}
	}

	public function actionAjaxGetCity()
	{


			$data = City::model()->findAllByAttributes(array('province_id'=>$_POST['InsuranceCompany']['province_id']),array('order'=>'name ASC'));

			if(count($data) > 0)
			{

				$data=CHtml::listData($data,'id','name');
				echo CHtml::tag('option',array('value'=>''),'[--Select City--]',true);
				foreach($data as $value=>$name)
				{

					echo CHtml::tag('option', array('value'=>$value), CHtml::encode($name), true);

				}
			}
			else
			{
				echo CHtml::tag('option',array('value'=>''),'[--Select City--]',true);
			}



	}

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return InsuranceCompany the loaded model
	 * @throws CHttpException
	 */

	public function instantiate($id)
	{
		if (empty($id)){
			$insurance = new Insurances(new InsuranceCompany(), array());
			//print_r("test");
		}
		else
		{
			$insuranceModel = $this->loadModel($id);
			$insurance = new Insurances($insuranceModel, $insuranceModel->insuranceCompanyPricelists);
			//print_r("test");
		}
		return $insurance;
	}



	public function loadState($insurance)
	{
		if (isset($_POST['InsuranceCompany']))
		{
			$insurance->header->attributes = $_POST['InsuranceCompany'];
		}


		if (isset($_POST['InsuranceCompanyPricelist']))
		{
			foreach ($_POST['InsuranceCompanyPricelist'] as $i => $item)
			{
				if (isset($insurance->priceDetails[$i])){
					$insurance->priceDetails[$i]->attributes = $item;
				
				}

				else
				{
					$detail = new InsuranceCompanyPricelist();
					$detail->attributes = $item;
					$insurance->priceDetails[] = $detail;
					
				}
			}
			if (count($_POST['InsuranceCompanyPricelist']) < count($insurance->priceDetails))
				array_splice($insurance->priceDetails, $i + 1);
		}
		else
			{
				$insurance->priceDetails = array();
				
			}
		


	}

	public function loadModel($id)
	{
		$model=InsuranceCompany::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param InsuranceCompany $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='insurance-company-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}

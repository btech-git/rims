<?php

class CustomerController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/backend';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete','ajaxGetCity','ajaxHtmlAddPhoneDetail','ajaxHtmlRemoveDetail','ajaxHtmlAddMobileDetail','ajaxHtmlRemoveMobileDetail','ajaxHtmlAddPicDetail','ajaxHtmlRemovePicDetail','ajaxHtmlAddVehicleDetail','ajaxHtmlRemoveVehicleDetail', 'ajaxGetModel', 'ajaxGetSubModel','updatePic','updateVehicle','ajaxGetCityPic','ajaxGetCityPicIndex','ajaxHtmlAddServiceDetail','ajaxHtmlRemoveServiceDetail','ajaxGetServiceCategory','ajaxGetService','updatePrice' ,'ajaxGetSubModelDetails','ajaxGetChasisCode','ajaxGetFuelPower','ajaxGetTransmissionFuel','ajaxGetTransmissionPower','ajaxGetCarMake','ajaxGetModelPrice','ajaxGetSubModelPrice'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$picDetails = CustomerPic::model()->findAllByAttributes(array('customer_id'=>$id));
		$vehicleDetails = Vehicle::model()->findAllByAttributes(array('customer_id'=>$id));
		$rateDetails = CustomerServiceRate::model()->findAllByAttributes(array('customer_id'=>$id));
		$this->render('view',array(
			'model'=>$this->loadModel($id),
			'picDetails'=> $picDetails,
			'vehicleDetails'=>$vehicleDetails,
			'rateDetails'=>$rateDetails,
		));
	}

	/**
	 * Creates a new model.
	 * If creation is successful, the browser will be redirected to the 'view' page.
	 */
	public function actionCreate()
	{
		// $model=new Customer;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		// if(isset($_POST['Customer']))
		// {
			// $model->attributes=$_POST['Customer'];
			// $model->status='Active';
			// if($model->save())
			// 	$this->redirect(array('admin'));
				//$this->redirect(array('view','id'=>$model->id));
		// }
		$customer = $this->instantiate(null);

		//$this->performAjaxValidation($customer->header);

		if(isset($_POST['Customer']))
		{


			$this->loadState($customer);
			if ($customer->save(Yii::app()->db)){
				$this->redirect(array('view', 'id' => $customer->header->id));
			} else {
				foreach ($customer->phoneDetails as $key => $phoneDetail) {
					//print_r(CJSON::encode($detail->jenis_persediaan_id));
				}
			}
		}


		$this->render('create',array(
			//'model'=>$model,
			'customer'=>$customer,
		));
	}

	/**
	 * Updates a particular model.
	 * If update is successful, the browser will be redirected to the 'view' page.
	 * @param integer $id the ID of the model to be updated
	 */
	public function actionUpdate($id)
	{
		// $model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		// if(isset($_POST['Customer']))
		// {
		// 	$model->attributes=$_POST['Customer'];
		// 	if($model->save())
		// 		$this->redirect(array('admin'));
		// 		//$this->redirect(array('view','id'=>$model->id));
		// }


		$customer = $this->instantiate($id);

		$this->performAjaxValidation($customer->header);

		if(isset($_POST['Customer']))
		{


			$this->loadState($customer);
			if ($customer->save(Yii::app()->db)){
				$this->redirect(array('view', 'id' => $customer->header->id));
			} else {
				foreach ($customer->phoneDetails as $key => $detail) {
					//print_r(CJSON::encode($detail->jenis_persediaan_id));
				}
			}
		}
		$this->render('update',array(
			'customer'=>$customer,
		));
	}

	public function actionUpdatePic($custId,$picId)
	{
		// $customer = $this->instantiate($custId);

		// $this->performAjaxValidation($customer->header);

		// if(isset($_POST['CustomerPic']))
		// {


		// 	$this->loadState($customer);
		// 	if ($customer->save(Yii::app()->db)){
		// 		$this->redirect(array('view', 'id' => $customer->header->id));
		// 	} else {
		// 		foreach ($customer->phoneDetails as $key => $detail) {
		// 			//print_r(CJSON::encode($detail->jenis_persediaan_id));
		// 		}
		// 	}
		// }

		 $customer = $this->instantiate($custId);

		// $this->performAjaxValidation($customer->header);
		$model = CustomerPic::model()->findByPk($picId);
		if(isset($_POST['CustomerPic']))
		{
			$model->attributes=$_POST['CustomerPic'];
			if($model->save())
				$this->redirect(array('view', 'id' => $custId));
		}
		
		$this->render('update',array(
			'customer'=>$customer,
			'model'=>$model,
		));
	}

	public function actionUpdateVehicle($custId,$vehicleId)
	{
		

		 $customer = $this->instantiate($custId);

		// $this->performAjaxValidation($customer->header);
		$model = Vehicle::model()->findByPk($vehicleId);
		if(isset($_POST['Vehicle']))
		{
			$model->attributes=$_POST['Vehicle'];
			if($model->save())
				$this->redirect(array('view', 'id' => $custId));
		}
		
		$this->render('update',array(
			'customer'=>$customer,
			'model'=>$model,
		));
	}

	public function actionUpdatePrice($custId,$priceId)
	{
		

		 $customer = $this->instantiate($custId);

		// $this->performAjaxValidation($customer->header);
		$model = CustomerServiceRate::model()->findByPk($priceId);
		if(isset($_POST['CustomerServiceRate']))
		{
			$model->attributes=$_POST['CustomerServiceRate'];
			if($model->save())
				$this->redirect(array('view', 'id' => $custId));
		}
		
		$this->render('update',array(
			'customer'=>$customer,
			'model'=>$model,
		));
	}

	/**
	 * Deletes a particular model.
	 * If deletion is successful, the browser will be redirected to the 'admin' page.
	 * @param integer $id the ID of the model to be deleted
	 */
	public function actionDelete($id)
	{
		$this->loadModel($id)->delete();

		// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
		if(!isset($_GET['ajax']))
			$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
	}

	/**
	 * Lists all models.
	 */
	public function actionIndex()
	{
		$dataProvider=new CActiveDataProvider('Customer');
		$this->render('index',array(
			'dataProvider'=>$dataProvider,
		));
	}

	/**
	 * Manages all models.
	 */
	public function actionAdmin()
	{
		$model=new Customer('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Customer']))
			$model->attributes=$_GET['Customer'];

		$this->render('admin',array(
			'model'=>$model,
		));
	}
	//Add PhoneDetail
	public function actionAjaxHtmlAddPhoneDetail($id)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			$customer = $this->instantiate($id); 	
			$this->loadState($customer);

			$customer->addDetail();
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
      Yii::app()->clientscript->scriptMap['jquery.js'] = false;
      $this->renderPartial('_detailPhone', array('customer'=>$customer), false, true);
		}
	}

	//Delete Phone Detail
	public function actionAjaxHtmlRemoveDetail($id, $index)
	{
		if (Yii::app()->request->isAjaxRequest)
		{

			$customer = $this->instantiate($id);
			$this->loadState($customer);
			//print_r(CJSON::encode($salesOrder->details));
			$customer->removeDetailAt($index);
			$this->renderPartial('_detailPhone', array('customer'=>$customer), false, true);
		}
	}

	//Add Mobile Detail
	public function actionAjaxHtmlAddMobileDetail($id)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			$customer = $this->instantiate($id); 	
			$this->loadState($customer);

			$customer->addMobileDetail();
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
      Yii::app()->clientscript->scriptMap['jquery.js'] = false;
      $this->renderPartial('_detailMobile', array('customer'=>$customer), false, true);
		}
	}

	//Delete Mobile Detail
	public function actionAjaxHtmlRemoveMobileDetail($id, $index)
	{
		if (Yii::app()->request->isAjaxRequest)
		{

			$customer = $this->instantiate($id);
			$this->loadState($customer);
			//print_r(CJSON::encode($salesOrder->details));
			$customer->removeMobileDetailAt($index);
			$this->renderPartial('_detailMobile', array('customer'=>$customer), false, true);
		}
	}

	//Add Vehicle Detail
	public function actionAjaxHtmlAddVehicleDetail($id)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			$customer = $this->instantiate($id); 	
			$this->loadState($customer);

			$customer->addVehicleDetail();
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
      Yii::app()->clientscript->scriptMap['jquery.js'] = false;
      $this->renderPartial('_detailVehicle', array('customer'=>$customer), false, true);
		}
	}

	//Delete Vehicle Detail
	public function actionAjaxHtmlRemoveVehicleDetail($id, $index)
	{
		if (Yii::app()->request->isAjaxRequest)
		{

			$customer = $this->instantiate($id);
			$this->loadState($customer);
			//print_r(CJSON::encode($salesOrder->details));
			$customer->removeVehicleDetailAt($index);
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
      Yii::app()->clientscript->scriptMap['jquery.js'] = false;
			$this->renderPartial('_detailVehicle', array('customer'=>$customer), false, true);
		}
	}

	public function actionAjaxHtmlAddPicDetail($id)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			$customer = $this->instantiate($id); 	
			$this->loadState($customer);

			$customer->addPicDetail();
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
      Yii::app()->clientscript->scriptMap['jquery.js'] = false;
      $this->renderPartial('_detailPic', array('customer'=>$customer), false, true);
		}
	}

	//Delete Pic Detail
	public function actionAjaxHtmlRemovePicDetail($id, $index)
	{
		if (Yii::app()->request->isAjaxRequest)
		{

			$customer = $this->instantiate($id);
			$this->loadState($customer);
			//print_r(CJSON::encode($salesOrder->details));
			$customer->removePicDetailAt($index);
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
      Yii::app()->clientscript->scriptMap['jquery.js'] = false;
			$this->renderPartial('_detailPic', array('customer'=>$customer), false, true);
		}
	}

	

	public function actionAjaxHtmlAddServiceDetail($id)
	{
		if (Yii::app()->request->isAjaxRequest)
		{
			$customer = $this->instantiate($id); 	
			$this->loadState($customer);

			$customer->addServiceDetail();
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
      Yii::app()->clientscript->scriptMap['jquery.js'] = false;
      $this->renderPartial('_detailPrice', array('customer'=>$customer), false, true);
		}
	}

	//Delete Pic Detail
	public function actionAjaxHtmlRemoveServiceDetail($id, $index)
	{
		if (Yii::app()->request->isAjaxRequest)
		{

			$customer = $this->instantiate($id);
			$this->loadState($customer);
			//print_r(CJSON::encode($salesOrder->details));
			$customer->removeServiceDetailAt($index);
			Yii::app()->clientscript->scriptMap['jquery-ui.min.js'] = false;
      Yii::app()->clientscript->scriptMap['jquery.js'] = false;
			$this->renderPartial('_detailPrice', array('customer'=>$customer), false, true);
		}
	}

	// Get City
	public function actionAjaxGetCity()
	{
		
			
				$data = City::model()->findAllByAttributes(array('province_id'=>$_POST['Customer']['province_id']),array('order'=>'name ASC'));
			
			if(count($data) > 0)
			{

				$data=CHtml::listData($data,'id','name');
				echo CHtml::tag('option',array('value'=>''),'[--Select City--]',true);
				foreach($data as $value=>$name)
				{
					
					echo CHtml::tag('option', array('value'=>$value), CHtml::encode($name), true);
				
				}
			}
			else
			{
				echo CHtml::tag('option',array('value'=>''),'[--Select City--]',true);
			}

		

	}
	public function actionAjaxGetCityPic()
	{
		
			
				$data = City::model()->findAllByAttributes(array('province_id'=>$_POST['CustomerPic']['province_id']),array('order'=>'name ASC'));
			
			if(count($data) > 0)
			{

				$data=CHtml::listData($data,'id','name');
				echo CHTML::tag('option',array('value'=>''),'[--Select City--]',true);
				foreach($data as $value=>$name)
				{
					
					echo CHtml::tag('option', array('value'=>$value), CHtml::encode($name), true);
				
				}
			}
			else
			{
				echo CHtml::tag('option',array('value'=>''),'[--Select City--]',true);
			}

		

	}
	public function actionAjaxGetCityPicIndex($index)
	{
		
		
				$data = City::model()->findAllByAttributes(array('province_id'=>$_POST['CustomerPic'][$index]['province_id']),array('order'=>'name ASC'));
			
			if(count($data) > 0)
			{

				$data=CHtml::listData($data,'id','name');
				echo CHTML::tag('option',array('value'=>''),'[--Select City--]',true);
				foreach($data as $value=>$name)
				{
					
					echo CHtml::tag('option', array('value'=>$value), CHtml::encode($name), true);
				
				}
			}
			else
			{
				echo CHtml::tag('option',array('value'=>''),'[--Select City--]',true);
			}

		

	}

	// Get Car Make
	public function actionAjaxGetCarMake($year)
	{
		$criteria = new CDbCriteria;
		$criteria->with = array('vehicleCarModels','vehicleCarModels.vehicleCarSubModels','vehicleCarModels.vehicleCarSubModels.vehicleCarSubModelDetails');
        $criteria->together = true;
		$criteria->condition = '"' . $year . '" BETWEEN vehicleCarSubModelDetails.assembly_year_start and vehicleCarSubModelDetails.assembly_year_end';
		$data = VehicleCarMake::model()->findAll($criteria); 

		//$data = VehicleCarMake::model()->findAllByAttributes(array('car_make_id'=>$_POST['Vehicle']['car_make_id']));

		if(count($data) > 0)
		{
			$data=CHtml::listData($data,'id','name');
			echo CHtml::tag('option',array('value'=>''),'[--Select Car Make--]',true);
			foreach($data as $value=>$name)
			{
				echo CHtml::tag('option', array('value'=>$value), CHtml::encode($name), true);			
			}
		}
		else
		{
			echo CHtml::tag('option',array('value'=>''),'[--Select Car Make--]',true);
		}
	}

	// Get Car Model for pricelist
	public function actionAjaxGetModelPrice($carmake)
	{
		
		
			$data = VehicleCarModel::model()->findAllByAttributes(array('car_make_id'=>$carmake));

			if(count($data) > 0)
			{

				$data=CHtml::listData($data,'id','name');
				echo CHtml::tag('option',array('value'=>''),'[--Select Car Model--]',true);
				foreach($data as $value=>$name)
				{
					
					echo CHtml::tag('option', array('value'=>$value), CHtml::encode($name), true);
				
				}
			}
			else
			{
				echo CHtml::tag('option',array('value'=>''),'[--Select Car Model--]',true);
			}

		

	}

	//Get Car Sub Model for pricelist
	public function actionAjaxGetSubModelPrice($carmake,$carmodel)
	{
		
		
			$data = VehicleCarSubModel::model()->findAllByAttributes(array('car_make_id'=>$carmake,'car_model_id'=>$carmodel));

			if(count($data) > 0)
			{

				$data=CHtml::listData($data,'id','name');
				echo CHtml::tag('option',array('value'=>''),'[--Select Car SubModel--]',true);
				foreach($data as $value=>$name)
				{
					
					echo CHtml::tag('option', array('value'=>$value), CHtml::encode($name), true);
				
				}
			}
			else
			{
				echo CHtml::tag('option',array('value'=>''),'[--Select Car SubModel--]',true);
			}

		

	}

	// Get Car Model
	public function actionAjaxGetModel($year,$carmake)
	{
		$criteria = new CDbCriteria;
		$criteria->with = array('vehicleCarSubModels','vehicleCarSubModels.vehicleCarSubModelDetails');
        $criteria->together = true;
		$criteria->condition = '"' . $year . '" BETWEEN vehicleCarSubModelDetails.assembly_year_start and vehicleCarSubModelDetails.assembly_year_end';
		$data = VehicleCarModel::model()->findAllByAttributes(array('car_make_id'=>$carmake),$criteria); 

		if(count($data) > 0)
		{
			$data=CHtml::listData($data,'id','name');
			echo CHtml::tag('option',array('value'=>''),'[--Select Car Model--]',true);
			foreach($data as $value=>$name)
			{
				echo CHtml::tag('option', array('value'=>$value), CHtml::encode($name), true);
			}
		}
		else
		{
			echo CHtml::tag('option',array('value'=>''),'[--Select Car Model--]',true);
		}
	}

	// Get Car Sub Model
	public function actionAjaxGetSubModel($year,$carmake,$carmodel)
	{
		$criteria = new CDbCriteria;
		$criteria->with = array('vehicleCarSubModelDetails');
        $criteria->together = true;
		$criteria->condition = '"' . $year . '" BETWEEN vehicleCarSubModelDetails.assembly_year_start and vehicleCarSubModelDetails.assembly_year_end';
		$criteria->order = 't.name ASC';

		$data = VehicleCarSubModel::model()->findAllByAttributes(array('car_make_id'=>$carmake,'car_model_id'=>$carmodel),$criteria); 

		if(count($data) > 0)
		{
			$data=CHtml::listData($data,'id','name');
			echo CHtml::tag('option',array('value'=>''),'[--Select Car Sub Model--]',true);
			foreach($data as $value=>$name)
			{		
				echo CHtml::tag('option', array('value'=>$value), CHtml::encode($name), true);
			}
		}
		else
		{
			echo CHtml::tag('option',array('value'=>''),'[--Select Car Sub Model--]',true);
		}
	}

	public function actionAjaxGetSubModelDetails($year,$carsubmodel)
	{
		$transmissionCriteria = new CDbCriteria;
		$transmissionCriteria->select = 'transmission';
		$transmissionCriteria->distinct = true;
		$transmissionCriteria->condition = 'car_sub_model_id = ' . $carsubmodel;

		$powerCriteria = new CDbCriteria;
		$powerCriteria->select = 'power';
		$powerCriteria->distinct = true;
		$powerCriteria->condition = 'car_sub_model_id = ' . $carsubmodel;

		$fuelTypeCriteria = new CDbCriteria;
		$fuelTypeCriteria->select = 'fuel_type';
		$fuelTypeCriteria->distinct = true;
		$fuelTypeCriteria->condition = 'car_sub_model_id = ' . $carsubmodel;

		$chasisCriteria = new CDbCriteria;
		$chasisCriteria->select = 'chasis_code';
		$chasisCriteria->distinct = true;
		$chasisCriteria->condition = '"' . $year . '" BETWEEN assembly_year_start and assembly_year_end' . ' AND car_sub_model_id = ' . $carsubmodel;		

		$transmissions = VehicleCarSubModelDetail::model()->findAll($transmissionCriteria);
		$powers = VehicleCarSubModelDetail::model()->findAll($powerCriteria);
		$fuel_types = VehicleCarSubModelDetail::model()->findAll($fuelTypeCriteria);
		$chasis = VehicleCarSubModelDetail::model()->find($chasisCriteria);


		$power = CHtml::tag('option',array('value'=>''),'[--Select Power--]',true);
		$transmission = CHtml::tag('option',array('value'=>''),'[--Select Transmission--]',true);
		$fuel_type = CHtml::tag('option',array('value'=>''),'[--Select Fuel Type--]',true);

		$object = array();

		if($transmissions != NULL){
			foreach ($transmissions as $t) {
				$transmission .= CHtml::tag('option',array('value'=>$t->transmission),CHtml::encode($t->transmission),true);
			}
			$object['transmission'] = $transmission;
		}

		if($powers != NULL){
			foreach ($powers as $p) {
				$power .= CHtml::tag('option',array('value'=>$p->power),CHtml::encode($p->power),true);
			}
			$object['power'] = $power;
		}

		if($fuel_types != NULL){
			foreach ($fuel_types as $f) {
				$fuel_type .= CHtml::tag('option',array('value'=>$f->fuel_type),CHtml::encode($f->fuel_type),true);
			}
			$object['fuel_type'] = $fuel_type;
		}

		if($chasis != NULL){
			$object['chasis_code'] = $chasis->chasis_code;
		}
		
		echo CJSON::encode($object);
	}

	public function actionAjaxGetFuelPower($carsubmodel,$transmission)
	{
		if($transmission != NULL){

			$powerCriteria = new CDbCriteria;
			$powerCriteria->select = 'power';
			$powerCriteria->distinct = true;
			$powerCriteria->condition = 'car_sub_model_id = ' . $carsubmodel . ' AND transmission = "' . $transmission . '"';

			$fuelTypeCriteria = new CDbCriteria;
			$fuelTypeCriteria->select = 'fuel_type';
			$fuelTypeCriteria->distinct = true;
			$fuelTypeCriteria->condition = 'car_sub_model_id = ' . $carsubmodel . ' AND transmission = "' . $transmission . '"';

			$powers = VehicleCarSubModelDetail::model()->findAll($powerCriteria);
			$fuel_types = VehicleCarSubModelDetail::model()->findAll($fuelTypeCriteria);

			$power = CHtml::tag('option',array('value'=>''),'[--Select Power--]',true);
			$fuel_type = CHtml::tag('option',array('value'=>''),'[--Select Fuel Type--]',true);

			$object = array();

			if($powers != NULL){
				foreach ($powers as $p) {
					$power .= CHtml::tag('option',array('value'=>$p->power),CHtml::encode($p->power),true);
				}
				$object['power'] = $power;
			}

			if($fuel_types != NULL){
				foreach ($fuel_types as $f) {
					$fuel_type .= CHtml::tag('option',array('value'=>$f->fuel_type),CHtml::encode($f->fuel_type),true);
				}
				$object['fuel_type'] = $fuel_type;
			}
			
			echo CJSON::encode($object);
		} else {
			$this->actionAjaxGetSubModelDetails();
		}
	}

	public function actionAjaxGetTransmissionPower($carsubmodel,$fueltype)
	{
		if($fueltype != NULL){

			$transmissionCriteria = new CDbCriteria;
			$transmissionCriteria->select = 'transmission';
			$transmissionCriteria->distinct = true;
			$transmissionCriteria->condition = 'car_sub_model_id = ' . $carsubmodel . ' AND fuel_type = "' . $fueltype . '"';

			$powerCriteria = new CDbCriteria;
			$powerCriteria->select = 'power';
			$powerCriteria->distinct = true;
			$powerCriteria->condition = 'car_sub_model_id = ' . $carsubmodel . ' AND fuel_type = "' . $fueltype . '"';			

			$transmissions = VehicleCarSubModelDetail::model()->findAll($transmissionCriteria);
			$powers = VehicleCarSubModelDetail::model()->findAll($powerCriteria);
			
			$power = CHtml::tag('option',array('value'=>''),'[--Select Power--]',true);
			$transmission = CHtml::tag('option',array('value'=>''),'[--Select Transmission--]',true);

			$object = array();

			if($transmissions != NULL){
				foreach ($transmissions as $t) {
					$transmission .= CHtml::tag('option',array('value'=>$t->transmission),CHtml::encode($t->transmission),true);
				}
				$object['transmission'] = $transmission;
			}

			if($powers != NULL){
				foreach ($powers as $p) {
					$power .= CHtml::tag('option',array('value'=>$p->power),CHtml::encode($p->power),true);
				}
				$object['power'] = $power;
			}
			
			echo CJSON::encode($object);
		} else {
			$this->actionAjaxGetSubModelDetails();
		}
	}

	public function actionAjaxGetTransmissionFuel($carsubmodel,$power)
	{
		if($power != NULL){

			$transmissionCriteria = new CDbCriteria;
			$transmissionCriteria->select = 'transmission';
			$transmissionCriteria->distinct = true;
			$transmissionCriteria->condition = 'car_sub_model_id = ' . $carsubmodel . ' AND power = "' . $power . '"';

			$fuelTypeCriteria = new CDbCriteria;
			$fuelTypeCriteria->select = 'fuel_type';
			$fuelTypeCriteria->distinct = true;
			$fuelTypeCriteria->condition = 'car_sub_model_id = ' . $carsubmodel . ' AND power = "' . $power. '"';
			
			$transmissions = VehicleCarSubModelDetail::model()->findAll($transmissionCriteria);
			$fuel_types = VehicleCarSubModelDetail::model()->findAll($fuelTypeCriteria);

			$transmission = CHtml::tag('option',array('value'=>''),'[--Select Transmission--]',true);
			$fuel_type = CHtml::tag('option',array('value'=>''),'[--Select Fuel Type--]',true);

			$object = array();

			if($transmissions != NULL){
				foreach ($transmissions as $t) {
					$transmission .= CHtml::tag('option',array('value'=>$t->transmission),CHtml::encode($t->transmission),true);
				}
				$object['transmission'] = $transmission;
			}

			if($fuel_types != NULL){
				foreach ($fuel_types as $f) {
					$fuel_type .= CHtml::tag('option',array('value'=>$f->fuel_type),CHtml::encode($f->fuel_type),true);
				}
				$object['fuel_type'] = $fuel_type;
			}
			
			echo CJSON::encode($object);
		} else {
			$this->actionAjaxGetSubModelDetails();
		}
	}


	public function actionAjaxGetChasisCode($carsubmodeldetail)
	{
		$data = VehicleCarSubModelDetail::model()->findByPk($carsubmodeldetail);
		if($data != NULL){
			$object = array('chasis_code'=>$data->chasis_code);
		} else {
			$object = array();
		}
		echo CJSON::encode($object);
	}

	//get Service Category
	public function actionAjaxGetServiceCategory($serviceType)
	{
		
			
				$data = ServiceCategory::model()->findAllByAttributes(array('service_type_id'=>$serviceType),array('order'=>'name ASC'));
			
			if(count($data) > 0)
			{

				$data=CHtml::listData($data,'id','name');
				echo CHtml::tag('option',array('value'=>''),'[--Select Service Category--]',true);
				foreach($data as $value=>$name)
				{
					
					echo CHtml::tag('option', array('value'=>$value), CHtml::encode($name), true);
				
				}
			}
			else
			{
				echo CHtml::tag('option',array('value'=>''),'[--Select Service Category--]',true);
			}

		

	}

	// get service
	public function actionAjaxGetService($serviceType,$serviceCategory)
	{
		
			
				$data = Service::model()->findAllByAttributes(array('service_type_id'=>$serviceType,'service_category_id'=>$serviceCategory),array('order'=>'name ASC'));
			
			if(count($data) > 0)
			{

				$data=CHtml::listData($data,'id','name');
				echo CHtml::tag('option',array('value'=>''),'[--Select Service--]',true);
				foreach($data as $value=>$name)
				{
					
					echo CHtml::tag('option', array('value'=>$value), CHtml::encode($name), true);
				
				}
			}
			else
			{
				echo CHtml::tag('option',array('value'=>''),'[--Select Service--]',true);
			}

		

	}


	public function instantiate($id)
	{
		if (empty($id)){
			$customer = new Customers(new Customer(), array(),array(),array(),array(),array());
			//print_r("test");
		}
		else
		{
			$customerModel = $this->loadModel($id);
			$customer = new Customers($customerModel, $customerModel->customerPhones, $customerModel->customerMobiles, $customerModel->customerPics, $customerModel->vehicles,$customerModel->customerServiceRates);
		}
		return $customer;
	}

	public function loadState($customer)
	{
		if (isset($_POST['Customer']))
		{
			$customer->header->attributes = $_POST['Customer'];
		}
		if (isset($_POST['CustomerPhone']))
		{
			foreach ($_POST['CustomerPhone'] as $i => $item)
			{
				if (isset($customer->phoneDetails[$i]))
					$customer->phoneDetails[$i]->attributes = $item;
				else
				{
					$detail = new CustomerPhone();
					$detail->attributes = $item;
					$customer->phoneDetails[] = $detail;
				}
			}
			if (count($_POST['CustomerPhone']) < count($customer->phoneDetails))
				array_splice($customer->phoneDetails, $i + 1);
		}
		else
			$customer->phoneDetails = array();


		if (isset($_POST['CustomerMobile']))
		{
			foreach ($_POST['CustomerMobile'] as $i => $item)
			{
				if (isset($customer->mobileDetails[$i]))
					$customer->mobileDetails[$i]->attributes = $item;
				else
				{
					$detail = new CustomerMobile();
					$detail->attributes = $item;
					$customer->mobileDetails[] = $detail;
				}
			}
			if (count($_POST['CustomerMobile']) < count($customer->mobileDetails))
				array_splice($customer->mobileDetails, $i + 1);
		}
		else
			$customer->mobileDetails = array();


		if (isset($_POST['CustomerPic']))
		{
			foreach ($_POST['CustomerPic'] as $i => $item)
			{
				if (isset($customer->picDetails[$i]))
					$customer->picDetails[$i]->attributes = $item;
				else
				{
					$detail = new CustomerPic();
					$detail->attributes = $item;
					$customer->picDetails[] = $detail;
				}
			}
			if (count($_POST['CustomerPic']) < count($customer->picDetails))
				array_splice($customer->picDetails, $i + 1);
		}
		else
			$customer->picDetails = array();

		if (isset($_POST['Vehicle']))
		{
			foreach ($_POST['Vehicle'] as $i => $item)
			{
				if (isset($customer->vehicleDetails[$i]))
					$customer->vehicleDetails[$i]->attributes = $item;
				else
				{
					$detail = new Vehicle();
					$detail->attributes = $item;
					$customer->vehicleDetails[] = $detail;
				}
			}
			if (count($_POST['Vehicle']) < count($customer->vehicleDetails))
				array_splice($customer->vehicleDetails, $i + 1);
		}
		else
			$customer->vehicleDetails = array();

		if (isset($_POST['CustomerServiceRate']))
		{
			foreach ($_POST['CustomerServiceRate'] as $i => $item)
			{
				if (isset($customer->serviceDetails[$i]))
					$customer->serviceDetails[$i]->attributes = $item;
				else
				{
					$detail = new CustomerServiceRate();
					$detail->attributes = $item;
					$customer->serviceDetails[] = $detail;
				}
			}
			if (count($_POST['CustomerServiceRate']) < count($customer->serviceDetails))
				array_splice($customer->serviceDetails, $i + 1);
		}
		else
			$customer->serviceDetails = array();
		
	
	}

	// public function actionRegistration(){
	// 		$this->render('registration',array(
	// 		//'model'=>$model,
	// 		'customer'=>$customer,
	// 	));
	// }

	/**
	 * Returns the data model based on the primary key given in the GET variable.
	 * If the data model is not found, an HTTP exception will be raised.
	 * @param integer $id the ID of the model to be loaded
	 * @return Customer the loaded model
	 * @throws CHttpException
	 */
	public function loadModel($id)
	{
		$model=Customer::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

	/**
	 * Performs the AJAX validation.
	 * @param Customer $model the model to be validated
	 */
	protected function performAjaxValidation($model)
	{
		if(isset($_POST['ajax']) && $_POST['ajax']==='customer-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}
	}
}
